<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Volunteer extends Model
{
    //
    public function user(){
        return $this->belongsTo('App\User');
    }
    public function Departments(){
        return $this->belongsTo('App\Department');
    }
    public function Postions(){
        return $this->belongsTo('App\Postion');
    }
}
