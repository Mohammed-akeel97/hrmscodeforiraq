<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Postion extends Model
{
    //

    public function volunteers(){
        return $this->hasMany('App\Volunteer');
    }
}
