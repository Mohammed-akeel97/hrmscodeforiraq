<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Messages_inboxes_replay extends Model
{
    //
}
