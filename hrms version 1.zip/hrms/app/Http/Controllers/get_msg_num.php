<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use View;
class get_msg_num extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function get_number_msg(){
        $messages = DB::table('messages_inboxes')
        ->join('messages_inboxe_tos', 'messages_inboxe_tos.messages_inboxes_id', '=', 'messages_inboxes.id')      
        ->select(DB::raw('count(messages_inboxe_tos.is_read) as num'))
        ->where('messages_inboxe_tos.to_msg', '=', Auth::user()->email)
        ->where('messages_inboxe_tos.is_read', '=', 0)
        ->get();
       
        View::share('messages', $messages );
    }
}
