<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class treams_controller extends Controller
{
    //
    public function check_trems(){

        $users = DB::table('volunteers')
       
        ->join('postions', 'postions.id', '=', 'volunteers.Positions_id')
        ->join('departments', 'departments.id', '=', 'volunteers.departments_id')
        
        ->select('volunteers.*', 'departments.treams', 'postions.name_postion', 'postions.id as id_position')
        ->where('volunteers.email', '=',Auth::user()->email)
        ->get();
        foreach($users as $user){
$trems=$user->treams;
$id_postion=$user->id_position;
        }

     if($trems==1)   {

        return 1;
     }else if($trems==2&&$id_postion==1){
return 2;
     }
     else{
     return 0;
     }
    }

    //******************************



}

//    return view('hrm.errors.tremas')

// ->with('error', 'You dont Have Treams,Manager');
