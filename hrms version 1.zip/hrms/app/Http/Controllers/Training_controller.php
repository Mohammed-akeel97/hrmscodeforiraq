<?php

namespace App\Http\Controllers;
use App\Training;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use View;
class Training_controller extends Controller
{
     /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
       
    }
       // view
    public function index(){
        $user = new get_msg_num();
        $user->get_number_msg();
   
        
        $Trainings=   Training::orderBy('updated_at','ASC')->paginate(10);
        
   return view('hrm.Training.View.component_form')->with('Trainings',$Trainings);

    }
    // edit search
    public function edit_search(Request $request){
        $user = new get_msg_num();
        $user->get_number_msg();
        if($request->has('Title_Trining_search')){  
            $Trainings =   Training::where('Title_Trining', 'like', '%' . $request->Title_Trining_search . '%')
            ->orderBy('Title_Trining','ASC')->paginate(10);
        }
        else
        {
            $Trainings =   Training::orderBy('Title_Trining','ASC')->paginate(10);
        }
    
    return view('hrm.Training.Edit.component_form')->with('Trainings',$Trainings);
}
    // search
    public function search(Request $request){
        $user = new get_msg_num();
        $user->get_number_msg();
        if($request->has('Title_Trining_search')){  
            $Trainings =   Training::where('Title_Trining', 'like', '%' . $request->Title_Trining_search . '%')
            ->orderBy('Title_Trining','ASC')->paginate(10);
        }
        else
        {
            $Trainings =   Training::orderBy('Title_Trining','ASC')->paginate(10);
        }
    
    return view('hrm.Training.View.component_form')->with('Trainings',$Trainings);
}
    //add
    public function create(){

        $user = new get_msg_num();
        $user->get_number_msg();

        $trems=new treams_controller();
        if($trems->check_trems()==1){
            
        }
        else {
            return view('hrm.errors.tremas');}
        return view('hrm.Training.Add.component_form');
    }
        // add
        public function store(Request $request)
        {
            $trems=new treams_controller();
            if($trems->check_trems()==1){
                
            }
            else {
                return view('hrm.errors.tremas');}
            $this->validate($request ,[
                'Title_Trining'=>'required',
                'Trainer_Name'=>'required',
                'Training_Course_Duration'=>'required',
                'Status'=>'required',
                'Training_Place'=>'required',
                'Training_Start_Date'=>'required',
                'Training_End_Date'=>'required',
       
               ]);
               $Training = new Training;
               //0
               $Training->Title_Trining = $request->input('Title_Trining');
               //1
               $Training->Trainer_Name = $request->input('Trainer_Name');
               //2
               $Training->Training_Course_Duration = $request->input('Training_Course_Duration');
               //3
               $Training->Status = $request->input('Status');
               //4
               $Training->Training_Place = $request->input('Training_Place');
               //5
               $Training->Training_Start_Date = $request->input('Training_Start_Date');
           //6 
           $Training->Training_End_Date = $request->input('Training_End_Date'); 
           //7
           $Training->add_by = Auth::user()->name;
  //add to table
  $Training->save();

        return redirect('/training/create')->with('success', 'Add Training Done successfully');
        
            }

 
        //  edit
            public function edit($id)
    {
        $user = new get_msg_num();
        $user->get_number_msg();
        $trems=new treams_controller();
        if($trems->check_trems()==1){
            
        }
        else {
            return view('hrm.errors.tremas');}
     $get_Training =Training::find($id);
    //****************************
        
          return view('hrm.Training.Update.component_form')->with(compact('get_Training',$get_Training));
    }

//***********
public function update(Request $request, $id)
{
    $trems=new treams_controller();
    if($trems->check_trems()==1){
        
    }
    else {
        return view('hrm.errors.tremas');}
    $this->validate($request ,[
        'Title_Trining'=>'required',
        'Trainer_Name'=>'required',
        'Training_Course_Duration'=>'required',
        'Status'=>'required',
        'Training_Place'=>'required',
        'Training_Start_Date'=>'required',
        'Training_End_Date'=>'required',
       ]);

       $Training = Training::find($id);
       //0
       $Training->Title_Trining = $request->input('Title_Trining');
       //1
       $Training->Trainer_Name = $request->input('Trainer_Name');
       //2
       $Training->Training_Course_Duration = $request->input('Training_Course_Duration');
       //3
       $Training->Status = $request->input('Status');
       //4
       $Training->Training_Place = $request->input('Training_Place');
       //5
       $Training->Training_Start_Date = $request->input('Training_Start_Date');
     //6 
            $Training->Training_End_Date = $request->input('Training_End_Date');
            //7 
     $Training->add_by = Auth::user()->name;
//add to table
$Training->save();

return redirect('/training/edit')->with('success', 'Add Training Done successfully');


}
//****************
    public function View(){
        $user = new get_msg_num();
        $user->get_number_msg();
        $trems=new treams_controller();
        if($trems->check_trems()==1){
            
        }
        else {
            return view('hrm.errors.tremas');}
        $Trainings =   Training::orderBy('Training_Start_Date','ASC')->paginate(10);
   return view('hrm.Training.Edit.component_form')->with('Trainings',$Trainings);

    }
    //******************
    public function destroy($id)
    {

        $trems=new treams_controller();
        if($trems->check_trems()==1){
            
        }
        else {
            return view('hrm.errors.tremas');}

        $Training =  Training::find($id);




        $Training->delete() ;   


     
       
        return redirect('/training/edit')->with('success', 'Done successfully');
    }

}
