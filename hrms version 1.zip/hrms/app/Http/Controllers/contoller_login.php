<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use View;
class contoller_login extends Controller
{
    //  arabic language
public function arabic_login($logo_bath,$bg_img){
       $ar_arr=['login_title'=>"تسجيل الدخول",'p_password'=>"الرمز السري",'p_email'=>"البريد الالكتروني",'p_login'=>"تسجيل الدخول",'logo'=>$logo_bath
      ,'bg_img' =>$bg_img ,'logo_title'=>"Code For Baghdad",'g_title'=>"اهلا وسهلا في Code For Iraq",'system_title'=>"HRMS",'language'=>"ar"];
        return $ar_arr;
}
// english language
public function english_login($logo_bath,$bg_img){
      $en_arr=['login_title'=>"Login",'p_password'=>"Password",'p_email'=>"E-mail",'p_login'=>"login",'logo'=>$logo_bath
     ,'bg_img' =>$bg_img,'logo_title'=>"Code For Baghdad",'g_title'=>"Welcome To Code For Iraq",'system_title'=>"HRMS",'language'=>"en"];
         return $en_arr;
}


//  route 
    public function view_login(){
        $bg_img="wp4.jpg";
        $logo_bath="logo_code_for_iraq2.png";
        $ar_arr=contoller_login::arabic_login($logo_bath,$bg_img);
         return view('login',$ar_arr);
    }
    //************************************************
     public function view_login_en($en){
         $bg_img="../wp4.jpg";
        $logo_bath="../logo_code_for_iraq2.png";
         if($en=="en"){
             $en_arr=contoller_login::english_login($logo_bath,$bg_img);
return view('login',$en_arr);
         } else {
       $ar_arr=contoller_login::arabic_login($logo_bath);
         return view('login',$ar_arr);
         }
    }
}
