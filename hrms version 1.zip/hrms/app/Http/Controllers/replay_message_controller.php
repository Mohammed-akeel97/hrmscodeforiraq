<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Messages_inboxe_to;
use App\Messages_inbox;
use App\Messages_inboxes_replay;
class replay_message_controller extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');

    }
    public function store(Request $request){
   
        if($request->has('replay_id')&&$request->has('detailes_replay')){
            $replay_id=$request->input('replay_id');
            $detailes_replay= $request->input('detailes_replay');
            $this->validate($request ,[
                'detailes_replay'=>'required',
            
               ]);
        }elseif($request->has('replay_id_sent')&&$request->has('detailes_replay_sent')){
            $replay_id=$request->input('replay_id_sent');
            $detailes_replay= $request->input('detailes_replay_sent');
            $this->validate($request ,[
                'detailes_replay_sent'=>'required',
            
               ]);
        }
        $department_senders= DB::table('volunteers')
        ->select('Positions_id','departments_id')
  
        ->where('email', '=',Auth::user()->email)->get();
        foreach ($department_senders as $sender )
        $department_sender=$sender;

        $Messages_inboxes_replay=new Messages_inboxes_replay();

        $Messages_inboxes_replay->detailes_replay=$detailes_replay ;
        $Messages_inboxes_replay->messages_inboxes_id=$replay_id;
        $Messages_inboxes_replay->replay_email=Auth::user()->email;
        $Messages_inboxes_replay->replay_name=Auth::user()->name;
        $Messages_inboxes_replay->replay_department_id=$sender->departments_id;
        $Messages_inboxes_replay->replay_position_id=$sender->Positions_id;
        $Messages_inboxes_replay->save();


       
        $get_id=DB::table('messages_inboxe_tos')->select('id','to_msg')
        ->where('messages_inboxes_id', '=',$replay_id)->get();
        foreach($get_id as $id_arr){
        $Messages_inbox_to=Messages_inboxe_to::find($id_arr->id);
        $Messages_inbox_to->is_read = 0;
        $Messages_inbox_to->save();
            
    }

        return redirect('/announcement')->with('success', 'Send Message  Done successfully');
    }
    public function create(){
    }


    public function edit($id)
    {

    }
}
