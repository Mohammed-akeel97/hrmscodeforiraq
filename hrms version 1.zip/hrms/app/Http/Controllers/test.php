<?php

namespace App\Http\Controllers;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;

use App\Http\Controllers\Controller;

class test extends Controller
{
    
    public function test(){
         return view('test.test');
    }


    public function veiwtests(){
     

     

         return view('test.veiwtests');
    }
 
    
}
