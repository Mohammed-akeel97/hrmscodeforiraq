<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use View;
class user_controller extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    
    }

    //
    public function index(){
        $user = new get_msg_num();
        $user->get_number_msg();
        $user = DB::table('volunteers')
        ->join('users', 'users.id', '=', 'volunteers.id')
        ->join('postions', 'postions.id', '=', 'volunteers.Positions_id')
        ->join('departments', 'departments.id', '=', 'volunteers.departments_id')
        
        ->select('users.*', 'volunteers.*', 'departments.name_department', 'postions.name_postion')
        
        ->where('users.email', '=',Auth::user()->email)
        ->get();

        //***********88
   return view('hrm.user.user')->with('user_info',$user);

    }
    //******************************
    public function update(Request $request,$id){
        $this->validate($request ,[
          'Previous_Password' => 'required|string|min:6',
            'password' => 'required|string|min:6|confirmed',
           // 'password-confirm' => 'required',
           ]);

           $useres =   User::select('password','id')
           ->where('email','=',Auth::user()->email)
           ->get();
           $hash_password;
           $id_user;
           foreach ($useres as $user) {
            $hash_password=$user->password;
            $id=$user->id;
           }
     
   
           if($request->has('Previous_Password') ){
            if (Hash::check( $request->input('Previous_Password'), $hash_password)) {
$user=User::find($id);

$user->password=bcrypt($request->input('password'));
$user->save();

                return redirect('/user')->with('success', 'Change Password Done successfully');
            }else {
                return redirect('/user')
                ->with('error', 'Change Password Passsword Not Match')
                ->with('Previous_Password','Password Not Match');
            }
           
           }
           return redirect('/user');
       
    }
}
