<?php

namespace App\Http\Controllers;
use App\project;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use App\Http\Controllers\Controller;
use View;

class project_controller extends Controller

{
      public function __construct()
    {
        $this->middleware('auth');
    }

    

  public function index(){
    $user = new get_msg_num();
    $user->get_number_msg();
    $trems=new treams_controller();

    if($trems->check_trems()==1||$trems->check_trems()==2){
        
    }
    else {
        return view('hrm.errors.tremas');}
    $Projects=   Project::orderBy('updated_at','DESC')->paginate(10);
return view('hrm.project.Edit.component_form')->with('Projects',$Projects);

    }
        // edit search
        public function edit_search(Request $request){
            $user = new get_msg_num();
            $user->get_number_msg();
            $trems=new treams_controller();
        
            if($trems->check_trems()==1||$trems->check_trems()==2){
                
            }
            else {
                return view('hrm.errors.tremas');} 

            if($request->has('Project_Name_search')){  
                $Projects =   project::where('Project_Name', 'like', '%' . $request->Project_Name_search . '%')
                ->orderBy('Project_Name','ASC')->paginate(10);
            }
            else
            {
                $Projects =   project::orderBy('Project_Name','ASC')->paginate(10);
            }
        
        return view('hrm.project.Edit.component_form')->with('Projects',$Projects);
    }
        // search
        public function search(Request $request){
            $user = new get_msg_num();
            $user->get_number_msg();
            if($request->has('Project_Name_search')){  
                $Projects =   project::where('Project_Name', 'like', '%' . $request->Project_Name_search . '%')
                ->orderBy('Project_Name','ASC')->paginate(1);
            }
            else
            {
                $Projects =   project::orderBy('Project_Name','ASC')->paginate(10);
            }
        
        return view('hrm.project.View.component_form')->with('Projects',$Projects);
        }

 
        //  edit
        public function edit($id)
        {
            $user = new get_msg_num();
            $user->get_number_msg();
            $trems=new treams_controller();
        
            if($trems->check_trems()==1||$trems->check_trems()==2){
                
            }
            else {
                return view('hrm.errors.tremas');}
         $get_Project = project::find($id);
        //****************************
        return view('hrm.project.Update.component_form')->with(compact('get_Project',$get_Project));
        }
    
//***********
public function update(Request $request, $id)
{
    $user = new get_msg_num();
    $user->get_number_msg();
    $trems=new treams_controller();

    if($trems->check_trems()==1||$trems->check_trems()==2){
        
    }
    else {
        return view('hrm.errors.tremas');}

 $this->validate($request ,[
    'Project_Name'=>'required',
    'Project_Description'=>'required',
    'Project_Requirement'=>'required',
    'Project_Provider'=>'required',
    'Team_Responsible'=>'required',
    'Project_Start_Date'=>'required',
    'Estimate_Project_Time'=>'required',
    'Project_Report'=>'required',


    ]);


    $project = Project::find($id);
    //1
    $project->Project_Name = $request->input('Project_Name');
    //2
    $project->Project_Description = $request->input('Project_Description');
    //3
    $project->Project_Requirement = $request->input('Project_Requirement');
    //4
    $project->Project_Requirement = $request->input('Project_Requirement');
    //5
    $project->Project_Provider = $request->input('Project_Provider');
    //6
    $project->Team_Responsible = $request->input('Team_Responsible');
    //7
    $project->Project_Start_Date = $request->input('Project_Start_Date');
    //8
    $project->Estimate_Project_Time = $request->input('Estimate_Project_Time');
    //9
    $project->Project_Report = $request->input('Project_Report');
    $project->save();
return redirect('/project')->with('success', 'Add Training Done successfully');


}

  //add
      public function create(){
        $user = new get_msg_num();
        $user->get_number_msg();
        $trems=new treams_controller();
    
        if($trems->check_trems()==1||$trems->check_trems()==2){
            
        }
        else {
            return view('hrm.errors.tremas');}
return view('hrm.project.Add.component_form');

    }
      // add
      public function store(Request $request)
      {
        $user = new get_msg_num();
        $user->get_number_msg();
        $trems=new treams_controller();
    
        if($trems->check_trems()==1||$trems->check_trems()==2){
            
        }
        else {
            return view('hrm.errors.tremas');}



          $this->validate($request ,[
              'Project_Name'=>'required',
              'Project_Description'=>'required',
              'Project_Requirement'=>'required',
              'Project_Provider'=>'required',
              'Team_Responsible'=>'required',
              'Project_Start_Date'=>'required',
              'Estimate_Project_Time'=>'required',
              'Project_Report'=>'required',
       
             ]);

              // add to table  

   $project = new Project;
   //1
   $project->Project_Name = $request->input('Project_Name');
   //2
   $project->Project_Description = $request->input('Project_Description');
   //3
   $project->Project_Requirement = $request->input('Project_Requirement');
   //4
   $project->Project_Requirement = $request->input('Project_Requirement');
   //5
   $project->Project_Provider = $request->input('Project_Provider');
   //6
   $project->Team_Responsible = $request->input('Team_Responsible');
   //7
   $project->Project_Start_Date = $request->input('Project_Start_Date');
   //8
   $project->Estimate_Project_Time = $request->input('Estimate_Project_Time');
   //9
   $project->Project_Report = $request->input('Project_Report');
   $project->save();
   return redirect('/project/create')->with('success', 'Add Project Done successfully');

    }
    public function View(){
        $Project =   project::orderBy('Project_Start_Date','ASC')->paginate(10);
   return view('hrm.Project.Edit.component_form')->with('Project',$Project);

    }




     
  
public function destroy($id)
{
    $trems=new treams_controller();

    if($trems->check_trems()==1||$trems->check_trems()==2){
        
    }
    else {
        return view('hrm.errors.tremas');} 
    $Projects =  project::find($id);
    $Projects->delete() ;   
    return redirect('/project')->with('success', 'Done successfully');
}

    
}

