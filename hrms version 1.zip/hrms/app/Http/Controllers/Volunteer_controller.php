<?php

namespace App\Http\Controllers;
use App\Volunteer;
use App\User;
use App\Department;
use App\Postion;
use View;
use Illuminate\Encryption\EncryptionServiceProvider;
use Illuminate\Contracts\Encryption\Encrypter;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Support\Facades\Storage;
class Volunteer_controller extends Controller
{
 /**
     * Create a new controller instance.
     *
     * @return void
     */
     public function __construct()
     {
        $this->middleware('auth');
     
     }

public function index(){
  



    $user = new get_msg_num();
    $user->get_number_msg();
    $Volunteers =   Volunteer::select('*','volunteers.created_at as join_date','volunteers.id as volunteerID','volunteers.email as volunteerEmail')->orderBy('Full_Name','ASC') 
    ->join('departments', 'departments.id', '=', 'volunteers.departments_id')
    ->join('postions', 'postions.id', '=', 'volunteers.Positions_id')
    ->join('users', 'users.id', '=', 'volunteers.how_add_id')
    ->paginate(10);
    $get_depatment=Department::all();
    $get_postion=Postion::all();

    $trems=new treams_controller();
   
    

if($trems->check_trems()==1){
    return view('hrm.volunteer.Edit.component_form')->with('Volunteers',$Volunteers)
->with('get_postion', $get_postion)
    ->with('get_depatment', $get_depatment);
}
    else {
        return view('hrm.errors.tremas')
 ->with('error', 'You dont Have Treams,Manager');
    }
}
//*************************888
public function search_structor($request){
    
    if($request->has('Full_Name_search')&&$request->has('Department_search')&&$request->has('Position_search')&&$request->has('parent_group_search')){  
        $Volunteers =   Volunteer::select('*','volunteers.created_at as join_date','volunteers.email as volunteerEmail')->orderBy('Full_Name','ASC') 
        ->join('departments', 'departments.id', '=', 'volunteers.departments_id')
        ->join('postions', 'postions.id', '=', 'volunteers.Positions_id')
        ->join('users', 'users.id', '=', 'volunteers.how_add_id')->where('Full_Name',$request->Full_Name_search)
        ->Where('departments_id', '=', $request->Department_search)
        ->Where('Positions_id', '=', $request->Position_search)
        ->Where('parent_group', '=', $request->parent_group_search)
        ->orderBy('Full_Name','ASC')->paginate(10);
    }else
           // p1

           if($request->has('Position_search')&&$request->has('Department_search')&&$request->has('parent_group_search')){  
            $Volunteers =   Volunteer::select('*','volunteers.created_at as join_date','volunteers.email as volunteerEmail')->orderBy('Full_Name','ASC') 
            ->join('departments', 'departments.id', '=', 'volunteers.departments_id')
            ->join('postions', 'postions.id', '=', 'volunteers.Positions_id')
            ->join('users', 'users.id', '=', 'volunteers.how_add_id')->where('Positions_id',$request->Position_search)
            ->Where('departments_id', '=', $request->Department_search)
            ->Where('parent_group', '=', $request->parent_group_search)
            ->orderBy('Full_Name','ASC')->paginate(10);
        }else
        // p1

        if($request->has('Full_Name_search')&&$request->has('Department_search')&&$request->has('parent_group_search')){  
            $Volunteers =   Volunteer::select('*','volunteers.created_at as join_date','volunteers.email as volunteerEmail')->orderBy('Full_Name','ASC') 
            ->join('departments', 'departments.id', '=', 'volunteers.departments_id')
            ->join('postions', 'postions.id', '=', 'volunteers.Positions_id')
            ->join('users', 'users.id', '=', 'volunteers.how_add_id')->where('Full_Name',$request->Full_Name_search)
            ->Where('departments_id', '=', $request->Department_search)
            ->Where('parent_group', '=', $request->parent_group_search)
            ->orderBy('Full_Name','ASC')->paginate(10);
        }else
      
    // p1

    if($request->has('Full_Name_search')&&$request->has('Department_search')&&$request->has('Position_search')){  
        $Volunteers =   Volunteer::select('*','volunteers.created_at as join_date','volunteers.email as volunteerEmail')->orderBy('Full_Name','ASC') 
        ->join('departments', 'departments.id', '=', 'volunteers.departments_id')
        ->join('postions', 'postions.id', '=', 'volunteers.Positions_id')
        ->join('users', 'users.id', '=', 'volunteers.how_add_id')->where('Full_Name',$request->Full_Name_search)
       ->Where('departments_id', '=', $request->Department_search)
        ->Where('Positions_id', '=', $request->Position_search)
        ->orderBy('Full_Name','ASC')->paginate(10);
    }else
    //p2
    if($request->has('Full_Name_search')&&$request->has('Department_search')){  
        $Volunteers =   Volunteer::select('*','volunteers.created_at as join_date','volunteers.email as volunteerEmail')->orderBy('Full_Name','ASC') 
        ->join('departments', 'departments.id', '=', 'volunteers.departments_id')
        ->join('postions', 'postions.id', '=', 'volunteers.Positions_id')
        ->join('users', 'users.id', '=', 'volunteers.how_add_id')->where('Full_Name',$request->Full_Name)
        ->Where('departments_id', '=', $request->Department_search)
        ->orderBy('Full_Name','ASC')->paginate(10);
    }else
    //p3  //
    if($request->has('Full_Name_search')&&$request->has('parent_group_search')){  
        $Volunteers =   Volunteer::select('*','volunteers.created_at as join_date','volunteers.email as volunteerEmail')->orderBy('Full_Name','ASC') 
        ->join('departments', 'departments.id', '=', 'volunteers.departments_id')
        ->join('postions', 'postions.id', '=', 'volunteers.Positions_id')
        ->join('users', 'users.id', '=', 'volunteers.how_add_id')->where('Full_Name',$request->Full_Name_search)
        ->Where('parent_group', '=', $request->parent_group_search)
        ->orderBy('Full_Name','ASC')->paginate(10);
    }else
        //p3
        if($request->has('Full_Name_search')&&$request->has('Position_search')){  
            $Volunteers =   Volunteer::select('*','volunteers.created_at as join_date','volunteers.email as volunteerEmail')->orderBy('Full_Name','ASC') 
            ->join('departments', 'departments.id', '=', 'volunteers.departments_id')
            ->join('postions', 'postions.id', '=', 'volunteers.Positions_id')
            ->join('users', 'users.id', '=', 'volunteers.how_add_id')->where('Full_Name',$request->Full_Name_search)
            ->Where('Positions_id', '=', $request->Position_search)
            ->orderBy('Full_Name','ASC')->paginate(10);
        }else
    //p4
 
    if($request->has('Position_search')&&$request->has('Department_search')){  
        $Volunteers =   Volunteer::select('*','volunteers.created_at as join_date','volunteers.email as volunteerEmail')->orderBy('Full_Name','ASC') 
        ->join('departments', 'departments.id', '=', 'volunteers.departments_id')
        ->join('postions', 'postions.id', '=', 'volunteers.Positions_id')
        ->join('users', 'users.id', '=', 'volunteers.how_add_id')->where('Positions_id',$request->Position_search)
        ->Where('departments_id', '=', $request->Department_search)
        ->orderBy('Full_Name','ASC')->paginate(10);
    }else

    //p5
      if($request->has('parent_group_search')&&$request->has('Department_search')){  
        $Volunteers =   Volunteer::select('*','volunteers.created_at as join_date','volunteers.email as volunteerEmail')->orderBy('Full_Name','ASC') 
        ->join('departments', 'departments.id', '=', 'volunteers.departments_id')
        ->join('postions', 'postions.id', '=', 'volunteers.Positions_id')
        ->join('users', 'users.id', '=', 'volunteers.how_add_id')->where('parent_group',$request->parent_group_search)
        ->Where('departments_id', '=', $request->Department_search)
        ->orderBy('Full_Name','ASC')->paginate(10);
    }else
      //p6
      if($request->has('parent_group_search')&&$request->has('Position_search')){  
        $Volunteers =   Volunteer::select('*','volunteers.created_at as join_date','volunteers.email as volunteerEmail')->orderBy('Full_Name','ASC') 
        ->join('departments', 'departments.id', '=', 'volunteers.departments_id')
        ->join('postions', 'postions.id', '=', 'volunteers.Positions_id')
        ->join('users', 'users.id', '=', 'volunteers.how_add_id')->where('parent_group',$request->parent_group_search)
        ->Where('Positions_id', '=', $request->Position_search)
        ->orderBy('Full_Name','ASC')->paginate(10);
    }else
//p7
    if($request->has('Full_Name_search')&&!$request->has('Department_search')&&!$request->has('Position_search')&&!$request->has('parent_group_search')){  
        $Volunteers =   Volunteer::select('*','volunteers.created_at as join_date','volunteers.email as volunteerEmail')->orderBy('Full_Name','ASC') 
        ->join('departments', 'departments.id', '=', 'volunteers.departments_id')
        ->join('postions', 'postions.id', '=', 'volunteers.Positions_id')
        ->join('users', 'users.id', '=', 'volunteers.how_add_id')->where('Full_Name',$request->Full_Name_search)
        ->orWhere('Full_Name', 'like', '%' . $request->Full_Name_search . '%')
        ->orderBy('Full_Name','ASC')->paginate(10);
    }else
//p8
    if(!$request->has('Full_Name_search')&&$request->has('Department_search')&&!$request->has('Position_search')&&!$request->has('parent_group_search')){  
        $Volunteers =   Volunteer::select('*','volunteers.created_at as join_date','volunteers.email as volunteerEmail')->orderBy('Full_Name','ASC') 
        ->join('departments', 'departments.id', '=', 'volunteers.departments_id')
        ->join('postions', 'postions.id', '=', 'volunteers.Positions_id')
        ->join('users', 'users.id', '=', 'volunteers.how_add_id')->where('departments_id',$request->Department_search)     
        ->orderBy('Full_Name','ASC')->paginate(10);
      
    }else
    if(!$request->has('Full_Name_search')&&!$request->has('Department_search')&&!$request->has('Position_search')&&$request->has('parent_group_search')){  
        $Volunteers =   Volunteer::select('*','volunteers.created_at as join_date','volunteers.email as volunteerEmail')->orderBy('Full_Name','ASC') 
        ->join('departments', 'departments.id', '=', 'volunteers.departments_id')
        ->join('postions', 'postions.id', '=', 'volunteers.Positions_id')
        ->join('users', 'users.id', '=', 'volunteers.how_add_id')->where('parent_group',$request->parent_group_search)
        ->orderBy('Full_Name','ASC')->paginate(10);
    }
    else
    //p9

    if(!$request->has('Full_Name_search')&&!$request->has('Department_search')&&$request->has('Position_search')&&!$request->has('parent_group_search')){  
        $Volunteers =   Volunteer::select('*','volunteers.created_at as join_date','volunteers.email as volunteerEmail')->orderBy('Full_Name','ASC') 
        ->join('departments', 'departments.id', '=', 'volunteers.departments_id')
        ->join('postions', 'postions.id', '=', 'volunteers.Positions_id')
        ->join('users', 'users.id', '=', 'volunteers.how_add_id')->where('Positions_id',$request->Position_search) 
        ->orderBy('Full_Name','ASC')->paginate(10);
    
    }else
    //p10

   
    {
     
        $Volunteers =   Volunteer::select('*','volunteers.created_at as join_date','volunteers.email as volunteerEmail')
        ->join('departments', 'departments.id', '=', 'volunteers.departments_id')
        ->join('postions', 'postions.id', '=', 'volunteers.Positions_id')
        ->join('users', 'users.id', '=', 'volunteers.how_add_id')->orderBy('Full_Name','ASC')->paginate(10);
    }
    return $Volunteers;
}
//***************************************************************
//edit  search resluts 
public function results_search(Request $request){
    $user = new get_msg_num();
    $user->get_number_msg();
    $get_depatment=Department::all();
    $get_postion=Postion::all();
    $Volunteers=Volunteer_controller::search_structor($request);
        return view('hrm.volunteer.Search.component_form')->with('Volunteers',$Volunteers)->with('get_postion', $get_postion)
        ->with('get_depatment', $get_depatment);
    }
    //******************************

//***************************************************************
//edit  search sub 
//
public function edit_search(Request $request){
    $user = new get_msg_num();
    $user->get_number_msg();
    $get_depatment=Department::all();
    $get_postion=Postion::all();
    $Volunteers=Volunteer_controller::search_structor($request);
    return view('hrm.volunteer.Edit.component_form')->with('Volunteers',$Volunteers)->with('get_postion', $get_postion)
    ->with('get_depatment', $get_depatment);;
}
//******************************
// go to volunteer
public function re_volunteer(){
    return redirect('/volunteer');
}
//**********************************
//update 
public function update(Request $request, $id)
{
    $trems=new treams_controller();
    if($trems->check_trems()==1){
        
    }
    else {
        return view('hrm.errors.tremas')
 ->with('error', 'You dont Have Treams,Manager');
    }
    $this->validate($request ,[
        'departments'=>'required',
        'Position'=>'required',
        'Acadimic_Achievement'=>'required',
        'Specialization'=>'required',
        'Experience'=>'required',
        'email'=>'required',
        'Phone_Number1'=>'required',
   
        'Full_Name'=>'required',
        'Blood_Group'=>'required',
        'Marital_Status'=>'required',
        'Gender'=>'required',
        'Day_of_Birth'=>'required',
        'Governorate'=>'required',
        'Address'=>'required',
        'Password'=>'min:6|nullable',
        'facebook'=>'url|nullable',
        'Instagram'=>'url|nullable',
        'Twitter'=>'url|nullable',
        'New_Pecture'=>'image|nullable|max:1024',
       ]);


       if($request->hasFile('New_Pecture')){  
        
            $filenameWithExtention = $request->file('New_Pecture')->getClientOriginalName();
            $fileName = pathinfo($filenameWithExtention,PATHINFO_FILENAME);
            $extension = $request->file('New_Pecture')->getClientOriginalExtension();
            $fileNameStore = $fileName .'_'.time().'.'.$extension;
        
            $path = $request->file('New_Pecture')->move(base_path() . '/public/pictures/', $fileNameStore);
             }
                // add to table  
                $Volunteer =    Volunteer::find($id);
 //0
 $Volunteer->Positions_id = $request->input('Position');
 //1
 $Volunteer->departments_id = $request->input('departments');
 //2
 $Volunteer->Full_Name = $request->input('Full_Name');
 //3
 $Volunteer->Specialization = $request->input('Specialization');
 //4
 $Volunteer->Gender = $request->input('Gender');
 //5
 $Volunteer->parent_group = $request->input('Parent_Group');
 //6
 $Volunteer->Day_of_Birth = $request->input('Day_of_Birth');
 //7
 $Volunteer->Acadimic_Achievement = $request->input('Acadimic_Achievement');
 //8
 $Volunteer->Governorate = $request->input('Governorate');
 //9
 if($request->hasFile('New_Pecture')){ 
 $Volunteer->New_Pecture = $fileNameStore;
 }
 //10
 $Volunteer->Address = $request->input('Address');
 //11
 $Volunteer->Experience = $request->input('Experience');
 //12
 $Volunteer->Blood_Group = $request->input('Blood_Group');
 //13
 $Volunteer->email = $request->input('email');
 //14
 $Volunteer->Marital_Status = $request->input('Marital_Status');
 //15
 $Volunteer->Phone_Number1 = $request->input('Phone_Number1');
 //16
 $Volunteer->Phone_Number2 = $request->input('Phone_Number2');
 //17
 $Volunteer->Twitter = $request->input('Twitter');
 //18
 $Volunteer->facebook = $request->input('facebook');
 //19
 $Volunteer->Instagram = $request->input('Instagram');
 //20
 $Volunteer->how_add_id = Auth::user()->id;
   //add to table
   $Volunteer->save();
   // add to table user
   $User = User::find($id);
   $User->name=$request->input('Full_Name');
   $User->email=$request->input('email');
   if($request->has('Password')){
   $User->password=bcrypt($request->input('Password'));
   }
   $User->save();
   return redirect('/volunteer')->with('success', 'Done successfully');
}






    // add
    public function store(Request $request)
    {
        $trems=new treams_controller();
        if($trems->check_trems()==1){
            
        }
        else {
            return view('hrm.errors.tremas');}
 
            

        $this->validate($request ,[
            'departments'=>'required',
            'Position'=>'required',
            'Acadimic_Achievement'=>'required',
            'Specialization'=>'required',
            'Experience'=>'required',
            'email'=>'required|unique:volunteers|unique:users',
            'Phone_Number1'=>'required',
       
            'Full_Name'=>'required',
            'Blood_Group'=>'required',
            'Marital_Status'=>'required',
            'Gender'=>'required',
            'Day_of_Birth'=>'required',
            'Governorate'=>'required',
            'Address'=>'required',
            'Password'=>'required|min:6',
            'facebook'=>'url|nullable',
            'Instagram'=>'url|nullable',
            'Twitter'=>'url|nullable',
            'New_Pecture'=>'image|required|max:1024',
           ]);
           if($request->hasFile('New_Pecture')){  
            
                $filenameWithExtention = $request->file('New_Pecture')->getClientOriginalName();
                $fileName = pathinfo($filenameWithExtention,PATHINFO_FILENAME);
                $extension = $request->file('New_Pecture')->getClientOriginalExtension();
                $fileNameStore = $fileName .'_'.time().'.'.$extension;
            
                $path = $request->file('New_Pecture')->move(base_path() . '/public/pictures/', $fileNameStore);
              
             
                        
                    }else{
                            $fileNameStore = 'noImage.jpg';
                          }
             
            // if($request->hasFile('post_image')){
            //     $filenameWithExtention = $request->file('post_image')->getClientOriginalName();
            //     $fileName = pathinfo($filenameWithExtention,PATHINFO_FILENAME);
            //     $extension = $request->file('post_image')->getClientOriginalExtension();
            //     $fileNameStore = $fileName .'_'.time().'.'.$extension;
            //     $path = $request->file('post_image')->storeAs('public/post_image',$fileNameStore);
            // }else{
            //     $fileNameStore = 'noImage.jpg';
            // }
   // add to table  

   $Volunteer = new Volunteer;
   //0
   $Volunteer->Positions_id = $request->input('Position');
   //1
   $Volunteer->departments_id = $request->input('departments');
   //2
   $Volunteer->Full_Name = $request->input('Full_Name');
   //3
   $Volunteer->Specialization = $request->input('Specialization');
   //4
   $Volunteer->Gender = $request->input('Gender');
   //5
   $Volunteer->parent_group = $request->input('Parent_Group');
   //6
   $Volunteer->Day_of_Birth = $request->input('Day_of_Birth');
   //7
   $Volunteer->Acadimic_Achievement = $request->input('Acadimic_Achievement');
   //8
   $Volunteer->Governorate = $request->input('Governorate');
   //9
   $Volunteer->New_Pecture = $fileNameStore;
   //10
   $Volunteer->Address = $request->input('Address');
   //11
   $Volunteer->Experience = $request->input('Experience');
   //12
   $Volunteer->Blood_Group = $request->input('Blood_Group');
   //13
   $Volunteer->email = $request->input('email');
   //14
   $Volunteer->Marital_Status = $request->input('Marital_Status');
   //15
   $Volunteer->Phone_Number1 = $request->input('Phone_Number1');
   //16
   $Volunteer->Phone_Number2 = $request->input('Phone_Number2');
   //17
   $Volunteer->Twitter = $request->input('Twitter');
   //18
   $Volunteer->facebook = $request->input('facebook');
   //19
   $Volunteer->Instagram = $request->input('Instagram');
   //20
   $Volunteer->how_add_id = Auth::user()->id;
   //add to table
   $Volunteer->save();
   // add to table user
   $User = new User;
   $User->name=$request->input('Full_Name');
   $User->email=$request->input('email');
   $User->password=bcrypt($request->input('Password'));
   $User->save();

        return redirect('/volunteer/create')->with('success', 'Add Volunteer Done successfully');
    }


 




    //*************************************************8
    // create page
    public function create(){
        $user = new get_msg_num();
        $user->get_number_msg();
        $trems=new treams_controller();
        if($trems->check_trems()==1){
            
        }
        else {
            return view('hrm.errors.tremas');}
     
      
        $titles=Volunteer_controller::titles("en");
        $form_items=Volunteer_controller::form_items("en");

      
$get_depatment=Department::all();
$get_postion=Postion::all();
// get manager
$get_manager=DB::table('volunteers')
->select('volunteers.email','volunteers.Full_Name','volunteers.departments_id')
->join('postions', 'postions.id', '=', 'volunteers.Positions_id')
->where('postions.id', 1)
->get();

return view('hrm.volunteer.Add.component_form',$titles,$form_items)
->with('get_postion', $get_postion)
->with('get_depatment', $get_depatment)
->with('get_manager', $get_manager);

    }

  
//search
  public function search(){
    $user = new get_msg_num();
    $user->get_number_msg();
    $get_depatment=Department::all();
    $get_postion=Postion::all();
    $Volunteers =   Volunteer::select('*','volunteers.created_at as join_date','volunteers.email as volunteerEmail')->orderBy('Full_Name','ASC') 
    ->join('departments', 'departments.id', '=', 'volunteers.departments_id')
    ->join('postions', 'postions.id', '=', 'volunteers.Positions_id')
    ->join('users', 'users.id', '=', 'volunteers.how_add_id')
    ->paginate(10);
    return view('hrm.volunteer.Search.component_form')->with('Volunteers',$Volunteers)
    ->with('get_postion', $get_postion)
    ->with('get_depatment', $get_depatment);
    }


    public function edit($id)
    {
        $user = new get_msg_num();
        $user->get_number_msg();
        $trems=new treams_controller();
        if($trems->check_trems()==1){
            
        }
        else {
            return view('hrm.errors.tremas');}
       
      
             $titles=Volunteer_controller::titles("en");
        $form_items=Volunteer_controller::form_items("en");
        $get_depatment=Department::all();
        $get_postion=Postion::all();
        // get manager
        $get_manager=DB::table('volunteers')
        ->select('volunteers.email','volunteers.Full_Name','volunteers.departments_id')
        ->join('postions', 'postions.id', '=', 'volunteers.Positions_id')
        ->where('postions.id', 1)
        ->get();
       $get_volunteer =Volunteer::find($id);
    //****************************
   

        // return data
return view('hrm.volunteer.Update.component_form',$titles,$form_items)
->with(compact('get_postion',$get_postion))
->with(compact('get_volunteer',$get_volunteer))
->with('get_postion', $get_postion)
->with('get_depatment', $get_depatment)
->with('get_manager', $get_manager);
        

    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
     public function destroy($id)
     {
        $trems=new treams_controller();
        if($trems->check_trems()==1){
            
        }
        else {
            return view('hrm.errors.tremas');}


        $trems=new treams_controller();
        $trems->get_trems();


 if($id==Auth::user()->id){
    return redirect('/volunteer')->with('error', "Not Delete");
     }
else{
    $Volunteer =  Volunteer::find($id);
    if($Volunteer->New_Pecture != 'noImage.jpg'){
        Storage::delete('public/pictures/'.$Volunteer->New_Pecture);
    }
    
          $Volunteer->delete() ;   
          $User =  User::find($id);
      $User->delete() ; 
           
            return redirect('/volunteer')->with('success', 'Done successfully');

}
    
    }











// english form 
// titles panel
//****************************************
public function titles($language){
  if($language=="en")
$arr_titles=array (
'title_form'=>"Add Volunteer"
 ,
'title_panel_Group_Information'=>"Group Information"
 ,
 'title_panel_Personal_Information'=>"Personal Information"
,
'title_panel_Specialty_Information'=>"Specialty Information"
,
'title_panel_Address'=>"Address"
,
'title_panel_Means_of_communication'=>"Means of communication"
,
'title_panel_other_information'=>"other information"
,
'title_panel_Password'=>"Password"
,
'title_panel_Save_Changes'=>"Save Changes",
'title_panel_social_m'=>"Social Media Contact",
'language'=>"en"
);
   
return  $arr_titles;
}
//***************************************
public function form_items($language){
if($language=="en")
$arr=array(
    //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    //Group Information
'departments_id'=>"Department",
//Position select option in Group Information
//***
'Position'=>"Position",
'Position_Manager'=>"Manager",
'Position_Volunteer'=>"Volunteer",
//***
'Parent_Group'=>"Parent Group",
'Parent_Group_title'=>"Manager Name",
 //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//Personal Information
'Full_Name'=>"Full Name",
//Gender select option in Personal Information
//**
'Gender'=>"Gender",
'Gender_Male'=>"Male",
'Gender_Female'=>"Female",

//**
'Day_of_Birth'=>"Day of Birth",
 //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//Means of communication
'email'=>"E-Mail",
'Phone_Number1'=>"Phone Number 1",
'Phone_Number2'=>"Phone Number 2",
 //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//Specialty Information

'Acadimic_Achievement'=>"Acadimic Achievement",
// Acadimic_Achievement select option personal information
//***
//1
'Acadimic_Achievement_High_School'=>"High School",
//2
'Acadimic_Achievement_diploma'=>"diploma",
//3
'Acadimic_Achievement_Bachelor'=>"Bachelor",
//4
'Acadimic_Achievement_Master'=>"Master",
//5
'Acadimic_Achievement_Doctorate'=>"Doctorate",
//6
'Acadimic_Achievement_not'=>"Not Graduated",
//**
'Specialization'=>"Specialization",
'Experience'=>"Experience",


 //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//Address
'Address'=>"Address",
'Governorate'=>"Governorate",'Governorates'=>
//select Governorate option 
[
//1

'Al Anbar'=>"Al Anbar",
//2
'Babil'=>"Babil",
//3
'Baghdad'=>"Baghdad",
//4
'Basra'=>"Basra",
//5
'Dhi Qar'=>"Dhi Qar",
//6
'Al-Qadisiyyah'=>"Al-Qadisiyyah",
//7 
'Diyala'=>"Diyala",
//8 
'Dohuk'=>"Dohuk",
//9
'Erbil'=>"Erbil",
//10
'Karbala'=>"Karbala",
//11
'Kirkuk'=>"Kirkuk",
//12
'Maysan'=>"Maysan",
// 13
'Muthanna'=>"Muthanna",
//14
'Najaf'=>"Najaf",
//15
'Nineveh'=>"Nineveh",
//16
'Saladin'=>"Saladin",
//17
'Sulaymaniyah'=>"Sulaymaniyah",
//18
'Wasit'=>"Wasit"],
//****
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//other information
'Blood_Group'=>"Blood Group",
'New_Pecture'=>"New Pecture",
'Marital_Status'=>"Marital Status",
// select oprion Marital_Status
// ***
'Marital_Status_Married'=>"Married",
'Marital_Status_Not'=>"Not Married",
// ***
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//Passoword
'Password'=>"Password",
'Generate_Password'=>"Generate Password",
'save'=>"save",
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//social m
'facebook'=>"Facebook",
'Instagram'=>"Instagram",
'Twitter'=>"Twitter",
'new_pecture'=>"New Picrtrue"
);


return $arr;
}
//*************************************8888

}

