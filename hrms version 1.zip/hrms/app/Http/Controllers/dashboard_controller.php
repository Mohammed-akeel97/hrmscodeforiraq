<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class dashboard_controller extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(){
        $user = new get_msg_num();
        $user->get_number_msg();
        $trems=new treams_controller();
        if($trems->check_trems()==1){
            return view('hrm.dashboard.index');
        }
        else {
            return view('hrm.errors.tremas')
     ->with('error', 'You dont Have Treams,Manager');
        }

    }
}
