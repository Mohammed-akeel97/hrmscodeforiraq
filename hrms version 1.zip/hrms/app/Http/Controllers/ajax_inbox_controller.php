<?php

namespace App\Http\Controllers;
use App\Messages_inbox;
use App\Messages_inboxe_to;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use View;
class ajax_inbox_controller extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');

    }
  public  function read(Request $request){

$anc=Messages_inboxe_to::find($request->id);
 $anc->is_read=1;
 $anc->save();
   return view('hrm.Announcement.points.ajax.replay')->with('sec','ok');
    }
    //************************
public function get_num_msg_ajax(Request $request){
    $user = new get_msg_num();
    $user->get_number_msg();
    return view('hrm.Announcement.points.ajax.msg_num');
}
//********************************
public  function get_replay(Request $request){
   
    $replays= DB::table('messages_inboxes')
    ->select('*','messages_inboxes_replays.created_at as replay_at')
    ->join('messages_inboxes_replays', 'messages_inboxes_replays.messages_inboxes_id', '=', 'messages_inboxes.id')
    ->join('messages_inboxe_tos', 'messages_inboxe_tos.messages_inboxes_id', '=', 'messages_inboxes.id')
    ->join('postions', 'postions.id', '=', 'messages_inboxes_replays.replay_position_id')
    ->join('departments', 'departments.id', '=', 'messages_inboxes_replays.replay_department_id')
    ->where('messages_inboxes.id', '=', $request->id)
    ->orderBy('messages_inboxes_replays.created_at','DESC')->get();
       return view('hrm.Announcement.points.ajax.get_replays')->with('replays',$replays);
        }
}
