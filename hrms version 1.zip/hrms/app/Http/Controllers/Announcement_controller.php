<?php

namespace App\Http\Controllers;
use app\Http\ViewComposers;
use App\Messages_inbox;
use App\Messages_inboxe_to;
use App\Volunteer;
use App\Department;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Contracts\Auth\Authenticatable as Authenticatable;
use View;
class Announcement_controller extends Controller
{
     /**
     * Create a new controller instance.
     *
     * 
     * @return void
     */
    public function __construct()
    {
    
        $this->middleware('auth');
   
    }
 

    public function index(){
        // 
        $user = new get_msg_num();
        $user->get_number_msg();
        $get_depatment=Department::all();
        // get messages
       $received= DB::table('messages_inboxes')
       ->select('*','messages_inboxe_tos.id as id_message_to','messages_inboxe_tos.messages_inboxes_id as id_message','messages_inboxes.created_at as sent_at')
       ->join('postions', 'postions.id', '=', 'messages_inboxes.Positions_id')
       ->join('departments', 'departments.id', '=', 'messages_inboxes.departments_id')
       ->join('messages_inboxe_tos', 'messages_inboxe_tos.messages_inboxes_id', '=', 'messages_inboxes.id')      
       ->where('to_msg', '=',Auth::user()->email)->orderBy('messages_inboxes.created_at','DESC')->paginate(15);
     //******************
     
       $sent= DB::table('messages_inboxes')   
       ->select('*','messages_inboxe_tos.id as id_message_to','messages_inboxe_tos.messages_inboxes_id as id_message','messages_inboxes.created_at as sent_at')
       ->join('postions', 'postions.id', '=', 'messages_inboxes.Positions_id')
       ->join('departments', 'departments.id', '=', 'messages_inboxes.departments_id')
       ->join('messages_inboxe_tos', 'messages_inboxe_tos.messages_inboxes_id', '=', 'messages_inboxes.id')
      ->where('email_sender', '=',Auth::user()->email)->orderBy('messages_inboxes.created_at','DESC')->paginate(15);
      
      //***********************************************************
       $email= DB::table('volunteers')->select('volunteers.email','volunteers.Full_Name','departments.name_department','postions.name_postion')
       ->join('departments', 'departments.id', '=', 'volunteers.departments_id')
       ->join('postions', 'postions.id', '=', 'volunteers.Positions_id')
       ->orderBy('volunteers.departments_id','ASC')
       ->get();
       
       
       return view('hrm.Announcement.component_form')
       ->with('receiveds',$received)
       ->with('sents',$sent)
       ->with('emails',$email)
       ->with('get_depatment', $get_depatment);
    }


    public function store(Request $request)
    {
        if($request->has('To'))
        $this->validate($request ,[
            'To'=>'required|email',
            'title_message'=>'required',
            'full_message'=>'required',
           ]);
           else if($request->has('Department_send'))
           $this->validate($request ,[
            'Department_send'=>'required',
            'title_message'=>'required',
            'full_message'=>'required',
           ]);
           else 
           $this->validate($request ,[
            'title_message'=>'required',
            'full_message'=>'required',
           ]);







// get departments

$department_senders= DB::table('volunteers')
->select('departments.name_department','volunteers.parent_group','volunteers.Positions_id','volunteers.departments_id')
->join('departments', 'departments.id', '=', 'volunteers.departments_id')
->where('email', '=',Auth::user()->email)->get();
foreach ($department_senders as $sender )
$department_sender=$sender;




if($request->has('To'))
$department_receiveds= DB::table('volunteers')
->select('departments.name_department')
->join('departments', 'departments.id', '=', 'volunteers.departments_id')
->where('email', '=',$request->input('To'))->get();
elseif($request->has('Department_send'))
$department_receiveds= DB::table('departments')
->where('id', '=',$request->input('Department_send'))->get();
else {
    $department_receiveds= DB::table('volunteers')
    ->select('departments.name_department')
    ->join('departments', 'departments.id', '=', 'volunteers.departments_id')
    ->where('email', '=',Auth::user()->email)->get();
}






foreach ($department_receiveds as $sender )
$department_received=$sender;



$lastInsertId_messages= DB::table('messages_inboxes')
 ->select(DB::raw('MAX(messages_inboxes.id) as id'))->get();
foreach ($lastInsertId_messages as $Id_messages_insert )
$Id_messages=$Id_messages_insert->id;
if($Id_messages)
$Id_messages++;
else $Id_messages=1;
//***********************
           $Messages_inbox=new Messages_inbox();
  
           $Messages_inbox->id=$Id_messages;
            //2
            $Messages_inbox->title_message = $request->input('title_message');
             //3
           $Messages_inbox->full_message = $request->input('full_message');
               //4
               $Messages_inbox->name_sender = Auth::user()->name;
                      //5
           $Messages_inbox->email_sender = Auth::user()->email;
                  //6
                  $Messages_inbox->department_sender = $department_sender->name_department;
                  //7
                  
                  $Messages_inbox->department_received =$department_received->name_department;
             
                  //8
                 
                     //9
                     $Messages_inbox->Positions_id = $department_sender->Positions_id;
                        //10
                  $Messages_inbox->group_parent = $department_sender->parent_group;
                        //11
                        $Messages_inbox->departments_id = $department_sender->departments_id;
                          //12
                          if(!$request->has('To'))
                          if(empty($department_sender->parent_group))
                          $Messages_inbox->to_group_parent = Auth::user()->email;
                          else
                          $Messages_inbox->to_group_parent = $department_sender->parent_group;
           if( $Messages_inbox->save()){

           }else {
            $Id_messages++;
            $Messages_inbox->save();
           }

                  //********************************************8
        
//***********************

if($request->has('To'))
Announcement_controller::add_to_emails($request->input('To'),$Id_messages);
else if($request->has('Department_send')){
    $Department_send_emails =   Volunteer::select('email') 
    ->where('departments_id', '=',$request->input('Department_send'))
    ->where('email', '<>',Auth::user()->email)
    ->get();

    foreach($Department_send_emails as $Department_send_email){
        Announcement_controller::add_to_emails($Department_send_email->email,$Id_messages);
    }

}
else {



   if(empty($department_sender->parent_group))
   $group_p= Auth::user()->email;
   else
   $group_p = $department_sender->parent_group;

    $Department_send_emails =   Volunteer::select('email') 
    ->where('parent_group', '=', $group_p )
    ->get();
    foreach($Department_send_emails as $Department_send_email){
        Announcement_controller::add_to_emails($Department_send_email->email,$Id_messages);
    }
}



                  //

          
           return redirect('/announcement')->with('success', 'Send Message  Done successfully');
           

    }
    public function add_to_emails($to_email,$Id_messages){
        $Messages_inbox_to=new Messages_inboxe_to();
        $Messages_inbox_to->to_msg=$to_email;
        $Messages_inbox_to->messages_inboxes_id=$Id_messages;
        $Messages_inbox_to->is_read = 0;
        $Messages_inbox_to->save();
    }
     
}
