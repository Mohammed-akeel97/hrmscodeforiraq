<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class reports_controller extends Controller
{
    //

    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(){
        $user = new get_msg_num();
        $user->get_number_msg();
            return view('hrm.reports.index');
     

    }
}
