<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/




//*********************************************************************** Volunteer
// 
Route::get('/volunteer/search/results_search', 'Volunteer_controller@results_search');
Route::post('/volunteer/search/results_search', 'Volunteer_controller@results_search');
Route::get('/volunteer/edit_search', 'Volunteer_controller@edit_search');
Route::post('/volunteer/edit_search', 'Volunteer_controller@edit_search');
Route::get('/volunteer/search', 'Volunteer_controller@search');
    Route::resource('volunteer',"Volunteer_controller");


//******************************************************* project
//
Route::get('/project/search', 'project_controller@search');
Route::post('/project/search', 'project_controller@search');
Route::get('/project/edit_search', 'project_controller@edit_search');
Route::post('/project/edit_search', 'project_controller@edit_search');
Route::resource('/project',"project_controller");
//******************************************************* Announcement_controller
Route::resource('/announcement',"Announcement_controller");


//*******************************************************  Training 
// add 
Route::post('/training/edit_search', 'Training_controller@edit_search');
Route::get('/training/edit_search', 'Training_controller@edit_search');
Route::post('/training/search', 'Training_controller@search');
Route::get('/training/search', 'Training_controller@search');
Route::get('/training/edit', 'Training_controller@View');
Route::resource('/training',"Training_controller");
//***************************************

Route::resource('/user',"user_controller");

//******************* ajax inbox
Route::post('/read_announcement', 'ajax_inbox_controller@read');
Route::post('/get_replay', 'ajax_inbox_controller@get_replay');
Route::post('/num_messages', 'ajax_inbox_controller@get_num_msg_ajax');
Route::resource('/replay',"replay_message_controller");
Route::resource('/dashboard',"dashboard_controller");
Route::resource('/reports',"reports_controller");
Auth::routes();

Route::get('/', 'HomeController@index')->name('home');
Route::get('/home', 'HomeController@index')->name('home');

Route::get('get-file', 'CloudderController@getFile');
Route::post('upload-file', ['as'=>'upload-file','uses'=>'CloudderController@uploadFile']);