               <h3 class="headerSign" align="center"><?php echo e($title_panel_other_information); ?></h3>
                          <!-- *********************************************************************  -->
    <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($Blood_Group); ?><span style="color:red;font-size:18pt;">*</span></label>
                    <select class="form-control"  name="Blood_Group" >

                    <option value="" >AB +-ve</option>
                     <option value="" >A+-ve</option>
                    <option value="" >B+-ve</option>
                     <option value="" >O+-ve</option>
                    </select>
                    
                </div>
                           <!-- *********************************************************************  -->

    <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($Marital_Status); ?></label>
                    <select class="form-control"  name="Marital_Status" >

                    <option value="" ><?php echo e($Marital_Status_Married); ?></option>
                     <option value="" ><?php echo e($Marital_Status_Not); ?></option>
            
                    </select>
                    
                </div>
                <!-- *********************************************************************  --
                                                      <!-- *********************************************************************  -->

    <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($New_Pecture); ?><span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="file" accept="Image/*" name="Pecture" value="">

                    
                    
                </div>
                <!-- *********************************************************************  -->
            