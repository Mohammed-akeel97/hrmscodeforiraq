<?php $__env->startSection('form_reg'); ?>

<fieldset style="padding: 20px;"> 
<?php echo Form::open(['action' => ['Volunteer_controller@update',$get_volunteer->id], 'method'=>'POST','enctype'=>'multipart/form-data']); ?>


<?php echo e(csrf_field()); ?>




<?php if(session('success')): ?>
<div class="container">
<div class="row col-md-8 col-md-offset-2">
<div class="alert alert-success alert-success fade in">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
<strong>Success!</strong>  <?php echo e(session('success')); ?>.
</div>
</div>
</div>
<?php endif; ?>
<?php if(session('errors')): ?>
<div class="container">
<div class="row col-md-8 col-md-offset-2">
<div class="alert alert-success alert-danger fade in">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Danger!</strong> Not Successful  You Have Fileds.
  </div>
</div>
</div>
<?php endif; ?>
<link href="<?php echo e(asset('css/add.css')); ?>" rel="stylesheet">

	 <!--this was made my Agil Asadi. You are free to delete this comment line and use it as you wish-->   
<div class="container">

	<div class="row">
		<h2 class="headerSign" style="">Update Volunteer</h2>

	</div>
</div>
<div class="row col-md-8 col-ms-5 col-md-offset-2 registeration" style="z-index:100;background-color:rgba(255,255,255,0.8)">
    
<div class="registerInner">
<!-- ********************************  lift -->
        <div class="col-md-6 signUp">



<!-- ******************************* Group Information -->
<?php echo $__env->make('hrm.volunteer.Update.points.Group_Information', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- ******************************* Specialty Information -->
<?php echo $__env->make('hrm.volunteer.Update.points.Specialty_Information', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- ******************************* Means of communication -->
<?php echo $__env->make('hrm.volunteer.Update.points.Means_communication', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- ******************************* Social Media Contact-->
<?php echo $__env->make('hrm.volunteer.Update.points.social_m', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


 </div>
<!-- ********************************  right -->       
        <div class="col-md-6">
 <!-- ******************************* Personal Information-->

 <?php echo $__env->make('hrm.volunteer.Update.points.Personal_Information', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <!-- ******************************* Address-->
  <?php echo $__env->make('hrm.volunteer.Update.points.Address', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
<!-- ******************************* other  information-->

 <?php echo $__env->make('hrm.volunteer.Update.points.other_information', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- ******************************* Passowrd-->

           <?php echo $__env->make('hrm.volunteer.Update.points.Password', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>                                                <!-- *********************************************************************  -->

 
                    
           </div>
           <!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
                                    <!-- *********************************************************************  -->
           <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                           <h3 class="headerSign" align="center"><?php echo e($title_panel_Save_Changes); ?></h3>
                                     <!-- *********************************************************************  -->
            <div class="form-group"> 
            <?php echo e(Form::hidden('_method','PUT' )); ?>

                <?php echo e(Form::submit('save',['class'=>'signbuttons btn btn-primary pull-right' ] )); ?>

                          </div>  
                                     <br>
           <br>	
                                     <br>
           <br>		  
           <!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
                       
                   </div>
                        
           </div>
                  
           </div>
<?php echo Form::close(); ?>

</fieldset> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.general', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>