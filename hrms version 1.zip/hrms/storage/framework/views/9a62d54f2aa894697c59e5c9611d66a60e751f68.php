<!-- *************************  left ****************** -->
<?php $__env->startSection('form_reg'); ?>

 <link href="<?php echo e(asset('css/add.css')); ?>" rel="stylesheet">  


<?php echo Form::open(['action' => 'project_controller@store', 'method'=>'POST','enctype'=>'multipart/form-data']); ?>

	<fieldset style="padding: 20px;"> 
         <!--this was made my Agil Asadi. You are free to delete this comment line and use it as you wish-->   
<div class="container">
	<div class="row">
		<h2 class="headerSign" style="">Add Project</h2>

	</div>
</div>
<div class="row col-md-8 col-ms-5 col-md-offset-2 registeration" style="z-index:100;background-color:rgba(255,255,255,0.8)">
    
<div class="registerInner">
<!-- ********************************  lift -->
        <div class="col-md-6 signUp">

<!-- ********************************  Name & Description -->  
 <?php echo $__env->make('hrm.project.Add.points.Name_and_Description', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- ********************************  Requirement & Team  -->  
<?php echo $__env->make('hrm.project.Add.points.Requirement', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


 </div>
<!-- ********************************  right  -->       
        <div class="col-md-6">
        <!-- ********************************Start Date&Estimate Time-->  
<?php echo $__env->make('hrm.project.Add.points.Start_Date', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- ********************************Progress Rate Report -->  
 <?php echo $__env->make('hrm.project.Add.points.Report_project', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   

  <div class="row" >
 
 <div class="form-group" style="padding-top:130%;"> 

                <button type="submit" class="signbuttons btn btn-primary pull-right">Save</button>
   </div>
               </div>  
                    
                </div>
<!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
                         <!-- *********************************************************************  -->

                
              
                          <!-- *********************************************************************  -->

		  
<!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
            
        </div>
             
</div>
       
</div>
</fieldset> 
     
<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.general', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>