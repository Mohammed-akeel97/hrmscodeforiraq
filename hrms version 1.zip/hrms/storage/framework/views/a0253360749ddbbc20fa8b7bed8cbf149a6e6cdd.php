<?php echo Form::open(['action' => 'Announcement_controller@store', 'method'=>'POST','enctype'=>'multipart/form-data']); ?>


<div class="container">
             <?php
$departments_arr=array ();
foreach ($get_depatment as $depratment){
    $departments_arr[$depratment->id]=$depratment->name_department;
}

     ?>
  <!-- Modal -->
  <div class="modal fade " id="modal_send_deparments" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header color_panel">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Department Announcement</h4>
        </div>
        <div class="modal-body">
       <!-- body start -->
       
       <?php $vols=array(); ?>
       <?php $__currentLoopData = $emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vol_email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
       <?php 
       if($vol_email->email!=Auth::user()->email)
       $vols[$vol_email->email]=$vol_email->Full_Name." / ".$vol_email->email." / ".$vol_email->name_department." / ".$vol_email->name_postion;  ?>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       <!-- *********************************************************************  -->
                    <div class="form-group">                    
                                  <?php echo e(Form::label('Department_send', 'Department')); ?>

                             
                                      <?php echo e(Form::select('Department_send',$departments_arr,'',['class'=>'form-control','placeholder'=>'Department']
                  )); ?>

                                  </div>
                                  <?php if($errors->has('Department_send')): ?>
                                                      <span class="help-block" style="color:red;">
                                                          <strong><?php echo e($errors->first('Department_send')); ?></strong>
                                                      </span>
                                                  <?php endif; ?>
<!-- *********************************************************************  -->
<!-- *********************************************************************  -->
<div class="form-group">
                <?php echo e(Form::label('title_message', 'Title Message')); ?><span style="color:red;font-size:18pt;">*</span>
                <?php echo e(Form::text('title_message','',['class'=>'form-control','placeholder'=>'Title Message']  )); ?>

                <?php if($errors->has('title_message')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('title_message')); ?></strong>
                                    </span>
                                <?php endif; ?>
            </div>
<!-- *********************************************************************  -->
<!-- *********************************************************************  -->
<div class="form-group">
                <?php echo e(Form::label('full_message', 'Message')); ?><span style="color:red;font-size:18pt;">*</span>
                <?php echo e(Form::textarea('full_message','',['class'=>'form-control txt1','placeholder'=>'Message','id'=>'article-ckeditor']  )); ?>

                <?php if($errors->has('full_message')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('full_message')); ?></strong>
                                    </span>
                                <?php endif; ?>
            </div>
<!-- *********************************************************************  -->


       <!-- body end -->
        </div>
        <div class="modal-footer">
        <button type="submit" class="btn btn-default pull-right color_button" >Send</button>
       
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>
<?php echo Form::close(); ?>