<div class="container">
<?php echo Form::open(['action' => ['user_controller@update',Auth::user()->id], 'method'=>'POST','enctype'=>'multipart/form-data']); ?>


  <!-- Trigger the modal with a button -->
  <!-- Modal -->
  <div class="modal fade" id="modalchangepassword" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header color_panel">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h3 class="modal-title" align="center"><i class="glyphicon glyphicon-lock"></i> Change Password</h3>
        </div>
        <div class="modal-body">
        <?php echo $__env->make('hrm.user.points.modal_body', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       
        </div>
        <div class="modal-footer">
        <button type="submit" class="btn btn-default pull-right color_button" >Save Change</button>
        <?php echo e(Form::hidden('_method','PUT' )); ?>

          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  <?php echo Form::close(); ?>

</div>