    
         <h3 class="headerSign" align="center"><?php echo e($title_panel_Address); ?></h3>
                <!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^  -->

                <div class="form-group">                    

                     
                <?php echo e(Form::label($Governorate, $Governorate)); ?><span style="color:red;font-size:18pt;">*</span>
           
                    <?php echo e(Form::select('Governorate', [
                        'Governorate' => $Governorates,             ]
                        ,$get_volunteer->Governorate,['class'=>'form-control','placeholder'=>'Governorate',]
)); ?>

<?php if($errors->has('Governorate')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Governorate')); ?></strong>
                                    </span>
                                <?php endif; ?>
                </div>
         <!--***********************************  -->








                <!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^  -->
                          <!-- *********************************************************************  -->
    <div class="form-group">                    
                    <?php echo e(Form::label('Address', $Address)); ?><span style="color:red;font-size:18pt;">*</span>
                <?php echo e(Form::text('Address',$get_volunteer->Address,['class'=>'form-control','placeholder'=>$Address]  )); ?>

                <?php if($errors->has('Address')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Address')); ?></strong>
                                    </span>
                                <?php endif; ?>
                </div>
                                          <!-- *********************************************************************  -->
  

