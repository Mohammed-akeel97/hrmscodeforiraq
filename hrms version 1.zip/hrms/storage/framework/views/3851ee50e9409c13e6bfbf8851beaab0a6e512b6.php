         <h3 class="headerSign" align="center"><?php echo e($title_panel_Address); ?></h3>
                <!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^  -->





    <div class="form-group">                    
                <label class="cols-sm-2 control-label ">Governorate<span style="color:red;font-size:18pt;">*</span></label>
                    <select class="form-control"  name="Governorates" >
                    <!-- 1 -->
                    <option value="" ><?php echo e($Governorate_Anbar); ?></option>
                     <!-- 2 -->
                  <option value="" ><?php echo e($Governorate_Babil); ?></option>
                   <!-- 3 -->
                   <option value="" ><?php echo e($Governorate_Baghdad); ?></option>
                    <!-- 4 -->
                   <option value="" ><?php echo e($Governorate_Basra); ?></option>
                    <!-- 5 -->
                   <option value="" ><?php echo e($Governorate_Dhi_Qar); ?></option>
                    <!-- 6 -->
                   <option value="" ><?php echo e($Governorate_Qadisiyyah); ?></option>
                    <!-- 7 -->
                   <option value="" ><?php echo e($Governorate_Diyala); ?></option>
                    <!-- 8 -->
                   <option value="" ><?php echo e($Governorate_Dohuk); ?></option>
                    <!-- 9 -->
                   <option value="" ><?php echo e($Governorate_Erbil); ?></option>
                    <!-- 10 -->
                   <option value="" ><?php echo e($Governorate_Karbala); ?></option>
                    <!-- 11 -->
                   <option value="" ><?php echo e($Governorate_Kirkuk); ?></option>
                    <!-- 12 -->
                   <option value="" ><?php echo e($Governorate_Maysan); ?></option>
                    <!-- 13 -->
                   <option value="" ><?php echo e($Governorate_Muthanna); ?></option>
                    <!-- 14 -->
                   <option value="" ><?php echo e($Governorate_Najaf); ?></option>
                    <!-- 15 -->
                   <option value="" ><?php echo e($Governorate_Nineveh); ?></option>
                    <!-- 16 -->
                   <option value="" ><?php echo e($Governorate_Saladin); ?></option>
                    <!-- 17 -->
                   <option value="" ><?php echo e($Governorate_Sulaymaniyah); ?></option>
                    <!-- 18 -->
                   <option value="" ><?php echo e($Governorate_Wasit); ?></option>
                    </select>
                    
                </div>























                <!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^  -->
                          <!-- *********************************************************************  -->
    <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($Address); ?><span style="color:red;font-size:18pt;">*</span></label>
                       
                    <input class="form-control" type="text" name="Address" placeholder="<?php echo e($Address); ?>" value="">

                    
                </div>
                                          <!-- *********************************************************************  -->
  

