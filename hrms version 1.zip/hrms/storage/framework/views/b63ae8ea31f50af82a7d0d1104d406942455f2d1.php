<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
 <link rel="shortcut icon" href="<?php echo e(URL::to('/')); ?>/Images/logo_home.png" type="image/x-icon" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Code for iraq</title>

    <!-- Styles -->
             <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
                       <script type="text/javascript" src="<?php echo e(asset('bootstrap/jquery/jquery-3.2.1.min.js')); ?>"></script>
                                <script type="text/javascript" src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
                        
                             
      <link href="<?php echo e(asset('css/login.css')); ?>" rel="stylesheet">
      <link href="<?php echo e(asset('css/check_box.css')); ?>" rel="stylesheet">
             
    <style>
html,body{
     background-image:url("<?php echo e(URL::to('/')); ?>/Images/wp4.jpg");

}
</style>
</head>
<body>
    <div id="app">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
