 
 <?php $__env->startSection('from'); ?>

                 <!--***********************************  -->
<!-- *********************************************************************  -->

  <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">From</label>
                    <input class="form-control" type="text" name="from" hidden="true" disabled  placeholder="From" value="<?php echo e(Auth::user()->email); ?> ">
</div>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
  
    <?php $__env->stopSection(); ?>
     <?php $__env->startSection('to'); ?>

                 <!--***********************************  -->
 <!-- *********************************************************************  -->

  <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">To</label>
                    <input class="form-control" type="text" name="to" placeholder="To" value="">
</div>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
  
    <?php $__env->stopSection(); ?>



         <?php $__env->startSection('subject'); ?>

                 <!--***********************************  -->
 <!-- *********************************************************************  -->

  <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Subject</label>
                    <input class="form-control" type="text" name="subject" placeholder="Subject" value="">
</div>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
  
    <?php $__env->stopSection(); ?>



         <?php $__env->startSection('msg'); ?>

                 <!--***********************************  -->
 <!-- *********************************************************************  -->

  <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Type Message</label>
                    <textarea class="form-control"  name="msg" placeholder="Type Message ..." ></textarea>
</div>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
  
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Announcement.form_Announcement', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>