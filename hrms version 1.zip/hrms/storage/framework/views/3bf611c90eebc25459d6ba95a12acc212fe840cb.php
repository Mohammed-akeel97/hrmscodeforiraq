       <div class="list-group">
      <?php $i=0; ?>
      <?php if(count($sents)>0): ?>
<?php $__currentLoopData = $sents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

     <a  href="#modal_message_sent" onclick="modal_message_sent_fun(<?php echo e($i); ?>,<?php echo e($sent->id_message_to); ?>,<?php echo e($sent->id_message); ?>)"  data-toggle="modal" style="padding:20px 20px 20px 20px;" id="message_class_sent[<?php echo e($i); ?>]"   class="list-group-item <?php if(!$sent->is_read)echo 'read'; ?>">
                    
                           <span class="name" style="min-width: 120px;
                                display: inline-block;" id="message_sent_name_sender[<?php echo e($i); ?>]"><?php echo e($sent->name_sender); ?></span> <span class="" id="message_sent_title_message[<?php echo e($i); ?>]"><?php echo e($sent->title_message); ?></span>
                            <span class="text-muted" style="font-size: 11px;">-<span id="message_sent_department_sender[<?php echo e($i); ?>]"> <?php echo e($sent->department_sender); ?></span></span> <span class="badge" id="message_sent_created_at[<?php echo e($i); ?>]"><?php echo e($sent->sent_at); ?></span> <span class="pull-right">
                                </span>
                        <span style="display:none;" id="message_sent_full_message[<?php echo e($i); ?>]"><?php echo $sent->full_message; ?></span>        
                                    <span style="display:none;" id="message_sent_email_sender[<?php echo e($i); ?>]"><?php echo e($sent->email_sender); ?></span>
                                        <span style="display:none;" id="message_sent_department_received[<?php echo e($i); ?>]"><?php echo e($sent->department_received); ?></span>
                                           <span style="display:none;" id="is_sent[<?php echo e($i); ?>]"><?php echo e($sent->is_read); ?></span>
                              </a>
 <?php $i++; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>`
<?php else: ?> 
<br>
<br>
<h3 align="center">No Announcement Received</h3>
<?php endif; ?>
</div> 
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
     <?php echo e($sents->links()); ?>

          <?php echo $__env->make('hrm.Announcement.points.modals.modal_msg_sent.modal_msg_sent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            