                              <!--***********************************  -->
 <h3 class="headerSign" align="center"><?php echo e($title_panel_Specialty_Information); ?></h3>
 <!-- *********************************************************************  -->
 
    <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($Acadimic_Achievement); ?><span style="color:red;font-size:18pt;">*</span></label>
                    <select class="form-control"  name="Acadimic_Achievement" >

                    <option value="" ><?php echo e($Acadimic_Achievement_High_School); ?></option>
                     <option value="" ><?php echo e($Acadimic_Achievement_diploma); ?></option>
                   <option value="" ><?php echo e($Acadimic_Achievement_Bachelor); ?></option>
                     <option value="" ><?php echo e($Acadimic_Achievement_Master); ?></option>
                     <option value="" ><?php echo e($Acadimic_Achievement_Doctorate); ?></option>
                 <option value="" ><?php echo e($Acadimic_Achievement_not); ?></option>
                    </select>
                    
                </div>
                <!-- *********************************************************************  -->
 <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label "><?php echo e($Specialization); ?><span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="email" name="Specialization" placeholder="<?php echo e($Specialization); ?>" value="">
</div>
<!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label "><?php echo e($Experience); ?><span style="color:red;font-size:18pt;">*</span></label>
                    <textarea class="form-control" type="text" name="Experience" placeholder="<?php echo e($Experience); ?>"></textarea>
</div>
<!-- *********************************************************************  -->
