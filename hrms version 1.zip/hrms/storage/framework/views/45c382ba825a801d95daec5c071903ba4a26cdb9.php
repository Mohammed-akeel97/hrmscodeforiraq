<html lang="en"><head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex, nofollow">

    <title>Code For Iraq</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
      <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
       <script src="<?php echo e(asset('js/app.js')); ?>"></script>
           <link href="<?php echo e(asset('css/add.css')); ?>" rel="stylesheet">

</head>
<body style="zoom: 1;">
	 <!--this was made my Agil Asadi. You are free to delete this comment line and use it as you wish-->   
<div class="container">
	<div class="row">
		<h2 class="headerSign" style="">Volunteer</h2>

	</div>
</div>
<div class="row col-md-8 col-md-offset-2 registeration">
    
<div class="registerInner">
<!-- ********************************  lift -->
        <div class="col-md-6 signUp">


  <?php echo $__env->yieldContent('Group_Information'); ?>;

<?php echo $__env->yieldContent('Specialty_Information'); ?>;

<?php echo $__env->yieldContent('Means_communication'); ?>;

 </div>
<!-- ********************************  right -->       
        <div class="col-md-6">
 <?php echo $__env->yieldContent('Personal_Information'); ?>;
 <?php echo $__env->yieldContent('Address'); ?>;
   
   <?php echo $__env->yieldContent('other_information'); ?>;
                                                          <!-- *********************************************************************  -->
  
                <h3 class="headerSign" align="center">Passowrd</h3>
                          <!-- *********************************************************************  -->
    <div class="form-group">                    
                <label class="cols-sm-2 control-label ">Password<span style="color:red;font-size:18pt;">*</span></label>
                       
                    <input class="form-control" type="text" name="password" placeholder="Password" value="">

                    
                </div>
                  <div class="form-group">                    

                       
   <button  name="Generate_password" class="signbuttons btn btn-primary pull-right">Generate Password</button>
   <br>
                    
                </div>
<!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
                         <!-- *********************************************************************  -->
  <br>
                <h3 class="headerSign" align="center">Save Changes</h3>
                          <!-- *********************************************************************  -->
 <div class="col-md-13">
                <button type="submit" class="signbuttons btn btn-primary pull-right">Save</button>
   
               </div>  
<!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
            
        </div>
             
</div>
          </div> 


	<script type="text/javascript">
	
	</script>


</body></html>