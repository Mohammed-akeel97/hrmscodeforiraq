<!--<button type="button" data-toggle="modal" title="" data-original-title="Delete" aria-expanded="true"  data-target="#DeleteModal'.$id.'" class="btn btn-danger"><span class="glyphicon glyphicon-trash"
aria-hidden="true"></span></button>-->

<div class="modal fade" id="SearchModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header color_panel" style=" ">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h3 align="center"><i class="glyphicon glyphicon-search"></i> Search </h3>
</div>
<div class="modal-body">
<?php echo $__env->make('hrm.volunteer.Edit.points.modal_points.body_for_search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<div class="modal-footer">
<div>
<button type="submit" name="Delete" class="btn btn-info" >Search</button>
<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancel</button>
</div>
</div>
</div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- Modal -->

