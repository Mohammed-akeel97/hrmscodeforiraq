<script type="text/javascript" src="<?php echo e(asset('js/get_info.js')); ?>"></script>
<div class="col-md-3 col-xs-12 col-sm-6 col-lg-3">                       
<div class="container">
<script>
  var originalContents = document.body.innerHTML;
function print_modal(){
	var printContents = document.getElementById('modal_body').innerHTML;
       
         document.body.innerHTML = printContents;
         window.print();
         document.body.innerHTML = originalContents;
}
function PrintContent()
{
	var Documentbsp = document.getElementById('bsp');
var DocumentContainer = document.getElementById('modal_body');
var WindowObject = window.open("PrintWindow", "PrintWindow",
"width=750,height=650,top=50,left=50,toolbars=no,scrollbars=yes,status=no,resizable=yes");
WindowObject.document.writeln(Documentbsp.innerHTML);
WindowObject.document.writeln(DocumentContainer.innerHTML);
WindowObject.document.close();
setTimeout(function(){
    WindowObject.focus();
    WindowObject.print();
    WindowObject.close();
},1500);
}
</script>
<!-- line modal -->
<div class="modal fade" style="  transition: all 0.8s;" id="ShowModal1" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true" style="display: none;">
  
	<div class="modal-content" >
		<div class="modal-header color_panel">
			<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
			<h3 class="modal-title" align="center" id="lineModalLabel"><i class="glyphicon glyphicon-list-alt"></i>  Show All Information For Volunteer</h3>
			<div class="btn-group pull-right" role="group">
					<button type="button" onclick="PrintContent()" class="btn btn-info pull-right"  role="button" ><i class="glyphicon glyphicon-print"></i></button>
				</div>
        </div>
        
		<div class="modal-body" id="modal_body">
			
            <!-- content goes here -->
		<?php echo $__env->make('hrm.volunteer.Edit.points.modal_points.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
		<div class="modal-footer"> 

		
		<div class="btn-group btn-group-justified" role="group" aria-label="group button">
		
		<div class="btn-group" role="group">

					<button type="button" class="btn btn-default" data-dismiss="modal" role="button" >Close!</button>
				</div>
            </div>
       
		</div>
	</div>
  </div>

</div>
</div>