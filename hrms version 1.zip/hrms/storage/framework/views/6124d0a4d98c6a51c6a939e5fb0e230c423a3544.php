                     <h3 class="headerSign" align="center"><?php echo e($title_panel_Personal_Information); ?></h3>
           

      <!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
                <div class="form-group">
            <?php echo e(Form::label('Full_Name', $Full_Name)); ?><span style="color:red;font-size:18pt;">*</span>
                <?php echo e(Form::text('Full_Name',$get_volunteer->Full_Name,['class'=>'form-control','placeholder'=>$Full_Name]  )); ?>

                <?php if($errors->has('Full_Name')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Full_Name')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
<!-- *********************************************************************  -->

    <div class="form-group">                    
         
                    <?php echo e(Form::label('Gender', $Gender)); ?><span style="color:red;font-size:18pt;">*</span>
           
                    <?php echo e(Form::select('Gender', [
                        $Gender_Male => $Gender_Male,         $Gender_Female => $Gender_Female,          
   ],$get_volunteer->Gender,['class'=>'form-control','placeholder'=>$Gender,]
)); ?>

<?php if($errors->has('Gender')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Gender')); ?></strong>
                                    </span>
                                <?php endif; ?>
                </div>
                <!-- *********************************************************************  -->

    <div class="form-group">                    
                <?php echo e(Form::label('Day_of_Birth', $Day_of_Birth)); ?><span style="color:red;font-size:18pt;">*</span>
                <?php echo e(Form::date('Day_of_Birth',$get_volunteer->Day_of_Birth,['class'=>'form-control','placeholder'=>$Day_of_Birth]  )); ?>


                <?php if($errors->has('Day_of_Birth')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Day_of_Birth')); ?></strong>
                                    </span>
                                <?php endif; ?>
                </div>
                <!-- *********************************************************************  -->