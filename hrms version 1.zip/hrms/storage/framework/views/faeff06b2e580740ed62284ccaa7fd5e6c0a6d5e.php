<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

 <link rel="shortcut icon" href="<?php echo e(URL::to('/')); ?>/Images/logo_home.png" type="image/x-icon" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

<script>var host='<?php echo e(URL::to('/')); ?>';</script>
    <title>Code For Iraq</title>
    <div id="bsp">
       <script src="<?php echo e(URL::to('/')); ?>/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
           <script src="<?php echo e(URL::to('/')); ?>/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
    <script src="<?php echo e(URL::to('/')); ?>/vendor/unisharp/laravel-ckeditor/adapters/jquery.js"></script>
     <script src="<?php echo e(URL::to('/')); ?>/vendor/unisharp/laravel-ckeditor/styles.js"></script>
       <link rel="shortcut icon" href="<?php echo e(URL::to('/')); ?>/vendor/unisharp/laravel-ckeditor/contents.css" />
    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/Images/logo_home.png" type="image/x-icon" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
      <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
       <link href="<?php echo e(asset('css/check_box.css')); ?>" rel="stylesheet">
           <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
                       <script type="text/javascript" src="<?php echo e(asset('bootstrap/jquery/jquery-3.2.1.min.js')); ?>"></script>
                                <script type="text/javascript" src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
                                <script type="text/javascript" src="<?php echo e(asset('js/suport.js')); ?>"></script> 
                              
                                     <script type="text/javascript" src="<?php echo e(asset('push/bin/push.min.js')); ?>"></script>     
      <link href="<?php echo e(asset('css/nav_bar.css')); ?>" rel="stylesheet">
       <link href="<?php echo e(asset('css/footer.css')); ?>" rel="stylesheet">
       <link href="<?php echo e(asset('css/color_panel.css')); ?>" rel="stylesheet">
       <link href="<?php echo e(asset('css/button_style.css')); ?>" rel="stylesheet">
       <link href="<?php echo e(asset('css/input_style.css')); ?>" rel="stylesheet">
     </div>
     <script>
function announcement_noti() {
    Push.create('You Have New Announcement  HRMS', {
        body: 'Press To View New Announcement',
        icon: '<?php echo e(URL::to('/')); ?>/Images/announcement_icon.png',
    
       
        onClick: function () {
        
            window.focus();
         location.href="/announcement";
           this.close();
        },
        vibrate: [200, 100, 200, 100, 200, 100, 200]
    });
}



     </script>
           <style>
           html,body{
               background-image:url("<?php echo e(URL::to('/')); ?>/Images/bg_photo_hrms.png");
               
           }
           </style>
<?php echo $__env->make('includes.nav_bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>

<body style="zoom: 1;">

<?php if(session('success')): ?>
<div class="container">
<div class="row col-md-8 col-md-offset-2">
<div class="alert alert-success alert-success fade in">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
<strong>Success!</strong>  <?php echo e(session('success')); ?>.
</div>
</div>
</div>
<?php endif; ?>
<?php if(session('errors')): ?>
<div class="container">
<div class="row col-md-8 col-md-offset-2">
<div class="alert alert-success alert-danger fade in">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Danger!</strong> Not Successful  You Have Fileds.
  </div>
</div>
</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="container">
<div class="row col-md-8 col-md-offset-2">
<div class="alert alert-success alert-danger fade in">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Danger!</strong>  <?php echo e(session('error')); ?>.
  </div>
</div>
</div>
<?php endif; ?>

<?php echo $__env->yieldContent('form_reg'); ?>
<?php echo $__env->yieldContent('home'); ?>
<?php echo $__env->yieldContent('panel_edit'); ?>
<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</body>
  <script>
        CKEDITOR.replace( 'article-ckeditor' );
    </script>
</html>