
                        
<div class="panel-body table-responsive">
<?php if(count($Projects) >0): ?>
<?php  $i=1; ?>
          <?php $__currentLoopData = $Projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class=" col-md-3">
<ul class="eight">
  <li class="transition">
    <div class="wrapper" > <span class="transition" >
      <h3 class="transition"><?php echo e($Project->Project_Name); ?><em><?php echo e($Project->Project_Start_Date); ?></em></h3>
     <span id="Project_Name[<?php echo e($i); ?>]" style="display:none;"><?php echo e($Project->Project_Name); ?></span>
     
      <span id="Project_Start_Date[<?php echo e($i); ?>]" style="display:none;"><?php echo e($Project->Project_Start_Date); ?></span>
      <span id="Training_Place[<?php echo e($i); ?>]" style="display:none;"><?php echo e($Project->Training_Place); ?></span>
      <span id="Training_Start_Date[<?php echo e($i); ?>]" style="display:none;"><?php echo e($Project->Training_Start_Date); ?></span>
      <span id="Estimate_Project_Time[<?php echo e($i); ?>]" style="display:none;"><?php echo e($Project->Estimate_Project_Time); ?></span>

 <span style="display:none;" id="Project_Description[<?php echo e($i); ?>]">  <?php echo $Project->Project_Description; ?> </span>
 <span style="display:none;" id="Project_Report[<?php echo e($i); ?>]">  <?php echo $Project->Project_Report; ?> </span>
              <span style="display:none;" id="Project_Requirement[<?php echo e($i); ?>]">  <?php echo $Project->Project_Requirement; ?> </span>

              <span style="display:none;" id="Project_Provider[<?php echo e($i); ?>]"> <?php echo e($Project->Project_Provider); ?> </span>
           
            <span style="display:none;" id="Team_Responsible[<?php echo e($i); ?>]">  <?php echo e($Project->Team_Responsible); ?> </span>




      <div class="image-container transition">
        <div class="creation" >
          <div class="front" >
            <div class="cont" > <i class="details"><img width="100" class="icon-circle transition" src="<?php echo e(URL::to('/')); ?>/Images/project-icon.png" ></img> </div>
          </div>
          <div class="back">
            <div class="cont" > <i class="details"><img width="100" src="<?php echo e(URL::to('/')); ?>/Images/vinger.png"  ></img> </div>
          </div>
        </div>
      </div>
      </span>
      <ul class="social transition" align="center" style="margin-left:36%;">
        <li class="transition"><button onclick="get_info_project(<?php echo e($i); ?>)" data-toggle="modal" data-target="#trainModal" class="btn btn-info center-block"><i class="glyphicon glyphicon-list-alt"></i> View</button></li>
   </ul>
      <div class="arrow"></div>
    </div>
  </li>

</ul>
</div>
<?php  $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?> 
<p colspan="7" style="text-align:center;"><br><br><strong>No Results</strong><br><br></p>      
<?php endif; ?>
</div>