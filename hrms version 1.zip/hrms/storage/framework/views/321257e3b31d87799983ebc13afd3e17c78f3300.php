    

            


<?php $__env->startSection('panel_edit'); ?>
<?php echo $__env->make('hrm.volunteer.Edit.points.delete_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<link href="<?php echo e(asset('css/add.css')); ?>" rel="stylesheet">  
<div class="col-md-12">
 <div class="container-fluid">
    <div class="panel panel-info" style="font-size:16;">
    <div class="panel-heading color_panel" style="color:white;">
       <?php echo $__env->make('hrm.volunteer.Edit.points.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
 
 <?php echo $__env->make('hrm.volunteer.Edit.points.table', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <?php echo $__env->make('hrm.volunteer.Edit.points.modal_show', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <div class="panel-footer">
        <div class="row ">
          <div class="col-lg-12 pull-righ">
            <div class="col-md-12">
            <?php if(count($Volunteers) >0): ?>
            <?php echo e($Volunteers->links()); ?>

            <?php endif; ?>
              </div>
              <div class="col-md-12">
              <p class="muted pull-right"><strong> © 2017 All rights reserved Code For Iraq </strong></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.general', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>