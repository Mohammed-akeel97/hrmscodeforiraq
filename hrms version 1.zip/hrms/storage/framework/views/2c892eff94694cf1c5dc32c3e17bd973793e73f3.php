<div class="row">
    
<fieldset style="padding: 20px;"> 

<div class="row col-md-12 col-ms-12 col-md-offset-0 form_style" >
<!-- *********************************************************************  -->
<div class="form-group">
                <?php echo e(Form::label('Previous_Password',  'Previous Password')); ?><span style="color:red;font-size:18pt;">*</span>
                <?php echo e(Form::text('Previous_Password','',['class'=>'form-control style_input','placeholder'=>'Previous Password']  )); ?>

                <?php if($errors->has('Previous_Password')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Previous_Password')); ?></strong>
                                    </span> 
                                <?php endif; ?>
                                         <?php if(session('Previous_Password')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e(session('Previous_Password')); ?></strong>
                                    </span> 
                                <?php endif; ?>
            </div>
<!-- *********************************************************************  -->
                      <div class="form-group ">
                            <label for="password">Password</label><span style="color:red;font-size:18pt;">*</span>

                            <div class="">
                                <input id="password" type="password" placeholder="Password" class="form-control style_input" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
<!-- *********************************************************************  -->

                        <div class="form-group ">
                            <label for="password-confirm" class="">Confirm Password</label><span style="color:red;font-size:18pt;">*</span>

                            <div class="">
                                <input id="password-confirm" placeholder="Confirm Password" type="password" class="form-control style_input" name="password_confirmation" required>
                            </div>
                        </div>
<!-- *********************************************************************  -->
<button id="show_password" type="button" onclick="show_password_action()" value="0" class="btn btn-default color_button pull-right"><i id="icon_show_password" class="glyphicon glyphicon-eye-open"></i></button>
<br><br>
</div>

</fieldset> 

</div>
