<html lang="en"><head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex, nofollow">

    <title>Code For Iraq</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
      <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
           <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
                       <script type="text/javascript" src="<?php echo e(asset('bootstrap/jquery/jquery-1.10.2.min.js')); ?>"></script>
                                <script type="text/javascript" src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
                        
      <link href="<?php echo e(asset('css/nav_bar.css')); ?>" rel="stylesheet">
       <link href="<?php echo e(asset('css/footer.css')); ?>" rel="stylesheet">
       <script src="<?php echo e(asset('js/app.js')); ?>"></script>
           <style>
           html,body{
               background-image:url("../rsz_coiraq3.png");
           }
           </style>
<?php echo $__env->yieldContent('nav_bar'); ?>;
</head>
<body style="zoom: 1;">
<?php echo $__env->yieldContent('form_reg'); ?>
<?php echo $__env->yieldContent('home'); ?>
<?php echo $__env->yieldContent('panel_edit'); ?>
<?php echo $__env->yieldContent('footer'); ?>


</body>

</html>