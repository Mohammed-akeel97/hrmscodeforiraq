<!-- *******************************  -->


     <h3 class="headerSign">Name & Description</h3>
     <!-- *******************************  -->
      <!-- *********************************************************************  -->
       <div class="form-group">
        <?php echo e(Form::label('Project Name', 'Project Name')); ?><span style="color:red;font-size:18pt;">*</span>
        <?php echo e(Form::text('Project_Name','',['class'=>'form-control ','placeholder'=>'Project Name']  )); ?>

            <?php if($errors->has('Project_Name')): ?>
                <span class="help-block" style="color:red;">
                <strong><?php echo e($errors->first('Project_Name')); ?></strong>
                </span>
             <?php endif; ?>
      
        </div>
     
<!-- *********************************************************************  -->
     <!-- *********************************************************************  -->
         <div class="form-group">
        <?php echo e(Form::label('Description', 'Project Description')); ?><span style="color:red;font-size:18pt;">*</span>
        <?php echo e(Form::textarea('Project_Description','',['class'=>'form-control ','placeholder'=>'Project Description','id'=>'article-ckeditor']  )); ?>

            <?php if($errors->has('Project_Description')): ?>
                <span class="help-block" style="color:red;">
                <strong><?php echo e($errors->first('Project_Description')); ?></strong>
                </span>
             <?php endif; ?>
        </div>
          <script>

      CKEDITOR.replace( 'article-ckeditor' );
  </script>
     
<!-- *********************************************************************  -->
    
         <!--***********************************  -->