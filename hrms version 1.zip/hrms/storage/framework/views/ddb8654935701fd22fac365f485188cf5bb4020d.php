          
          
                 <!--***********************************  -->
 <h3 class="headerSign" align="center">Start Date&Estimate  Time</h3>
 <!-- *********************************************************************  -->

  <!-- *********************************************************************  -->
                <div class="form-group">
                <?php echo e(Form::label('Project Start Date', 'Project Start Date')); ?><span style="color:red;font-size:18pt;">*</span>
                <?php echo e(Form::date('Project_Start_Date','',['class'=>'form-control','placeholder'=>'Project Start Date']  )); ?>

                <?php if($errors->has('Project_Start_Date')): ?>
                <span class="help-block" style="color:red;">
                <strong><?php echo e($errors->first('Project_Start_Date')); ?></strong>
                </span>
                <?php endif; ?>
                </div>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
  
                  <!-- *********************************************************************  -->
                <div class="form-group">
                <?php echo e(Form::label('Estimate Project Time', 'Estimate Project Time')); ?><span style="color:red;font-size:18pt;">*</span>
                <?php echo e(Form::date('Estimate_Project_Time','',['class'=>'form-control','placeholder'=>'Estimate Project Time']  )); ?>

                <?php if($errors->has('Estimate_Project_Time')): ?>
                <span class="help-block" style="color:red;">
                <strong><?php echo e($errors->first('Estimate_Project_Time')); ?></strong>
                </span>
                <?php endif; ?>
                </div>
<!-- *********************************************************************  -->
 

   