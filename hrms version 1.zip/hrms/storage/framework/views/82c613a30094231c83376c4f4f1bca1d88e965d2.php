 <div class="row">
          <div class=" col-md-12">
            <h2 class="text-center pull-left" style="padding-left: 30px;"> <span class="glyphicon glyphicon-list-alt"> </span> View Projects </h2>
          </div>
          <div class=" col-md-12">
            <div class=" col-md-12">
              <div class=" col-md-12">
                
                <!-- *************************  -->
                <!-- *************************  -->
                <div class=" col-md-4 pull-right">
                <?php echo Form::open(['action' =>[ 'project_controller@search'], 'method'=>'POST','enctype'=>'multipart/form-data']); ?>

    
                    <div class="form-group">
                    <label> Search </label>
                      <div class="input-group">
            <?php echo e(Form::text('Project_Name_search','',['class'=>'form-control','placeholder'=>'Project Name']  )); ?>

                  <div class="input-group-btn">
                          <button type="submit" class="btn btn-md btn-info"> <span class=" glyphicon glyphicon-search"></span></button>
                    
                        </div>
    
                      </div>
                      </div>
                      <?php echo Form::close(); ?>

                      </div>
                       <!-- *************************  -->
                   <!-- *************************  -->

                 <!-- *************************  -->

                 <!-- *************************  -->
              </div>
            </div>
          </div>
        </div>