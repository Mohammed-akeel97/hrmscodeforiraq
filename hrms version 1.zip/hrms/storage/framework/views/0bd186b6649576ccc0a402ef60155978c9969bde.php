 <div class="row">
          <div class=" col-md-12">
            <h2 class="pull-left" > <span class="glyphicon glyphicon-list-alt"> </span> Edit Volunteers </h2>
          </div>
          <div class=" col-md-12">
            <div class=" col-md-12">
              <div class=" col-md-12">
              <!-- Modal -->
              <?php echo Form::open(['action' => ['Volunteer_controller@edit_search'], 'method'=>'POST']); ?>

 
<a class="btn btn-info  pull-right" href="#SearchModal" data-toggle="modal" title="" data-original-title="Search" aria-expanded="true">  <i class="glyphicon glyphicon-search"></i>  Search</a> 
<!-- Modal -->
              <?php echo $__env->make('hrm.volunteer.Edit.points.modal_search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <?php echo Form::close(); ?>

              </div>
            </div>
       
            </div>
            </div>
     