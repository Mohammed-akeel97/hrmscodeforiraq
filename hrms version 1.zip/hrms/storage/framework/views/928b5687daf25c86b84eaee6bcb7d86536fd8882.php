<?php $__env->startSection('footer'); ?>
<style type="text/css">


</style>

<br>
<br>
<!-- Start footer -->
<div class="col-md-12 col-md-offset-0"  >
    <footer class="footer-bs">
        <div class="row">
        	<div class="col-md-3 footer-brand animated fadeInLeft">
            	<h2>Code For Iraq</h2>
            <p class="copy">© 2017 Code For Iraq CDI, All rights reserved</p>
            </div>
        	<div class="col-md-4 footer-nav animated fadeInUp">
            	<h4>Menu —</h4>
            	<div class="col-md-6">
                    <ul class="pages">
                        <li><a href="#">Volunteer</a></li>
                        <li><a href="#">Project</a></li>
                        <li><a href="#">Training</a></li>
                        <li><a href="#">Announcement</a></li>
                        <li><a href="#">Reports</a></li>
                    </ul>
                </div>
            	<div class="col-md-6">
                    <ul class="list">
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Contacts</a></li>
                        <li><a href="#">Terms &amp; Condition</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>
        	<div class="col-md-2 footer-social animated fadeInDown">
           
            	<ul>
                	<li><a href="#">Facebook</a></li>
                	<li><a href="#">Twitter</a></li>
                	<li><a href="#">Instagram</a></li>
                	<li><a href="#">RSS</a></li>
                </ul>
            </div>
        	<div class="col-md-3 footer-ns animated fadeInRight">
             <p>
                    </p><div class="input-group">
                   <span class="input-group-btn">
                    </span>
                    </div><!-- /input-group -->
                 <p></p>
            </div>
        </div>
    </footer>
    </div>
<?php $__env->stopSection(); ?>