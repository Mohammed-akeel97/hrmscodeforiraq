        
        
                               <!--***********************************  -->
 <h3 class="headerSign" align="center">Requirement & Team</h3>
<!-- *********************************************************************  -->
                <div class="form-group">
                <?php echo e(Form::label('Project Requirement', 'Project Requirement')); ?><span style="color:red;font-size:18pt;">*</span>
                <?php echo e(Form::textarea('Project_Requirement','',['class'=>'form-control ','placeholder'=>'Project Requirement','id'=>'txt2']  )); ?>

                <?php if($errors->has('Project_Requirement')): ?>
                <span class="help-block" style="color:red;">
                <strong><?php echo e($errors->first('Project_Requirement')); ?></strong>
                </span>
                <?php endif; ?>
                </div>
                <script>
     document.getElementById('article-ckeditor').id="none";
      document.getElementById('txt2').id="article-ckeditor";
        CKEDITOR.replace('article-ckeditor' );
       document.getElementById('article-ckeditor').id="txt2";
      
                </script>
<!-- *********************************************************************  -->
<!-- *********************************************************************  -->
                <div class="form-group">
                <?php echo e(Form::label('Project Provider', 'Project Provider')); ?><span style="color:red;font-size:18pt;">*</span>
                <?php echo e(Form::text('Project_Provider','',['class'=>'form-control','placeholder'=>'Project Provider']  )); ?>

                <?php if($errors->has('Project_Provider')): ?>
                <span class="help-block" style="color:red;">
                <strong><?php echo e($errors->first('Project_Provider')); ?></strong>
                </span>
                <?php endif; ?>
                </div>
<!-- *********************************************************************  -->
       <!-- *********************************************************************  -->
                <div class="form-group">
                <?php echo e(Form::label('Team Responsible for the Project', 'Team Responsible')); ?><span style="color:red;font-size:18pt;">*</span>
                <?php echo e(Form::text('Team_Responsible','',['class'=>'form-control','placeholder'=>'Team Responsible for the Project']  )); ?>

                <?php if($errors->has('Team_Responsible')): ?>
                <span class="help-block" style="color:red;">
                <strong><?php echo e($errors->first('Team_Responsible')); ?></strong>
                </span>
                <?php endif; ?>
                </div>
<!-- *********************************************************************  -->
 