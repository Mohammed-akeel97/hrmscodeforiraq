<!-- *************************  left ****************** -->
<?php $__env->startSection('form_reg'); ?>
<form action="" method="POST">
	 <!--this was made my Agil Asadi. You are free to delete this comment line and use it as you wish-->   
<div class="container">
	<div class="row">
		<h2 class="headerSign" style="">Add Project</h2>

	</div>
</div>
<div class="row col-md-8 col-ms-5 col-md-offset-2 registeration" style="z-index:100;background-color:rgba(255,255,255,0.8)">
    
<div class="registerInner">
<!-- ********************************  lift -->
        <div class="col-md-6 signUp">


  <?php echo $__env->yieldContent('Name_and_Description'); ?>

<?php echo $__env->yieldContent('Requirement'); ?>


 </div>
<!-- ********************************  right -->       
        <div class="col-md-6">
 <?php echo $__env->yieldContent('Start_Date'); ?>
 <?php echo $__env->yieldContent('Report_project'); ?>
   

 
                    
                </div>
<!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
                         <!-- *********************************************************************  -->

                
                <br>  <br>  <br>  <br>  <br>
                          <!-- *********************************************************************  -->
 <div class="form-group"> 
                <button type="submit" class="signbuttons btn btn-primary pull-right">Save</button>
   
               </div>  
			  <br>
<br>	
			  <br>
<br>		  
<!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
            
        </div>
             
</div>
       
</div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.nav_bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.general', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>