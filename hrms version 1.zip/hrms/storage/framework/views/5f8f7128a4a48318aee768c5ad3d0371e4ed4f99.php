<!-- *************************  left ****************** -->
<?php $__env->startSection('nav_bar'); ?>

<!--*********************** Start Navbar *************** -->



<header>
<div class="top_bar">
<div class="container">
<div class="col-md-6">
<ul class="social">
<!-- <li><a target="_blank" href="https://facebook.com"><i class="fa fa-facebook text-white"></i></a></li>
<li><a target="_blank" href="https://twitter.com"><i class="fa fa-twitter text-white"></i></a></li>
<li><a target="_blank" href="http://instagram.com"><i class="fa fa-instagram text-white"></i></a></li> -->
</ul></div>

<div class="col-md-6">
<ul class="rightc">
<li><i class="fa fa-envelope-o"></i> <?php echo e(Auth::user()->email); ?> </li>
<li><i class="fa fa-user"></i> <a href="#"><?php echo e(Auth::user()->name); ?></a></li>      
</ul>
</div>
</div>
</div>
<!--top_bar-->



<nav class="navbar navbar-default" role="navigation">
    	<div class="container">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="#"><img src=""> 

				</a>
				<a  class="navbar-brand"  href="/home"><span>&lt;IRAQ/&gt;</span></a>
			</div>

			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="color: #30bed6;">
				
				
				<ul class="nav navbar-nav navbar-right" style="">
				
			<li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Volunteer <b class="caret"></b></a>
            <ul class="dropdown-menu">
     <li><a href="/volunteer/create">Add Volunteer</a></li>
							<li><a href="/volunteer">Edit Volunteer</a></li>
						
							<li class="divider"></li>
							<li><a href="/volunteer/search">Search Volunteer</a></li>
            </ul>
          </li>  


				   <!-- ******************************8 -->
			<li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Project <b class="caret"></b></a>
            <ul class="dropdown-menu">
      	<li><a href="/project/create">Add Project</a></li>
	<li><a href="/project">Edit Project</a></li>
						
	<li class="divider"></li>
	<li><a href="/project/search">Search Project</a></li>
            </ul>
          </li>   
                  					 <!-- ******************************88  -->

		<li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Training <b class="caret"></b></a>
            <ul class="dropdown-menu">
     <li><a href="/training/create">Add Training</a></li>
							
							
							<li><a href="/training/edit">Edit Training</a></li>
							<li class="divider"></li>
							<li><a href="/training">View Training</a></li>
            </ul>
          </li>  

 <!-- ******************************88  --> 
                    <li><a href="/announcement">   Announcement </a></li>





                   


                    <li><a href="#">   Reports</a></li>
			      <li>
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
				</ul>

			</div><!-- /.navbar-collapse -->
		</div><!-- /.container-fluid -->
	</nav>
   
</header>

<!--*********************** End Navbar ***************/ -->
<?php $__env->stopSection(); ?>

