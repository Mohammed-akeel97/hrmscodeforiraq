<?php $__env->startSection('home'); ?>
<div>
<h1 align="center">Welcome To Code For iraq</h1>
<h3 align="center">HRMS</h3>
<div class="col-md-2 col-md-offset-4"  align="center" style="">
<img src="<?php echo e(URL::to('/')); ?>/Images/logo_home.png"/>

</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.general', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>