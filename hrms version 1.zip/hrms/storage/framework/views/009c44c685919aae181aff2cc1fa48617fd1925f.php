<div class="container">
<?php echo Form::open(['action' => 'replay_message_controller@store', 'method'=>'POST','enctype'=>'multipart/form-data']); ?>

<?php echo e(csrf_field()); ?>

  

  <!-- Modal -->
  <div class="modal fade" id="modal_read_message_received" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header color_panel">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><span class="glyphicon glyphicon-comment"></span> View A Received Announcement</h4>
        </div>
        <div class="modal-body">
                            <?php echo $__env->make('hrm.Announcement.points.modals.modal_read_msg_received.modal_read_msg_received_body', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="modal-footer">
       
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
          <?php echo Form::close(); ?>

</div>