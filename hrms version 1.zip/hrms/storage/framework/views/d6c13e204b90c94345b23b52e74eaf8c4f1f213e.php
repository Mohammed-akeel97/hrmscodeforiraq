<?php echo Form::open(['action' => 'Announcement_controller@store', 'method'=>'POST','enctype'=>'multipart/form-data']); ?>


<div class="container">


  <!-- Modal -->
  <div class="modal fade " id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header color_panel">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Individual Announcement</h4>
        </div>
        <div class="modal-body">
       <!-- body start -->
       
       <?php $vols=array(); ?>
       <?php $__currentLoopData = $emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vol_email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
       <?php 
       if($vol_email->email!=Auth::user()->email)
       $vols[$vol_email->email]=$vol_email->Full_Name." / ".$vol_email->email." / ".$vol_email->name_department." / ".$vol_email->name_postion;  ?>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       <!-- *********************************************************************  -->
       <div class="form-group">
                <?php echo e(Form::label('To', 'To')); ?><span style="color:red;font-size:18pt;">*</span>
                
                                        <?php echo e(Form::select('To', [
                        'All' => $vols,             ]
                        ,'',['class'=>'form-control','placeholder'=>'All',]
)); ?>

                <?php if($errors->has('To')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('To')); ?></strong>
                                    </span>
                                <?php endif; ?>
            </div>
<!-- *********************************************************************  -->
<!-- *********************************************************************  -->
<div class="form-group">
                <?php echo e(Form::label('title_message', 'Title Message')); ?><span style="color:red;font-size:18pt;">*</span>
                <?php echo e(Form::text('title_message','',['class'=>'form-control','placeholder'=>'Title Message']  )); ?>

                <?php if($errors->has('title_message')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('title_message')); ?></strong>
                                    </span>
                                <?php endif; ?>
            </div>
<!-- *********************************************************************  -->
<!-- *********************************************************************  -->
<div class="form-group">
                <?php echo e(Form::label('full_message', 'Message')); ?><span style="color:red;font-size:18pt;">*</span>
                <?php echo e(Form::textarea('full_message','',['class'=>'form-control txt3','placeholder'=>'Message','id'=>'article-ckeditor']  )); ?>

                <?php if($errors->has('full_message')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('full_message')); ?></strong>
                                    </span>
                                <?php endif; ?>
            </div>
<!-- *********************************************************************  -->


       <!-- body end -->
        </div>
        <div class="modal-footer">
        <button type="submit" class="btn btn-default pull-right color_button" >Send</button>
       
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>
<?php echo Form::close(); ?>