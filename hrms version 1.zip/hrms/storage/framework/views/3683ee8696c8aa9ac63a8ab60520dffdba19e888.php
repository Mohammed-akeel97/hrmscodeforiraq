 <h3 class="headerSign">Training Place & Date Start</h3>
     
                 <!--***********************************  -->
 <!-- *********************************************************************  -->

  <!-- *********************************************************************  -->
                <div class="form-group">
       
                    <?php echo e(Form::label('Training_Place','Training Place')); ?><span style="color:red;font-size:18pt;">*</span>
                <?php echo e(Form::text('Training_Place','',['class'=>'form-control','placeholder'=>'Training Place']  )); ?>

                <?php if($errors->has('Training_Place')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Trainer_Name')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
<!-- *********************************************************************  -->
  <!-- *********************************************************************  -->
                <div class="form-group">
   <?php echo e(Form::label('Training_Start_Date','Training Start Date')); ?><span style="color:red;font-size:18pt;">*</span>
                <?php echo e(Form::date('Training_Start_Date','',['class'=>'form-control','placeholder'=>'Training Start Date']  )); ?>

                <?php if($errors->has('Training_Start_Date')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Training_Start_Date')); ?></strong>
                                    </span>
                                <?php endif; ?>

</div>
<!-- *********************************************************************  -->
  <!-- *********************************************************************  -->
  <div class="form-group">
   <?php echo e(Form::label('Training_End_Date','Training End Date')); ?><span style="color:red;font-size:18pt;">*</span>
                <?php echo e(Form::date('Training_End_Date','',['class'=>'form-control','placeholder'=>'Training Start Date']  )); ?>

                <?php if($errors->has('Training_End_Date')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Training_End_Date')); ?></strong>
                                    </span>
                                <?php endif; ?>

</div>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
  