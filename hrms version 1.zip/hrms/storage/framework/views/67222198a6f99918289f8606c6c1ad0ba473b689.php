<html><head>
                                <meta charset="utf-8">
                                <meta name="viewport" content="width=device-width, initial-scale=1">
                                <title>Snippet - Bootsnipp.com</title>
                                <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet">
                                <style> .panel
        {
          margin: 5%;
          background: transparent;
        }


        tr
        {
          transition: all 0.5s;
        }
        tr:hover
        {
          background-color: #f0ad4e;
          transition: 0.5s;
        }
        .btn-warning
        {
          transition: all 0.8s;
        }

        .btn-warning:hover, .btn-warning:focus
        {
          transition: 0.8s;
          background-color: #428bca;
          border-color: #428bca;
        }

        .panel-footer
        {
          background-color: #5bc0de;
          color: white;
        }</style>
                                <script type="text/javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
                                <script type="text/javascript" src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
                                <script type="text/javascript">  $(document).ready(function(){
      $(".form-control").popover({title: "", placement: "top"});
     })</script>
                            </head>
                            <body style="">
                            <div class="container-fluid">
    <div class="panel panel-info">
      <div class="panel-heading">
        <div class="row">
          <div class=" col-md-12">
            <h2 class="text-center pull-left" style="padding-left: 30px;"> <span class="glyphicon glyphicon-list-alt"> </span> Edit Volunteers </h2>
          </div>
          <div class=" col-md-12">
            <div class=" col-md-12">
              <div class=" col-md-12">
                
                <!-- *************************  -->
            <div class=" col-md-4 pull-right">
                
                <div class="form-group">
                <label> Search </label>
                  <div class="input-group">

                    <input type="text" class="form-control input-md" name="Volunteer_Name" data-original-title="" placeholder="Name Volunteer" title="">
                    <div class="input-group-btn">
                      <button type="button" class="btn btn-md btn-warning"> <span class=" glyphicon glyphicon-search"></span></button>
                    </div>
                  </div>
                  </div>
                  </div>
                   <!-- *************************  -->
            <div class=" col-md-4 pull-right">
                   
                    <div class="form-group">
                 <label> Department </label>
                  
                    <select  class="form-control input-md" name="Volunteer_Code" data-original-title="" placeholder="Name Volunteer" title="">
        <option value="" >Department</option>            
<option value="#StM001" >Strategy</option>
                     <option value="#StV002" >Human Resorce</option>
                      <option value="" >Art</option>
                       <option value="" >Project</option>
                    </select>
                

                </div>
                </div>
                 <!-- *************************  -->
            <div class="col-md-4 pull-right">
                 
                       <div class="form-group">
               
                  <label> Position </label>
                    <select  class="form-control input-md" name="Position" data-original-title="" placeholder="Name Volunteer" title="">

<option value="">Position</option>
                    <option value="">Manager</option>
                     <option value="">Volunteer</option>
                   
                    </select>
          

                </div>
                </div>
                 <!-- *************************  -->
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="panel-body table-responsive">
        <table class="table table-hover">
          <thead>
            <tr>
              <th class="text-center"> No. </th>
              <th class="text-center"> Name </th>
              <th class="text-center"> Volunteer Code </th>
              <th class="text-center"> E-Mail </th>
              <th class="text-center"> Governorate</th>
                  <th class="col-tools text-center"><span class="glyphicon glyphicon-wrench" aria-hidden="true"></span>
            </tr>
          </thead>

          <tbody>
          <?php for($i=1;$i<5;$i++): ?>
            <tr class="edit" id="detail">
              <td id="no" class="text-center"> <?php echo e($i); ?></td>
              <td id="name" class="text-center"> mohammed</td>
              <td id="mobile" class="text-center"> #p123 </td>
              <td id="mail" class="text-center"> mohammed@gmail.com </td>
              <td id="city" class="text-center"> baghdad</td>
               <td align="center">
                                <a class="btn btn-default"><span class="glyphicon glyphicon-pencil"
                                                                 aria-hidden="true"></span></a>
                                <a class="btn btn-danger"><span class="glyphicon glyphicon-trash"
                                                                aria-hidden="true"></span></a>
 <a class="btn btn-info"><span class="glyphicon glyphicon-list-alt"
                            aria-hidden="true"></span></a>
                            </td>
            </tr>

     <?php endfor; ?>
          </tbody>
        </table>
      </div>

      <div class="panel-footer">
        <div class="row">
          <div class="col-lg-12">
            <div class="col-md-12">
              </div>
              <div class="col-md-12">
              <p class="muted pull-right"><strong> © 2017 All rights reserved Code For Iraq </strong></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
                            
                        </body></html>