<script>
function make_password() {
  var text = "";
  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

  for (var i = 0; i < 8; i++)
    text += possible.charAt(Math.floor(Math.random() * possible.length));

  return text;
}
function get_password(){
  var passowrd= make_password();
document.getElementById('Password').value=passowrd;
}

</script>

               <h3 class="headerSign" align="center"><?php echo e($title_panel_Password); ?></h3>
                          <!-- *********************************************************************  -->
    <div class="form-group">                    
 
                    <?php echo e(Form::label('Password', $Password)); ?><span style="color:red;font-size:18pt;">*</span>
                <?php echo e(Form::text('Password','',['class'=>'form-control','placeholder'=>$Password]  )); ?>

                <?php if($errors->has('Password')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                </div>
                  <div class="form-group">                    

                       
   <button type="button" name="Generate_password" onclick="get_password()" class="signbuttons btn btn-primary pull-right"><?php echo e($Generate_Password); ?></button>

   
