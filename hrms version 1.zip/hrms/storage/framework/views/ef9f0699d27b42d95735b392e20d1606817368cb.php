<h3 class="headerSign" align="center"><?php echo e($title_panel_social_m); ?></h3>

                          <!-- *********************************************************************  -->
    <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($facebook); ?></label>
                       
                    <input class="form-control" type="url" name="facebook" placeholder="<?php echo e($facebook); ?>" value="">

                    
                </div>
                                          <!-- *********************************************************************  -->
  
                        <!-- *********************************************************************  -->
    <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($Instagram); ?></label>
                       
                    <input class="form-control" type="url" name="Instagram" placeholder="<?php echo e($Instagram); ?>" value="">

                    
                </div>
                                          <!-- *********************************************************************  -->
                       <!-- *********************************************************************  -->
    <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($Twitter); ?></label>
                       
                    <input class="form-control" type="url" name="Twitter" placeholder="<?php echo e($Twitter); ?>" value="">

                    
                </div>
                                          <!-- *********************************************************************  -->
  

