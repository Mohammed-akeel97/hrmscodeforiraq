         
                <!-- *************************  -->
             
                    <?php
$departments_arr=array ();
foreach ($get_depatment as $depratment){
    $departments_arr[$depratment->id]=$depratment->name_department;
}
$postion_arr=array ();
foreach ($get_postion as $postion){
    $postion_arr[$postion->id]=$postion->name_postion;
}
     ?>
         
                <div class="form-group">                    
                
                                   <?php echo e(Form::label('Full_Name_search', 'Full Name')); ?>

                               <?php echo e(Form::text('Full_Name_search','',['class'=>'form-control','placeholder'=>'Full Name']  )); ?>

                               <?php if($errors->has('Full_Name_search')): ?>
                                                   <span class="help-block" style="color:red;">
                                                       <strong><?php echo e($errors->first('Full_Name_search')); ?></strong>
                                                   </span>
                                               <?php endif; ?>
                               </div>
                                  <!-- *************************  -->
                     
                                  
                                  <div class="form-group">                    
                                  <?php echo e(Form::label('Department_search', 'Department')); ?>

                             
                                      <?php echo e(Form::select('Department_search',$departments_arr,'',['class'=>'form-control','placeholder'=>'Department']
                  )); ?>

                                  </div>
                                  <?php if($errors->has('Department_search')): ?>
                                                      <span class="help-block" style="color:red;">
                                                          <strong><?php echo e($errors->first('Department_search')); ?></strong>
                                                      </span>
                                                  <?php endif; ?>
                               
                        
                                <!-- *************************  -->
                               <div class="form-group" >                    
                               <?php echo e(Form::label('Position_search', 'Position')); ?>

                          
                                   <?php echo e(Form::select('Position_search',$postion_arr,'',['class'=>'form-control','placeholder'=>'Position']
               )); ?>

               <?php if($errors->has('Position_search')): ?>
                                                   <span class="help-block" style="color:red;">
                                                       <strong><?php echo e($errors->first('Position_search')); ?></strong>
                                                   </span>
                                               <?php endif; ?>
                               </div>
                                <!-- *************************  -->
                                     
                <!-- *************************  -->
             
               
         
                <div class="form-group">                    
                
                                   <?php echo e(Form::label('parent_group_search', 'Email Manager')); ?>

                               <?php echo e(Form::email('parent_group_search','',['class'=>'form-control','placeholder'=>'Email Manager']  )); ?>

                               <?php if($errors->has('parent_group_search')): ?>
                                                   <span class="help-block" style="color:red;">
                                                       <strong><?php echo e($errors->first('parent_group_search')); ?></strong>
                                                   </span>
                                               <?php endif; ?>
                               </div>
                                  <!-- *************************  -->