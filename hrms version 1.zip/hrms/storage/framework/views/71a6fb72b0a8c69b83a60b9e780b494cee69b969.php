        
            <h3 class="headerSign" align="center">Progress Rate Report</h3>
                          <!-- *********************************************************************  -->
    <div class="form-group">                    
        <?php echo e(Form::label('Project Report', 'Project Report')); ?><span style="color:red;font-size:18pt;">*</span>
        <?php echo e(Form::textarea('Project_Report',$get_Project->Project_Report,['class'=>'form-control ','placeholder'=>'Project Report','id'=>'txt1']  )); ?>

            <?php if($errors->has('Project_Report')): ?>
                <span class="help-block" style="color:red;">
                <strong><?php echo e($errors->first('Project_Report')); ?></strong>
                </span>
             <?php endif; ?>     
                    
    </div>

      <script>
    
      document.getElementById('txt1').id="article-ckeditor";
        CKEDITOR.replace('article-ckeditor' );
    
  </script>
<!-- *********************************************************************  -->
<!--***************************************************************  -->
            
    