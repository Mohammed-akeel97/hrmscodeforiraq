<!-- *************************  left ****************** -->
<link href="<?php echo e(asset('css/add.css')); ?>" rel="stylesheet">
<?php $__env->startSection('Name_and_Description'); ?>

<?php echo $__env->make('hrm.project.Add.points.Name_and_Description', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                <?php $__env->stopSection(); ?>



<?php $__env->startSection('Requirement'); ?>
<?php echo $__env->make('hrm.project.Add.points.Requirement', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   <?php $__env->stopSection(); ?>
 







  <?php $__env->startSection('Start_Date'); ?>

<?php echo $__env->make('hrm.project.Add.points.Start_Date', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
    <?php $__env->stopSection(); ?>







<?php $__env->startSection('Report_project'); ?>

<?php echo $__env->make('hrm.project.Add.points.Report_project', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   

<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.project.form_add', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>