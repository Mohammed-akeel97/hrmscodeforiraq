                <!--***********************************  -->
 <h3 class="headerSign" align="center"><?php echo e($title_panel_Means_of_communication); ?></h3>
 <!-- *********************************************************************  -->

 <!-- *********************************************************************  -->
                <div class="form-group <?php echo e($errors->has('email') ? 'errorfiled' : ''); ?>">
         
                    <?php echo e(Form::label('email', $email)); ?><span style="color:red;font-size:18pt;">*</span>
      <?php echo e(Form::email('email','',['class'=>'form-control','placeholder'=>$email]  )); ?>

      <?php if($errors->has('email')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
<!-- *********************************************************************  -->
                <div class="form-group">
                <?php echo e(Form::label('Phone_Number1', $Phone_Number1)); ?><span style="color:red;font-size:18pt;">*</span>
                <?php echo e(Form::text('Phone_Number1','',['class'=>'form-control','placeholder'=>$Phone_Number1]  )); ?>

                <?php if($errors->has('Phone_Number1')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Phone_Number1')); ?></strong>
                                    </span>
                                <?php endif; ?>
            </div>
<!-- *********************************************************************  -->
<!-- *********************************************************************  -->
<div class="form-group">
<?php echo e(Form::label('Phone_Number2', $Phone_Number2)); ?>

<?php echo e(Form::text('Phone_Number2','',['class'=>'form-control','placeholder'=>$Phone_Number2]  )); ?>

</div>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
  
           
