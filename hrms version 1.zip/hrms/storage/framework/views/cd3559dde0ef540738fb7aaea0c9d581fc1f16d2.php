<h3 class="headerSign">Training Course Duration & Status</h3>
     
                 <!--***********************************  -->
 <!-- *********************************************************************  -->

  <!-- *********************************************************************  -->
                <div class="form-group">
             <?php echo e(Form::label('Training_Course_Duration','Training Course Duration')); ?><span style="color:red;font-size:18pt;">*</span>
                <?php echo e(Form::textarea('Training_Course_Duration','',['class'=>'form-control','placeholder'=>'Training Course Duration','id'=>'article-ckeditor']  )); ?>

                <?php if($errors->has('Training_Course_Duration')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Training_Course_Duration')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>

<script>

      CKEDITOR.replace( 'article-ckeditor' );
  </script>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
  


  <!-- *********************************************************************  -->
    
                    <div class="form-group" >                    
                <?php echo e(Form::label('Status', 'Status')); ?><span style="color:red;font-size:18pt;">*</span>
           
                    <?php echo e(Form::select('Status', [
                        'Active' => 'Active',
                       'Not Active' => 'Not Active',
                        
   ],'',['class'=>'form-control','placeholder'=>'Status']
)); ?>

<?php if($errors->has('Status')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Status')); ?></strong>
                                    </span>
                                <?php endif; ?>
                </div>

<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->