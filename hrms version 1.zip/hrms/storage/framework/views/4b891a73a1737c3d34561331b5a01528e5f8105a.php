
               <h3 class="headerSign" align="center"><?php echo e($title_panel_Passowrd); ?></h3>
                          <!-- *********************************************************************  -->
    <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($Passowrd); ?><span style="color:red;font-size:18pt;">*</span></label>
                       
                    <input class="form-control" type="text" name="<?php echo e($Passowrd); ?>" placeholder="Password" value="">

                    
                </div>
                  <div class="form-group">                    

                       
   <button  name="Generate_password" class="signbuttons btn btn-primary pull-right"><?php echo e($Generate_Password); ?></button>

   
