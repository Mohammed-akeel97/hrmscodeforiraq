

 <?php $__env->startSection('search_panel'); ?>
 <div class="row">
          <div class=" col-md-12">
            <h2 class="text-center pull-left" style="padding-left: 30px;"> <span class="glyphicon glyphicon-list-alt"> </span> View Training </h2>
          </div>
          <div class=" col-md-12">
            <div class=" col-md-12">
              <div class=" col-md-12">
                
                <!-- *************************  -->
            <div class=" col-md-4 pull-right">
                
                <div class="form-group">
                <label> Search </label>
                  <div class="input-group">

                    <input type="text" class="form-control input-md" name="Training_Name" data-original-title="" placeholder="Name Training" title="">
                    <div class="input-group-btn">
                      <button type="button" class="btn btn-md btn-info"> <span class=" glyphicon glyphicon-search"></span></button>
                    </div>
                  </div>
                  </div>
                  </div>
                   <!-- *************************  -->

                 <!-- *************************  -->

                 <!-- *************************  -->
              </div>
            </div>
          </div>
        </div>
        <?php $__env->stopSection(); ?>