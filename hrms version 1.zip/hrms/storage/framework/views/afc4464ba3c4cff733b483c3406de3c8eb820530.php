<!-- *************************  left ****************** -->
<link href="<?php echo e(asset('css/add.css')); ?>" rel="stylesheet">
<?php $__env->startSection('Group_Information'); ?>

<!-- *******************************  -->

<script>
function myFunction(selTag) {
  
    var x = selTag.selectedIndex;
    var pg=document.getElementById("Parent_Group");
    if(x==1)
pg.disabled = true;
    if(x==2)
pg.disabled = false;
}



</script>







     <h3 class="headerSign"><?php echo e($title_panel_Group_Information); ?></h3>
     <!-- *******************************  -->
                <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($Volunteer_Code); ?><span style="color:red;font-size:18pt;">*</span></label>
                    <select class="form-control"  name="Volunteer_Code" >

                    <option value="#StM001" >Strategy</option>
                     <option value="#StV002" >Human Resorce</option>
                      <option value="" >Art</option>
                       <option value="" >Project</option>
                    </select>
                    
                </div>
                <!-- **************************** -->
                  <div class="form-group" >                    
                <label class="cols-sm-2 control-label "><?php echo e($Position); ?><span style="color:red;font-size:18pt;">*</span></label>
                    <select class="form-control"  name="Position" id="Position" onchange="myFunction(this)" >
<option value="" disabled selected hidden><?php echo e($Position); ?></option>
                    <option value="" ><?php echo e($Position_Manager); ?></option>
                     <option value="" ><?php echo e($Position_Volunteer); ?></option>
                   
                    </select>
                    
                </div>
                 <!-- **********************************  -->

    <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($Parent_Group); ?></label>
                    <select class="form-control"  name="Parent_Group" id="Parent_Group"  >
<option value="" disabled selected hidden><?php echo e($Parent_Group_title); ?></option>
                    <option value="" >Oasama ismail</option>
                     <option value="" >Ahmed ali</option>
                  
                    </select>
                    
                </div>

         <!--***********************************  -->
                                <?php $__env->stopSection(); ?>








<?php $__env->startSection('Specialty_Information'); ?>



                               <!--***********************************  -->
 <h3 class="headerSign" align="center"><?php echo e($title_panel_Specialty_Information); ?></h3>
 <!-- *********************************************************************  -->
 
    <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($Acadimic_Achievement); ?><span style="color:red;font-size:18pt;">*</span></label>
                    <select class="form-control"  name="Acadimic_Achievement" >

                    <option value="" ><?php echo e($Acadimic_Achievement_High_School); ?></option>
                     <option value="" ><?php echo e($Acadimic_Achievement_diploma); ?></option>
                   <option value="" ><?php echo e($Acadimic_Achievement_Bachelor); ?></option>
                     <option value="" ><?php echo e($Acadimic_Achievement_Master); ?></option>
                     <option value="" ><?php echo e($Acadimic_Achievement_Doctorate); ?></option>
                 <option value="" ><?php echo e($Acadimic_Achievement_not); ?></option>
                    </select>
                    
                </div>
                <!-- *********************************************************************  -->
 <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label "><?php echo e($Specialization); ?><span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="email" name="Specialization" placeholder="<?php echo e($Specialization); ?>" value="">
</div>
<!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label "><?php echo e($Experience); ?><span style="color:red;font-size:18pt;">*</span></label>
                    <textarea class="form-control" type="text" name="Experience" placeholder="<?php echo e($Experience); ?>"></textarea>
</div>
<!-- *********************************************************************  -->


   <?php $__env->stopSection(); ?>
 







  <?php $__env->startSection('Means_communication'); ?>

                 <!--***********************************  -->
 <h3 class="headerSign" align="center"><?php echo e($title_panel_Means_of_communication); ?><span style="color:red;font-size:18pt;">*</span></h3>
 <!-- *********************************************************************  -->

 <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label "><?php echo e($email); ?><span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="email" name="email" placeholder="<?php echo e($email); ?>" value="">
</div>
<!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label "><?php echo e($Phone_Number1); ?><span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="text" name="Phone_Number1" placeholder="<?php echo e($Phone_Number1); ?>" value="">
</div>
<!-- *********************************************************************  -->
  <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label "><?php echo e($Phone_Number2); ?></label>
                    <input class="form-control" type="text" name="Phone_Number2" placeholder="<?php echo e($Phone_Number2); ?>" value="">
</div>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
  
           



   
 
    <?php $__env->stopSection(); ?>




<!-- *********************** right ******************** -->




   <?php $__env->startSection('Personal_Information'); ?>

                     <h3 class="headerSign" align="center"><?php echo e($title_panel_Personal_Information); ?></h3>
           

      <!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
                <div class="form-group">
             <label class="cols-sm-2 control-label "><?php echo e($Full_Name); ?><span style="color:red;font-size:18pt;">*</span></label>
                  
                    <input class="form-control" type="text" name="Full_Name" placeholder="<?php echo e($Full_Name); ?>" value="">

</div>
<!-- *********************************************************************  -->

    <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($Gender); ?><span style="color:red;font-size:18pt;">*</span></label>
                    <select class="form-control"  name="Gender" >

                    <option value="" ><?php echo e($Gender_Male); ?></option>
                     <option value="" ><?php echo e($Gender_Female); ?></option>
                   
                    </select>
                    
                </div>
                <!-- *********************************************************************  -->

    <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($Day_of_Birth); ?><span style="color:red;font-size:18pt;">*</span></label>
                   <input class="form-control" type="date" name="Day_of_Birth" placeholder="<?php echo e($Day_of_Birth); ?>" value="">

                    
                </div>
                <!-- *********************************************************************  -->
    <?php $__env->stopSection(); ?>






      <?php $__env->startSection('Address'); ?>
             <h3 class="headerSign" align="center"><?php echo e($title_panel_Address); ?></h3>
                <!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^  -->





    <div class="form-group">                    
                <label class="cols-sm-2 control-label ">Governorate<span style="color:red;font-size:18pt;">*</span></label>
                    <select class="form-control"  name="Governorates" >
                    <!-- 1 -->
                    <option value="" ><?php echo e($Governorate_Anbar); ?></option>
                     <!-- 2 -->
                  <option value="" ><?php echo e($Governorate_Babil); ?></option>
                   <!-- 3 -->
                   <option value="" ><?php echo e($Governorate_Baghdad); ?></option>
                    <!-- 4 -->
                   <option value="" ><?php echo e($Governorate_Basra); ?></option>
                    <!-- 5 -->
                   <option value="" ><?php echo e($Governorate_Dhi_Qar); ?></option>
                    <!-- 6 -->
                   <option value="" ><?php echo e($Governorate_Qadisiyyah); ?></option>
                    <!-- 7 -->
                   <option value="" ><?php echo e($Governorate_Diyala); ?></option>
                    <!-- 8 -->
                   <option value="" ><?php echo e($Governorate_Dohuk); ?></option>
                    <!-- 9 -->
                   <option value="" ><?php echo e($Governorate_Erbil); ?></option>
                    <!-- 10 -->
                   <option value="" ><?php echo e($Governorate_Karbala); ?></option>
                    <!-- 11 -->
                   <option value="" ><?php echo e($Governorate_Kirkuk); ?></option>
                    <!-- 12 -->
                   <option value="" ><?php echo e($Governorate_Maysan); ?></option>
                    <!-- 13 -->
                   <option value="" ><?php echo e($Governorate_Muthanna); ?></option>
                    <!-- 14 -->
                   <option value="" ><?php echo e($Governorate_Najaf); ?></option>
                    <!-- 15 -->
                   <option value="" ><?php echo e($Governorate_Nineveh); ?></option>
                    <!-- 16 -->
                   <option value="" ><?php echo e($Governorate_Saladin); ?></option>
                    <!-- 17 -->
                   <option value="" ><?php echo e($Governorate_Sulaymaniyah); ?></option>
                    <!-- 18 -->
                   <option value="" ><?php echo e($Governorate_Wasit); ?></option>
                    </select>
                    
                </div>























                <!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^  -->
                          <!-- *********************************************************************  -->
    <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($Address); ?><span style="color:red;font-size:18pt;">*</span></label>
                       
                    <input class="form-control" type="text" name="Address" placeholder="<?php echo e($Address); ?>" value="">

                    
                </div>
                                          <!-- *********************************************************************  -->
  


      <?php $__env->stopSection(); ?>



        <?php $__env->startSection('other_information'); ?>
               <h3 class="headerSign" align="center"><?php echo e($title_panel_other_information); ?></h3>
                          <!-- *********************************************************************  -->
    <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($Blood_Group); ?><span style="color:red;font-size:18pt;">*</span></label>
                    <select class="form-control"  name="Blood_Group" >

                    <option value="" >AB +-ve</option>
                     <option value="" >A+-ve</option>
                    <option value="" >B+-ve</option>
                     <option value="" >O+-ve</option>
                    </select>
                    
                </div>
                           <!-- *********************************************************************  -->

    <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($Marital_Status); ?></label>
                    <select class="form-control"  name="Marital_Status" >

                    <option value="" ><?php echo e($Marital_Status_Married); ?></option>
                     <option value="" ><?php echo e($Marital_Status_Not); ?></option>
            
                    </select>
                    
                </div>
                <!-- *********************************************************************  --
                                                      <!-- *********************************************************************  -->

    <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($New_Pecture); ?><span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="file" accept="Image/*" name="Pecture" value="">

                    
                    
                </div>
                <!-- *********************************************************************  -->
              


<?php $__env->stopSection(); ?>




<?php $__env->startSection('Passowrd'); ?>


               <h3 class="headerSign" align="center"><?php echo e($title_panel_Passowrd); ?></h3>
                          <!-- *********************************************************************  -->
    <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($Passowrd); ?><span style="color:red;font-size:18pt;">*</span></label>
                       
                    <input class="form-control" type="text" name="<?php echo e($Passowrd); ?>" placeholder="Password" value="">

                    
                </div>
                  <div class="form-group">                    

                       
   <button  name="Generate_password" class="signbuttons btn btn-primary pull-right"><?php echo e($Generate_Password); ?></button>

   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.volunteer.form_add', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>