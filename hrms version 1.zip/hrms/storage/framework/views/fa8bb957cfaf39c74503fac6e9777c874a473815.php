      <script type="text/javascript" src="<?php echo e(asset('js/get_info.js')); ?>"></script> 
   <div class="panel-body table-responsive">
        <table class="table table-hover">
          <thead>
            <tr class="th">
              <th class="text-center"> No. </th>
              <th class="text-center"> Project Name </th>
              <th class="text-center"> Project Provider </th>
              <th class="text-center"> Project Start Date</th>
                <th class="text-center"> Team Responsible</th>
              <th class="col-tools text-center"><span class="	glyphicon glyphicon-wrench" aria-hidden="true"></span>
            </tr>
          </thead>

          <tbody>
          <?php if(count($Projects) >0): ?>
<?php  $i=1; ?>
          <?php $__currentLoopData = $Projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr class="edit" id="detail">
                         <td style="display:none;" id="Project_Requirement[<?php echo e($i); ?>]">  <?php echo $Project->Project_Requirement; ?> </td>
  <td style="display:none;" id="Project_Description[<?php echo e($i); ?>]">  <?php echo $Project->Project_Description; ?> </td>
  <td style="display:none;" id="Estimate_Project_Time[<?php echo e($i); ?>]">  <?php echo e($Project->Estimate_Project_Time); ?> </td>
  <td style="display:none;" id="Project_Report[<?php echo e($i); ?>]">  <?php echo $Project->Project_Report; ?> </td>

              <td  class="text-center"> <?php echo e($i); ?></td>
              <td  class="text-center" id="Project_Name[<?php echo e($i); ?>]"> <?php echo e($Project->Project_Name); ?></td>
              <td class="text-center" id="Project_Provider[<?php echo e($i); ?>]"> <?php echo e($Project->Project_Provider); ?> </td>
           
              <td class="text-center" id="Project_Start_Date[<?php echo e($i); ?>]">  <?php echo e($Project->Project_Start_Date); ?> </td>
              <td class="text-center" id="Team_Responsible[<?php echo e($i); ?>]">  <?php echo e($Project->Team_Responsible); ?> </td>

              <td align="left">


    <a href="/project/<?php echo e($Project->id); ?>/edit" class="btn btn-default " title="" data-original-title="Edit" aria-expanded="true"><span class="glyphicon glyphicon-pencil"
                                                                 aria-hidden="true"></span></a>

          <!--   <button data-toggle="modal" onclick="get_info(<?php echo e($i); ?>)"  data-target="#ShowModal1" class="btn btn-info"  title="" data-original-title="Edit" aria-expanded="true"><span class="glyphicon glyphicon-list-alt"
                            aria-hidden="true"></span></button>-->
                            <a class="btn btn-info "  onclick="get_info_project(<?php echo e($i); ?>)"  href="#trainModal" data-toggle="modal" title="" data-original-title="Show Information" aria-expanded="true"><i class="glyphicon glyphicon-list-alt"></i></a> 
  <span>                            
                            <?php echo Form::open(['action' => ['project_controller@destroy',$Project->id], 'method'=>'POST']); ?>

  <?php echo e(Form::hidden('_method' ,'DELETE')); ?>

<?php
echo get_modal($Project->id,$Project->Project_Name);

?>
  <?php echo Form::close(); ?>

  </span>
                            </td>
            </tr>



            <?php  $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?> 
<td colspan="7" style="text-align:center;"><br><br><strong>No Results</strong><br><br></td>      
<?php endif; ?>
 
          </tbody>
        </table>
      </div>