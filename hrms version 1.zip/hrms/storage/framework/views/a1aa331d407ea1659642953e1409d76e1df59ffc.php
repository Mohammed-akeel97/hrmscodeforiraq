

  <?php $__env->startSection('table_edit_project'); ?>
   <div class="panel-body table-responsive">
        <table class="table table-hover">
          <thead>
            <tr class="th">
           <th class="text-center"> No. </th>
              <th class="text-center"> Name Project</th>
              <th class="text-center">Team Responsible for the Project </th>
              <th class="text-center"> Project Start Date </th>
              <th class="text-center"> Progress Rate Report</th>
                  <th class="col-tools text-center"><span class="	glyphicon glyphicon-wrench" aria-hidden="true"></span>
            </tr>
          </thead>

          <tbody>
        <?php for($i=1;$i<5;$i++): ?>
            <tr class="edit" id="detail">
                   <td class="text-center"> 1</td>
              <td class="text-center">hrms</td>
              <td  class="text-center"> oasma group</td>
              <td  class="text-center"> 28/8/2017 </td>
            
              <!-- *************************************8 -->
               <td class="text-center">
        <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 15%;">
         
            </div>
            <span class="progress-type">15</span>
          
        </div>

</td>

              <!-- *************************************** -->
               <td align="">
                                <a class="btn btn-default"><span class="glyphicon glyphicon-pencil"
                                                                 aria-hidden="true"></span></a>
                                <a class="btn btn-danger"><span class="glyphicon glyphicon-trash"
                                                                aria-hidden="true"></span></a>
 <a class="btn btn-info"><span class="glyphicon glyphicon-list-alt"
                            aria-hidden="true"></span></a>
                            </td>
            </tr>
<?php endfor; ?>
 
          </tbody>
        </table>
      </div>
      <?php $__env->stopSection(); ?>