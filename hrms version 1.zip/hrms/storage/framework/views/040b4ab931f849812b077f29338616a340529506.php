<link href="<?php echo e(asset('css/edit_vol.css')); ?>" rel="stylesheet">



<?php $__env->startSection('panel_edit'); ?>
<?php echo $__env->make('hrm.Training.View.points.modal_show', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<link href="<?php echo e(asset('css/add.css')); ?>" rel="stylesheet">   
<link href="<?php echo e(asset('css/training_view.css')); ?>" rel="stylesheet">
    <script type="text/javascript" src="<?php echo e(asset('js/get_info.js')); ?>"></script> 
 <div class="container-fluid">

    <div class="panel panel-info">
      <div class="panel-heading color_panel" style="color:white;  ">
   <?php echo $__env->make('hrm.Training.View.points.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>

   <?php echo $__env->make('hrm.Training.View.points.info_view', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <div class="panel-footer">
        <div class="row">
          <div class="col-lg-12">
            <div class="col-md-12">
            <?php echo e($Trainings->links()); ?>

              </div>
              <div class="col-md-12">
              <p class="muted pull-right"><strong> © 2017 All rights reserved Code For Iraq </strong></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.general', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>