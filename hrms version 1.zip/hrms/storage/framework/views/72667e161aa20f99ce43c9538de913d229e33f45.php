      <div class="list-group">
      <?php $i=0; ?>
      <?php if(count($receiveds)>0): ?>
<?php $__currentLoopData = $receiveds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $received): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

     <a onclick="modal_read_message_received_fun(<?php echo e($i); ?>,<?php echo e($received->id_message_to); ?>,<?php echo e($received->id_message); ?>)" href="#modal_read_message_received" data-toggle="modal" style="padding:20px 20px 20px 20px;" id="message_class[<?php echo e($i); ?>]"   class="list-group-item <?php if(!$received->is_read)echo 'read'; ?>">
                    
                            <span id="message_star[<?php echo e($i); ?>]" class="glyphicon glyphicon-star<?php if($received->is_read)echo '-empty'; ?>"></span><span class="name" style="min-width: 120px;
                                display: inline-block;" id="message_received_name_sender[<?php echo e($i); ?>]"><?php echo e($received->name_sender); ?></span> <span class="" id="message_received_title_message[<?php echo e($i); ?>]"><?php echo e($received->title_message); ?></span>
                            <span class="text-muted" style="font-size: 11px;">-<span id="message_received_department_sender[<?php echo e($i); ?>]"> <?php echo e($received->department_sender); ?></span>-<span id="message_received_position[<?php echo e($i); ?>]"> <?php echo e($received->name_postion); ?></span></span> <span class="badge" id="message_received_created_at[<?php echo e($i); ?>]"><?php echo e($received->sent_at); ?></span> <span class="pull-right">
                                </span>
                        <span style="display:none;" id="message_received_full_message[<?php echo e($i); ?>]"><?php echo $received->full_message; ?></span>        
                                    <span style="display:none;" id="message_received_email_sender[<?php echo e($i); ?>]"><?php echo e($received->email_sender); ?></span>
                                        <span style="display:none;" id="message_received_department_received[<?php echo e($i); ?>]"><?php echo e($received->department_received); ?></span>
                                <span style="display:none;" id="message_received_group_parent[<?php echo e($i); ?>]"><?php echo e($received->group_parent); ?></span>
                              </a>
 <?php $i++; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>`
<?php else: ?> 
<br>
<br>
<h3 align="center">No Announcement Received</h3>
<?php endif; ?>
</div> 
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
     <?php echo e($receiveds->links()); ?>

          <?php echo $__env->make('hrm.Announcement.points.modals.modal_read_msg_received.modal_read_msg_received', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>