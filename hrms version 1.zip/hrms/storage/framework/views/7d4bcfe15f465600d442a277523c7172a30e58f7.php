  
  <?php if(count($replays)>0): ?>
  <?php $__currentLoopData = $replays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $replays): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <article class="row">
            <div class="col-md-2 col-sm-2 hidden-xs">
          
            </div>
            <div class="col-md-12 col-sm-12">
              <div class="panel panel-primary arrow left">
              <div class="panel-heading <?php if($replays->replay_email==Auth::user()->email)echo 'color_panel';?>" style="color:white;"><?php echo e($replays->replay_name); ?></div>
                <div class="panel-body">
                  <header class="text-left">
                    <div class="comment-user"><span>Full Name:</span><?php echo e($replays->replay_name); ?></div>
                         <div class="comment-user"><span>Email:</span><?php echo e($replays->replay_email); ?></div>
                              <div class="comment-user"><span>Position:</span><?php echo e($replays->name_postion); ?></div>
                               <div class="comment-user"><span>Department:</span><?php echo e($replays->name_department); ?></div>

                    <time class="comment-date" datetime="16-12-2014 01:05"><i class="glyphicon glyphicon-time"></i> <?php echo e($replays->replay_at); ?></time>
                  </header>
                  <hr>
                  <div class="comment-post">
                    <p>
                    <?php echo $replays->detailes_replay; ?>

                   </p>
                  </div>
               </div>
              </div>
            </div>
          </article>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
          <p align="center">No Replays</p>
          <?php endif; ?>