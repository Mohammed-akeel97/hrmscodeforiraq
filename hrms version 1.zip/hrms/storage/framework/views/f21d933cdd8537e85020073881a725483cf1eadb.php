               <h3 class="headerSign" align="center"><?php echo e($title_panel_other_information); ?></h3>
                          <!-- *********************************************************************  -->
    <div class="form-group">                    

                    <?php echo e(Form::label('Blood_Group',$Blood_Group)); ?><span style="color:red;font-size:18pt;">*</span>
           
                    <?php echo e(Form::select('Blood_Group', [   'AB+-ve'=> 'AB+-ve',   'A+-ve'=> 'A+-ve',   'B+-ve'=> 'B+-ve', 
                        'O+-ve'=> 'O+-ve',               
   ],'',['class'=>'form-control','placeholder'=>$Blood_Group,]
)); ?>

<?php if($errors->has('Blood_Group')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Blood_Group')); ?></strong>
                                    </span>
                                <?php endif; ?>
                </div>
                           <!-- *********************************************************************  -->

    <div class="form-group">                    
    <?php echo e(Form::label('Marital_Status', $Marital_Status)); ?>

               <span style="color:red;font-size:18pt;">*</span>
           
                    <?php echo e(Form::select('Marital_Status', [   $Marital_Status_Married=> $Marital_Status_Married, 
                        $Marital_Status_Not=>$Marital_Status_Not,  
                                   
   ],'',['class'=>'form-control','placeholder'=>$Marital_Status,]
)); ?>

<?php if($errors->has('Marital_Status')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Marital_Status')); ?></strong>
                                    </span>
                                <?php endif; ?>
                </div>
                <!-- *********************************************************************  --
                                                      <!-- *********************************************************************  -->

    <div class="form-group">                    
    <label class="cols-sm-2 control-label "><?php echo e($new_pecture); ?></label><span style="color:red;font-size:18pt;">*</span>
                    <?php echo e(Form::file('New_Pecture', ['class'=>'btn','accept' =>'Image/*' ])); ?>

                    <?php if($errors->has('New_Pecture')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('New_Pecture')); ?></strong>
                                    </span>
                                <?php endif; ?>
                </div>
                <!-- *********************************************************************  -->
            