
<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $numbers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$num_message=$numbers->num;

?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo $num_message; ?>