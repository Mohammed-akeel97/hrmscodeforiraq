<link href="<?php echo e(asset('css/edit_vol.css')); ?>" rel="stylesheet">
<script type="text/javascript">
    $(function(){
$('a[title]').tooltip();
});

    </script>
   <div class="panel-body table-responsive">
        <table class="table table-hover">
          <thead>
            <tr class="th">
              <th class="text-center"> No. </th>
              <th class=""> Name </th>
              <th class=""> Department </th>
              <th class=""> Postion </th>
              <th class=""> Specialization </th>
              <th class=""> Governorate</th>
                  <th class="col-tools text-center"><span class="	glyphicon glyphicon-wrench" aria-hidden="true"></span>
            </tr>
          </thead>

          <tbody>
  
          <?php if(count($Volunteers) >0): ?>
<?php  $i=1; ?>
          <?php $__currentLoopData = $Volunteers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Volunteer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="edit" id="detail">
          
              <td id="no" class="text-center"><?php echo e($i); ?></td>
              <!-- 1 -->
              <td id="Full_Name[<?php echo e($i); ?>]" > <?php echo e($Volunteer->Full_Name); ?></td>
                 <!-- 2 -->
              <td id="Volunteer_Code[<?php echo e($i); ?>]" class=""> <?php echo e($Volunteer->name_department); ?></td>
                 <!-- 3 -->
              <td id="Position[<?php echo e($i); ?>]" class=""> <?php echo e($Volunteer->name_postion); ?></td>
                 <!-- 4 -->
                 <td id="Specialization[<?php echo e($i); ?>]" class="" > <?php echo e($Volunteer->Specialization); ?></td>
             <!-- 5 -->
              <td id="Governorate[<?php echo e($i); ?>]" class=""> <?php echo e($Volunteer->Governorate); ?></td>
                 <!-- 6 -->
        
              <td id="email[<?php echo e($i); ?>]" class="" style="display:none;"><?php echo e($Volunteer->volunteerEmail); ?></td>
           
                 <!-- 7 -->
              <td id="Gender[<?php echo e($i); ?>]" class="" style="display:none;"> <?php echo e($Volunteer->Gender); ?></td>
                 <!-- 8 -->
              <td id="parent_group[<?php echo e($i); ?>]" class="" style="display:none;"> <?php echo e($Volunteer->parent_group); ?></td>
                 <!-- 9 -->
              <td id="Day_of_Birth[<?php echo e($i); ?>]" class="" style="display:none;"> <?php echo e($Volunteer->Day_of_Birth); ?></td>
                 <!-- 10 -->
              <td id="Acadimic_Achievement[<?php echo e($i); ?>]" class="" style="display:none;"> <?php echo e($Volunteer->Acadimic_Achievement); ?></td>
                 <!-- 11 -->
              <td id="New_Pecture[<?php echo e($i); ?>]" class="" style="display:none;"><?php echo e($Volunteer->New_Pecture); ?></td>
                 <!-- 12 -->
              <td id="Address[<?php echo e($i); ?>]" class="" style="display:none;"> <?php echo e($Volunteer->Address); ?></td>
                 <!-- 13 -->
              <td id="Experience[<?php echo e($i); ?>]" class="" style="display:none;"> <?php echo $Volunteer->Experience; ?></td>
                 <!-- 14 -->
              <td id="Blood_Group[<?php echo e($i); ?>]" class="" style="display:none;"> <?php echo e($Volunteer->Blood_Group); ?></td>
                 <!-- 15 -->
              <td id="Marital_Status[<?php echo e($i); ?>]" class="" style="display:none;"> <?php echo e($Volunteer->Marital_Status); ?></td>
                 <!-- 16 -->
              <td id="Phone_Number1[<?php echo e($i); ?>]" class="" style="display:none;"> <?php echo e($Volunteer->Phone_Number1); ?></td>
                 <!-- 17 -->
              <td id="Phone_Number2[<?php echo e($i); ?>]" class="" style="display:none;"> <?php echo e($Volunteer->Phone_Number2); ?></td>
                 <!-- 18 -->
              <td id="Twitter[<?php echo e($i); ?>]" class="" style="display:none;"> <?php echo e($Volunteer->Twitter); ?></td>
                 <!-- 19 -->
              <td id="facebook[<?php echo e($i); ?>]" class="" style="display:none;"> <?php echo e($Volunteer->facebook); ?></td>
                 <!-- 20 -->
              <td id="Instagram[<?php echo e($i); ?>]" class="" style="display:none;"> <?php echo e($Volunteer->Instagram); ?></td>
                 <!-- 21 -->
              <td id="how_add[<?php echo e($i); ?>]" class="" style="display:none;"> <?php echo e($Volunteer->name); ?></td>
                      <!-- 22 -->
                      <td id="created_at[<?php echo e($i); ?>]" class="" style="display:none;"> <?php echo e($Volunteer->join_date); ?></td>
               
               <td align="left">


                                <a href="/volunteer/<?php echo e($Volunteer->volunteerID); ?>/edit" class="btn btn-default btn-group" title="" data-original-title="Edit" aria-expanded="true"><span class="glyphicon glyphicon-pencil"
                                                                 aria-hidden="true"></span></a>
                                                                 
            <?php echo Form::open(['action' => ['Volunteer_controller@destroy',$Volunteer->volunteerID], 'method'=>'POST']); ?>

  <?php echo e(Form::hidden('_method' ,'DELETE')); ?>

<?php
echo get_modal($Volunteer->volunteerID,$Volunteer->Full_Name);

?>
  <?php echo Form::close(); ?>

          <!--   <button data-toggle="modal" onclick="get_info(<?php echo e($i); ?>)"  data-target="#ShowModal1" class="btn btn-info"  title="" data-original-title="Edit" aria-expanded="true"><span class="glyphicon glyphicon-list-alt"
                            aria-hidden="true"></span></button>-->
                            <a class="btn btn-info btn-group" onclick="get_info(<?php echo e($i); ?>)" href="#ShowModal1" data-toggle="modal" title="" data-original-title="Show Information" aria-expanded="true"><i class="glyphicon glyphicon-list-alt"></i></a> 

                            </td>
            </tr>
 
            <?php  $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?> 
<td colspan="7" style="text-align:center;"><br><br><strong>No Results</strong><br><br></td>      
<?php endif; ?>
          </tbody>
        </table>
      </div>