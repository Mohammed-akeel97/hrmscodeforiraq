 
   <div class="panel-body table-responsive">
        <table class="table table-hover">
          <thead>
            <tr class="th">
              <th class="text-center"> No. </th>
              <th class="text-center"> Title </th>
              <th class="text-center"> Trainer Name </th>
              <th class="text-center"> Training Place </th>
              <th class="text-center"> Training Start Date</th>
                  <th class="col-tools text-center"><span class="	glyphicon glyphicon-wrench" aria-hidden="true"></span>
            </tr>
          </thead>

          <tbody>
          <?php if(count($Trainings) >0): ?>
<?php  $i=1; ?>
          <?php $__currentLoopData = $Trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="edit" id="detail">
              <td  class="text-center"> <?php echo e($i); ?></td>
              <td  class="text-center" id="Title_Trining[<?php echo e($i); ?>]"> <?php echo e($Training->Title_Trining); ?></td>
              <td class="text-center" id="Trainer_Name[<?php echo e($i); ?>]"> <?php echo e($Training->Trainer_Name); ?> </td>
              <td class="text-center" id="Training_Place[<?php echo e($i); ?>]">  <?php echo e($Training->Training_Place); ?> </td>
              <td  class="" id="Training_Start_Date[<?php echo e($i); ?>]">  <?php echo e($Training->Training_Start_Date); ?></td>
              <span id="Status[<?php echo e($i); ?>]" style="display:none;"><?php echo e($Training->Status); ?></span>
    <span id="add_by[<?php echo e($i); ?>]" style="display:none;"><?php echo e($Training->add_by); ?></span>
    <span id="Training_Course_Duration[<?php echo e($i); ?>]" style="display:none;"><?php echo $Training->Training_Course_Duration; ?></span>
    <span id="Training_End_Date[<?php echo e($i); ?>]" style="display:none;"><?php echo e($Training->Training_End_Date); ?></span>

              <td align="left">


                                <a href="/training/<?php echo e($Training->id); ?>/edit" class="btn btn-default " title="" data-original-title="Edit" aria-expanded="true"><span class="glyphicon glyphicon-pencil"
                                                                 aria-hidden="true"></span></a>

          <!--   <button data-toggle="modal" onclick="get_info(<?php echo e($i); ?>)"  data-target="#ShowModal1" class="btn btn-info"  title="" data-original-title="Edit" aria-expanded="true"><span class="glyphicon glyphicon-list-alt"
                            aria-hidden="true"></span></button>-->
                            <a class="btn btn-info "  onclick="get_info_training(<?php echo e($i); ?>)"  href="#trainModal" data-toggle="modal" title="" data-original-title="Show Information" aria-expanded="true"><i class="glyphicon glyphicon-list-alt"></i></a> 
                                     <span>                            
                            <?php echo Form::open(['action' => ['Training_controller@destroy',$Training->id], 'method'=>'POST']); ?>

  <?php echo e(Form::hidden('_method' ,'DELETE')); ?>

<?php
echo get_modal($Training->id,$Training->Title_Trining);

?>
  <?php echo Form::close(); ?>

  </span>
                            </td>
            </tr>
            <?php  $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?> 
<td colspan="7" style="text-align:center;"><br><br><strong>No Results</strong><br><br></td>      
<?php endif; ?>
 
          </tbody>
        </table>
      </div>