<!-- *************************  left ****************** -->
<?php $__env->startSection('form_reg'); ?>
<form action="" method="POST">
	 <!--this was made my Agil Asadi. You are free to delete this comment line and use it as you wish-->   
<div class="container">
	<div class="row">
		<h2 class="headerSign" style=""><?php echo e($title_form); ?></h2>

	</div>
</div>
<div class="row col-md-8 col-ms-5 col-md-offset-2 registeration" style="z-index:100;background-color:rgba(255,255,255,0.8)">
    
<div class="registerInner">
<!-- ********************************  lift -->
        <div class="col-md-6 signUp">


  <?php echo $__env->yieldContent('Group_Information'); ?>;

<?php echo $__env->yieldContent('Specialty_Information'); ?>;

<?php echo $__env->yieldContent('Means_communication'); ?>;

 </div>
<!-- ********************************  right -->       
        <div class="col-md-6">
 <?php echo $__env->yieldContent('Personal_Information'); ?>;
 <?php echo $__env->yieldContent('Address'); ?>;
   
   <?php echo $__env->yieldContent('other_information'); ?>;
                                                          <!-- *********************************************************************  -->
  <?php echo $__env->yieldContent('Passowrd'); ?>;
 
                    
                </div>
<!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
                         <!-- *********************************************************************  -->

                <h3 class="headerSign" align="center"><?php echo e($title_panel_Save_Changes); ?></h3>
                          <!-- *********************************************************************  -->
 <div class="form-group"> 
                <button type="submit" class="signbuttons btn btn-primary pull-right"><?php echo e($save); ?></button>
   
               </div>  
			  <br>
<br>	
			  <br>
<br>		  
<!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
            
        </div>
             
</div>
       
</div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.nav_bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.general', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>