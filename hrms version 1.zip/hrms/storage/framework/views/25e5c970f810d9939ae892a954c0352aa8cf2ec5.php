
 <script type="text/javascript" src="<?php echo e(asset('js/suport.js')); ?>"></script>
     <h3 class="headerSign"><?php echo e($title_panel_Group_Information); ?></h3>
     <!-- *******************************  -->
     <?php
$departments_arr=array ();
foreach ($get_depatment as $depratment){
    $departments_arr[$depratment->id]=$depratment->name_department;
}
     ?>
        <script>
    var arr_manager=[];
          <?php
          $i=0;
          $dpt_mng="";
foreach ($get_manager as $manager){
    $json="{nameManager:'".$manager->Full_Name."',emailManager:'".$manager->email."',departments_id:".$manager->departments_id."}";
echo "arr_manager[".$i."]=".$json."\n";
$i++;

}
     ?>
 

</script>

     
 
                <div class="form-group">                    
                <?php echo e(Form::label('departments', 'Department')); ?><span style="color:red;font-size:18pt;">*</span>
           
                    <?php echo e(Form::select('departments',$departments_arr,$get_volunteer->departments_id,['class'=>'form-control','placeholder'=>'Department','onchange'=>'get_manager(this)']
)); ?>

                </div>
                <?php if($errors->has('departments')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('departments')); ?></strong>
                                    </span>
                                <?php endif; ?>
                <!-- **************************** -->
                     <?php
$postion_arr=array ();
foreach ($get_postion as $postion){
    $postion_arr[$postion->id]=$postion->name_postion;
}
     ?>
                  <div class="form-group" >                    
                <?php echo e(Form::label('Position', 'Position')); ?><span style="color:red;font-size:18pt;">*</span>
           
                    <?php echo e(Form::select('Position',$postion_arr,$get_volunteer->Positions_id,['class'=>'form-control','placeholder'=>'Position','onchange'=>'myFunction(this)']
)); ?>

<?php if($errors->has('Position')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Position')); ?></strong>
                                    </span>
                                <?php endif; ?>
                </div>
                   <!-- get managers **********************************  -->

           <div class="form-group">                    

              
                <?php echo e(Form::label('Parent_Group', $Parent_Group)); ?>

         
                    <?php echo e(Form::select('Parent_Group', [
                        $Parent_Group =>'',               
   ],'',['class'=>'form-control','placeholder'=>$Parent_Group_title,]
)); ?>

                </div>
         <!--***********************************  -->
         <script>

get_select_manager(<?php echo e($get_volunteer->departments_id); ?>,<?php echo "'".$get_volunteer->parent_group."'";?>);
         get_position(<?php echo e($get_volunteer->Positions_id); ?>);
</script>