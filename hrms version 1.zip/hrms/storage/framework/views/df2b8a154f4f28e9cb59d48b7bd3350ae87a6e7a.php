<div class="row">
<div  class="col-md-12" >
<div class="container">
<div class="row" >
  <ul class="nav nav-tabs col-md-5">
   <li class="active"><a data-toggle="tab" href="#sentmenu1">Sent   Details</a></li>
    <li><a data-toggle="tab" href="#sentmenu2">Sent Replies</a></li>
    <li><a data-toggle="tab" href="#sentmenu3">Reply To The Announcement </a></li>
  </ul>
 </div>
 <div class="row" >
  <div class="tab-content" >

    <div id="sentmenu1" class="tab-pane  fade  in active" >
    
    <div class="row">
    <br>
  	<div class="row col-md-8 col-lg-8">
  
                <div class=" col-md-9 col-lg-9 "> 
                  <div class="list-group">
                    <tbody>
                      <a class="list-group-item">
                        <td>Name Sender:</td>
                        <td ><p id="message_sent_name_sender"></p></td>
											</a>
												       <a class="list-group-item">
                        <td>Email Sender:</td>
                        <td ><p id="message_sent_email_sender"></p></td>
											</a>
                      <a class="list-group-item">
                            <td>From  Department:</td>
                        <td ><p id="message_sent_department_sender"></p></td>
											</a>
                      	<a class="list-group-item">
                            <td>To  Department:</td>
                        <td ><p id="message_sent_department"></p></td>
											</a>
									       <a class="list-group-item">
                        <td>Announcement Title:</td>
                        <td ><p id="message_sent_title_message"></p></td>
											</a>
                
            
									
											<a class="list-group-item">
                        <td colspan="2">Announcement Details:<br>
                       <br><p id="message_sent_full_message"></p>  </a>
                     
                    </tbody>
                  </div>
                  
   <strong >sent at:<span  id="sent_sent_at"></span></strong><br>
      <strong >Status:<span  ><i id="dicon" class=""></i> <span id="status_sent"></span> </span></strong><br>
             </div>
				     </div>
   </div> 
 </div>
    <div id="sentmenu2" class="tab-pane fade">
  
  <div class="row col-md-6 col-md-offset-0">
  <div class="panel panel-primary ">
      <div class="panel-heading color_panel">Replays A Sent Announcement</div>
      <div class="panel-body" id="sent_replay"></div>
    </div>
   </div>
  </div>
    <div id="sentmenu3" class="tab-pane fade">
    
    <div class="row col-md-6">
  <!-- *********************************************************************  -->
<input name="replay_id_sent" id="replay_id_sent" type="hidden" value="">
<div class="form-group col-md-12">

                <?php echo e(Form::label('detailes_replay_sent', 'Replay Announcement')); ?><span style="color:red;font-size:18pt;">*</span>
                <?php echo e(Form::textarea('detailes_replay_sent','',['class'=>'form-control txt4','placeholder'=>'Replay Announcement']  )); ?>

                <?php if($errors->has('detailes_replay_sent')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('detailes_replay_sent')); ?></strong>
                                    </span>
                                <?php endif; ?>
            </div>
                               <button type="submit" class="btn btn-default color_button pull-right" >Send</button>
          
<!-- *********************************************************************  -->
   </div>
</div>
  </div>
</div>
</div>
</div>
</div>
