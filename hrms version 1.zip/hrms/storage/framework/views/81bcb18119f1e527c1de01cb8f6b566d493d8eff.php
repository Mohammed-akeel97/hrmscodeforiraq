
                        
<div class="panel-body table-responsive">
<?php if(count($Trainings) >0): ?>
<?php  $i=1; ?>
          <?php $__currentLoopData = $Trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class=" col-md-3">
<ul class="eight">
  <li class="transition">
    <div class="wrapper" > <span class="transition" >
      <h3 class="transition"><?php echo e($Training->Title_Trining); ?><em><?php echo e($Training->Trainer_Name); ?></em></h3>
      <span id="Title_Trining[<?php echo e($i); ?>]" style="display:none;"><?php echo e($Training->Title_Trining); ?></span>
      <span id="Trainer_Name[<?php echo e($i); ?>]" style="display:none;"><?php echo e($Training->Trainer_Name); ?></span>
      <span id="Training_Course_Duration[<?php echo e($i); ?>]" style="display:none;"><?php echo $Training->Training_Course_Duration; ?></span>
      <span id="Status[<?php echo e($i); ?>]" style="display:none;"><?php echo e($Training->Status); ?></span>
      <span id="Training_Place[<?php echo e($i); ?>]" style="display:none;"><?php echo e($Training->Training_Place); ?></span>
      <span id="Training_Start_Date[<?php echo e($i); ?>]" style="display:none;"><?php echo e($Training->Training_Start_Date); ?></span>
      <span id="add_by[<?php echo e($i); ?>]" style="display:none;"><?php echo e($Training->add_by); ?></span>
      <span id="Training_End_Date[<?php echo e($i); ?>]" style="display:none;"><?php echo e($Training->Training_End_Date); ?></span>
      <span id="days[<?php echo e($i); ?>]" style="display:none;"><?php echo e($Training->Training_End_Date-$Training->Training_Start_Date); ?></span>


      <div class="image-container transition">
        <div class="creation" >
          <div class="front" >
            <div class="cont" > <i class="details"><img width="100" class="icon-circle transition" src="<?php echo e(URL::to('/')); ?>/Images/lap.png" ></img> </div>
          </div>
          <div class="back">
            <div class="cont" > <i class="details"><img width="100" src="<?php echo e(URL::to('/')); ?>/Images/vinger.png"  ></img> </div>
          </div>
        </div>
      </div>
      </span>
      <ul class="social transition" align="center" style="margin-left:36%;">
        <li class="transition"><button onclick="get_info_training(<?php echo e($i); ?>)" data-toggle="modal" data-target="#trainModal" class="btn btn-info center-block"><i class="glyphicon glyphicon-list-alt"></i> View</button></li>
   </ul>
      <div class="arrow"></div>
    </div>
  </li>

</ul>
</div>
<?php  $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?> 
<p colspan="7" style="text-align:center;"><br><br><strong>No Results</strong><br><br></p>      
<?php endif; ?>
</div>