<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Training extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('trainings', function (Blueprint $table) {
               //1
               $table->increments('id')->unsigned();
               //2
               $table->string('Title_Trining');
               //3
               $table->string('Trainer_Name');
                  //4
                  $table->mediumText('Training_Course_Duration');
                     //5
               $table->string('Status');
                  //6
                  $table->string('Training_Place');
                     //7
               $table->date('Training_Start_Date');
               //8
               $table->date('Training_End_Date');
               //9
               $table->string('add_by');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('trainings');
    }
}
