<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddToInboxMessages extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::table('messages_inboxes', function ( $table) {
            $table->integer('Positions_id');
            $table->foreign('Positions_id')->references('id')->on('postions')->onDelete('cascade');
            $table->integer('departments_id');
            $table->foreign('departments_id')->references('id')->on('departments')->onDelete('cascade');
            $table->string('group_parent')->nullable();
           //
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        Schema::table('messages_inboxes', function ( $table) {
            $table->dropColumn('Positions_id');
            $table->dropColumn('departments_id');
            $table->dropColumn('group_parent');
    });
    }
}
