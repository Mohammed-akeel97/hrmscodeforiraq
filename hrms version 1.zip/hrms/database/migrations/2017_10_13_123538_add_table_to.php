<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddTableTo extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create('messages_inboxe_tos', function (Blueprint $table) {
            //1
            $table->increments('id')->unsigned();
            //2
            $table->string('to_msg');
            $table->string('messages_inboxes_id');
            $table->string('is_read');
         $table->timestamps();
     });
; 
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        Schema::dropIfExists('messages_inboxes');
    }
}
