<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Position extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
                   //
                   Schema::create('postions', function (Blueprint $table) {
                    //1
                    $table->increments('id')->unsigned();
                    //2
                    $table->string('name_postion');
               
                
        
                 $table->timestamps();
             });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
             //
             Schema::dropIfExists('postions');
    }
}
