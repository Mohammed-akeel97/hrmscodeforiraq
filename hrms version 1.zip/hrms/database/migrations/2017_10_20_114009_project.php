<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Project extends Migration
{
   /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('projects', function (Blueprint $table) {
            //1
            $table->increments('id')->unsigned();
            //1
            $table->string('Project_Name');
            //1
            $table->longText('Project_Description');
            //1
            $table->longText('Project_Requirement');
            //1
            $table->string('Project_Provider');
            //1
            $table->string('Team_Responsible');
            //1
            $table->date('Project_Start_Date');
            //1
            $table->date('Estimate_Project_Time');
            //1
            $table->longText('Project_Report');
            //1
            $table->timestamps();
            
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('prjects'); 
    }
}
