<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class MessagesInbox extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create('messages_inboxes', function (Blueprint $table) {
            //1
            $table->increments('id')->unsigned();
            //2
            $table->string('title_message');
            //3
          
              

            $table->longText('full_message');
                    //5

                    $table->string('name_sender');
                         //6

                         $table->string('email_sender');
                          //7
                          $table->string('department_sender');
                          //8
                          $table->string('department_received');
                          //9
                  
         $table->timestamps();
     });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    
            Schema::dropIfExists('messages_inboxes');
        
    }
}
