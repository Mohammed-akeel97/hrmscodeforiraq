<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddReplaysInbox extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create('messages_inboxes_replays', function (Blueprint $table) {
            //1
            $table->increments('id')->unsigned();
            //2
            $table->longText('detailes_replay');
            $table->integer('messages_inboxes_id');
            $table->foreign('messages_inboxes_id')->references('id')->on('messages_inboxes')->onDelete('cascade');
            $table->string('replay_email');
            $table->string('replay_name');
            $table->string('replay_department_id');
            $table->string('replay_position_id');
         $table->timestamps();
     });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        Schema::dropIfExists('messages_inboxes_replays');
    }
}
