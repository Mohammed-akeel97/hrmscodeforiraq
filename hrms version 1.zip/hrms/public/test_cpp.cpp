#include<iostream>
#include<string.h>
using namespace std;
int main(int argc, char *argv[]) {
cout<<"hello word";
}


