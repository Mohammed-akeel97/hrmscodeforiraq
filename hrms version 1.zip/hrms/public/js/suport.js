
  //************************************************************* */
  function myFunction(selTag) {
    
      var x = selTag.selectedIndex;
      var pg=document.getElementById("Parent_Group");
      if(x==1){
  pg.disabled = true;
  pg.getElementsByTagName('option')[0].selected = 'selected';
      }
      if(x==2)
  pg.disabled = false;
  }
  function get_position(x) {
    
    
      var pg=document.getElementById("Parent_Group");
      if(x==1){
  pg.disabled = true;
  pg.getElementsByTagName('option')[0].selected = 'selected';
      }
      if(x==2)
  pg.disabled = false;
  }
//************************************************ */
function get_days(str){
var new_str=str.split('-');
var int_mounth=parseInt(new_str[1]);
var mounth;
var sum=0;
for(var i=1;i<int_mounth;i++){
switch (i){
case 1:mounth=31;
case 2:mounth=29;
case 3:mounth=31;
case 4:mounth=30;
case 5:mounth=31;
case 6:mounth=30;
case 7:mounth=31;
case 8:mounth=31;
case 9:mounth=30;
case 10:mounth=31;
case 11:mounth=30;
case 12:mounth=30;
}
sum+=mounth;
}
var days=sum+parseInt(new_str[2]);

return days;

}
  //************************************************* */

//*********************************************8888 */
function add(){
	i++;
	
	document.getElementById('msg_num').innerText=i;
//	document.getElementById('vnotification').play();

}
//************************88888 */
//********************************************88 */
function num_message() {

    var msg_num=document.getElementById('msg_num').innerText;
    var token = document.getElementsByTagName('input').item(name="_token").value;
    var data = "";
                    var xhr =new XMLHttpRequest();
                xhr.onreadystatechange=function (){
                    if(xhr.readyState==4&&xhr.status==200){
                       var new_num_msg=xhr.responseText;
                       var int_new_num_msg=parseInt(new_num_msg);
                       var int_num_msg=parseInt(msg_num);
                       if(int_new_num_msg>int_num_msg){
                        document.getElementById('msg_num').innerText=int_new_num_msg;
                            document.getElementById('vnotification').play();
                            announcement_noti();
                           
                       }else {
                        document.getElementById('msg_num').innerText=int_new_num_msg;
                       }

                      }
                      dis();
                }
    
                xhr.open("POST",host+"/num_messages",true);
            //   xhr.setRequestHeader('X-CSRF-TOKEN', 'XMLHttpRequest');
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
               xhr.setRequestHeader("X-CSRF-TOKEN",token);
           
                xhr.send(data);
    
     
    
  
     
    
      
    }
      //********************** */

      function dis(){
        var msg_num=document.getElementById('msg_num').innerText;
        var int_num_msg=parseInt(msg_num);
        if(int_num_msg==0){
          //  msg_num.style.visibility = "hidden" ;
            $('#msg_num').css('display','none');
            $('#msg_num').css('visibility','hidden');
        }else {
          //  msg_num.style.visibility = "visible";
          
          
            $('#msg_num').css('display','');
            $('#msg_num').css('visibility','visible');
        }
      }
    //   *********************************88
    function get_manager(selTag) {
        
          var x = selTag.selectedIndex;
          var pg=document.getElementById("Parent_Group");
      var arr_m=[];
var j=1;
arr_m[0]='<option selected="selected" disabled="disabled" hidden="hidden" value="">Manager Name</option>';
for(var i=0;i<arr_manager.length;i++){
    if(arr_manager[i].departments_id==x){
        arr_m[j]="<option value='"+arr_manager[i].emailManager+"'>"+arr_manager[i].nameManager+" / "+arr_manager[i].emailManager+"</option>";
   j++;

    }
    
}
pg.innerHTML=arr_m;
      }

    //   ************************************************************
        function get_select_manager(x,manager) {
        
       
          var mg=document.getElementById("Parent_Group");
      var arr_m=[];
var j=1;
arr_m[0]='<option  disabled="disabled" hidden="hidden" value="">Manager Name</option>';
for(var i=0;i<arr_manager.length;i++){
    if(arr_manager[i].departments_id==x){
        if(manager==arr_manager[i].emailManager)
        arr_m[j]="<option selected='selected' value='"+arr_manager[i].emailManager+"'>"+arr_manager[i].nameManager+" / "+arr_manager[i].emailManager+"</option>";
   else 
   arr_m[j]="<option value='"+arr_manager[i].emailManager+"'>"+arr_manager[i].nameManager+" / "+arr_manager[i].emailManager+"</option>";
        j++;

    }
    
}
mg.innerHTML=arr_m;
      }


      function isEmpty(val){
        return (val === undefined || val == null || val.length <= 0) ? true : false;
    }




    function get_ckeditor(id_name){
        if( document.getElementById('article-ckeditor'))
        document.getElementById('article-ckeditor').id="none";
if(document.getElementById(id_name)){
    document.getElementById(id_name).id="article-ckeditor";
CKEDITOR.replace( 'article-ckeditor' );  
}  
    }
    function get_ckeditor_class(class_name){
        if( document.getElementById('article-ckeditor'))
        document.getElementById('article-ckeditor').id="none"
        document.getElementsByClassName(class_name).id="article-ckeditor";
        CKEDITOR.replace( 'article-ckeditor' );
    }


    function show_password_action(){
        var btn=document.getElementById('show_password');
   var Password=document.getElementById('password');
   var confirmPassword=document.getElementById('password-confirm');
   var icon_show_password=document.getElementById('icon_show_password');
   if(btn.value==0){
   password.type="text";
   confirmPassword.type="text";
      icon_show_password.className="glyphicon glyphicon-eye-close";
   btn.value=1;
      
   }else{
   password.type="password";
   confirmPassword.type="password";
    icon_show_password.className="glyphicon glyphicon-eye-open";
   btn.value=0;
   }
   
   
   
   
   }