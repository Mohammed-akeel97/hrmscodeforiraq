
function modal_message_sent_fun(index,id,msg_id) {
  get_ckeditor('detailes_replay_sent');
  var loading_img=host+'/Images/loading.gif';
var html_img='<div align="center"><img width="200"   src="" id="img_loading_sent"></div>'
  document.getElementById('sent_replay').innerHTML=html_img;
 document.getElementById('img_loading_sent').src=loading_img;
  document.getElementById('replay_id_sent').value=msg_id;
  get_sent_replay_sent(msg_id);
    //1
    var message_sent_name_sender=document.getElementById('message_sent_name_sender['+index+']').innerText;
     //2
     var message_sent_title_message=document.getElementById('message_sent_title_message['+index+']').innerText;
       //3
       var message_sent_department_sender=document.getElementById('message_sent_department_sender['+index+']').innerText;
          //4
          var message_sent_created_at=document.getElementById('message_sent_created_at['+index+']').innerText;
            //5
            var message_sent_full_message=document.getElementById('message_sent_full_message['+index+']').innerHTML;
            
    //6
    var message_sent_email_sender=document.getElementById('message_sent_email_sender['+index+']').innerText;
      //7
      var message_sent_department_received=document.getElementById('message_sent_department_received['+index+']').innerText;
        //8
        var is_sent=document.getElementById('is_sent['+index+']').innerText;
        
   
   //1
    document.getElementById('message_sent_name_sender').innerText=message_sent_name_sender;
       //2
       document.getElementById('message_sent_title_message').innerText=message_sent_title_message;
       
    //3
    document.getElementById('message_sent_department_sender').innerText=message_sent_department_sender;
        //4
        document.getElementById('sent_sent_at').innerText=message_sent_created_at;
       //5
       document.getElementById('message_sent_full_message').innerHTML=message_sent_full_message;
     //6
       document.getElementById('message_sent_email_sender').innerText=message_sent_email_sender;
         //7
     document.getElementById('message_sent_department').innerText=message_sent_department_received;
   if(is_sent!="0"){
    document.getElementById('status_sent').innerText="Displayed";
    document.getElementById('dicon').className="glyphicon glyphicon-ok-sign";
   }else{
    document.getElementById('status_sent').innerText="Not Displayed";
    document.getElementById('dicon').className="glyphicon glyphicon-remove-sign";
   }
}
//********************************************* */




function modal_read_message_received_fun(index,id,msg_id) {
get_ckeditor('detailes_replay');
// document.getElementById('detailes_replay').id="article-ckeditor";
  var loading_img=host+'/Images/loading.gif';
  var html_img='<div align="center"><img width="200"   src="" id="img_loading"></div>'
  document.getElementById('received_replay').innerHTML=html_img;
  document.getElementById('img_loading').src=loading_img;
  document.getElementById('replay_id').value=msg_id;
  get_sent_replay_received(msg_id);
    //1
    var message_received_name_sender=document.getElementById('message_received_name_sender['+index+']').innerText;
     //2
     var message_received_title_message=document.getElementById('message_received_title_message['+index+']').innerText;
       //3
       var message_received_department_sender=document.getElementById('message_received_department_sender['+index+']').innerText;
          //4
          var message_received_created_at=document.getElementById('message_received_created_at['+index+']').innerText;
            //5
            var message_received_full_message=document.getElementById('message_received_full_message['+index+']').innerHTML;
            
    //6
    var message_received_email_sender=document.getElementById('message_received_email_sender['+index+']').innerText;
      //7
      var message_received_department_received=document.getElementById('message_received_department_received['+index+']').innerText;
           //8
           var message_received_position=document.getElementById('message_received_position['+index+']').innerText;
      
                //9
      var message_received_group_parent=document.getElementById('message_received_group_parent['+index+']').innerText;
      
   
   //1
    document.getElementById('message_received_name_sender').innerText=message_received_name_sender;
       //2
       document.getElementById('message_received_title_message').innerText=message_received_title_message;
       
    //3
    document.getElementById('message_received_department_sender').innerText=message_received_department_sender;
        //4
        document.getElementById('sent_at').innerText=message_received_created_at;
       //5
       document.getElementById('message_received_full_message').innerHTML=message_received_full_message;
     //6
       document.getElementById('message_received_email_sender').innerText=message_received_email_sender;
         //7
     document.getElementById('message_received_department_received').innerText=message_received_department_received;
           //8
           document.getElementById('message_received_position').innerText=message_received_position;
  
                  //9
     document.getElementById('message_received_group_parent').innerText=message_received_group_parent;
    
     if(isEmpty(message_received_group_parent)){
      //  msg_num.style.visibility = "hidden" ;
        $('#message_received_group_parent_a').css('display','none');
        $('#message_received_group_parent_a').css('visibility','hidden');
    }else {
      //  msg_num.style.visibility = "visible";
      
      
        $('#message_received_group_parent_a').css('display','');
        $('#message_received_group_parent_a').css('visibility','visible');
    }
     read_message(index,id)
}
//********************************************88 */
function read_message(index,announcement_id) {

  var token = document.getElementsByTagName('input').item(name="_token").value;
 var data = "id="+announcement_id;

                var xhr =new XMLHttpRequest();
            xhr.onreadystatechange=function (){
                if(xhr.readyState==4&&xhr.status==200){
                    document.getElementById('message_class['+index+']').className="list-group-item";
                    document.getElementById('message_star['+index+']').className="glyphicon glyphicon-star-empty";
                   // document.getElementById('message_replay_text').setAttribute("name", "replay_message["+msg_id+"]");
               //    document.getElementById('message_received_name_sender').innerText=xhr.responseText;
                  }
            }

            xhr.open("POST",host+"/read_announcement",true);
    
        //   xhr.setRequestHeader('X-CSRF-TOKEN', 'XMLHttpRequest');
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
           xhr.setRequestHeader("X-CSRF-TOKEN",token);
       
            xhr.send(data);

 

//********************** */
 

  
}
// *****************************************888
function get_sent_replay_received(id){
  var token = document.getElementsByTagName('input').item(name="_token").value;
  var data = "id="+id;
 
                 var xhr =new XMLHttpRequest();
             xhr.onreadystatechange=function (){
                 if(xhr.readyState==4&&xhr.status==200){
                  document.getElementById('received_replay').innerHTML=xhr.responseText;
              }
             }
 
             xhr.open("POST",host+"/get_replay",true);
     
         //   xhr.setRequestHeader('X-CSRF-TOKEN', 'XMLHttpRequest');
         xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.setRequestHeader("X-CSRF-TOKEN",token);
        
             xhr.send(data);
}
//***************************************************8 */
function get_sent_replay_sent(id){
  var token = document.getElementsByTagName('input').item(name="_token").value;
  var data = "id="+id;
 
                 var xhr =new XMLHttpRequest();
             xhr.onreadystatechange=function (){
                 if(xhr.readyState==4&&xhr.status==200){
                  document.getElementById('sent_replay').innerHTML=xhr.responseText;
              }
             }
 
             xhr.open("POST",host+"/get_replay",true);
     
         //   xhr.setRequestHeader('X-CSRF-TOKEN', 'XMLHttpRequest');
         xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.setRequestHeader("X-CSRF-TOKEN",token);
        
             xhr.send(data);
}
