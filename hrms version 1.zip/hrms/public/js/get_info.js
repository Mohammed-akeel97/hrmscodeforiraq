function get_info(index){
// get info
    //1
    var Full_Name=document.getElementById('Full_Name['+index+']').innerText;
    //2
    var Volunteer_Code=document.getElementById('Volunteer_Code['+index+']').innerText;
    //3
var Position=document.getElementById('Position['+index+']').innerText;
    //4
    var Specialization=document.getElementById('Specialization['+index+']').innerText;
    //5
    var Governorate=document.getElementById('Governorate['+index+']').innerText;
    //6
    var Gender=document.getElementById('Gender['+index+']').innerText;
  

  //7
  var email=document.getElementById('email['+index+']').innerText;
  //8
  var parent_group=document.getElementById('parent_group['+index+']').innerText;
  //9
  var Day_of_Birth=document.getElementById('Day_of_Birth['+index+']').innerText;


  //10
  var Acadimic_Achievement=document.getElementById('Acadimic_Achievement['+index+']').innerText;
  //11
  var New_Pecture=document.getElementById('New_Pecture['+index+']').innerText;
  //12
  var Address=document.getElementById('Address['+index+']').innerText;


  //13
  var Experience=document.getElementById('Experience['+index+']').innerHTML;
  //14
//  var created_at=document.getElementById('created_at['+index+']').innerText;
  //15
  var Blood_Group=document.getElementById('Blood_Group['+index+']').innerText;


  //16
  var Phone_Number1=document.getElementById('Phone_Number1['+index+']').innerText;
  //17
  var Phone_Number2=document.getElementById('Phone_Number2['+index+']').innerText;
  //18
 var Twitter=document.getElementById('Twitter['+index+']').innerText;


  //19
 var facebook=document.getElementById('facebook['+index+']').innerText;
  //20
 var Instagram=document.getElementById('Instagram['+index+']').innerText;
  //21
var how_add=document.getElementById('how_add['+index+']').innerText;


  //22
 var created_at=document.getElementById('created_at['+index+']').innerText;

  //23
var Marital_Status=document.getElementById('Marital_Status['+index+']').innerText;

  //23
  var New_Pecture=document.getElementById('New_Pecture['+index+']').innerText;
  New_Pecture='/pictures/'+New_Pecture;





    // set info
    //1
    document.getElementById('Full_Name').innerText=Full_Name;
    //2
    document.getElementById('Volunteer_Code').innerText=Volunteer_Code;
    //3
   document.getElementById('Position').innerText=Position;
   
   
        //4
        document.getElementById('Specialization').innerText=Specialization;
        //5
     document.getElementById('Governorate').innerText=Governorate;
        //6
        document.getElementById('Gender').innerText=Gender;
       
       //7
       document.getElementById('email').innerText=email;
       //8
       document.getElementById('parent_group').innerText=parent_group;
       //9
       document.getElementById('Day_of_Birth').innerText=Day_of_Birth;
      
       //10
       document.getElementById('Acadimic_Achievement').innerText=Acadimic_Achievement;
       //11
       document.getElementById('New_Pecture').src=New_Pecture;
       //12
       document.getElementById('Address').innerText=Address;
      // 13 Experience
      document.getElementById('Experience').innerHTML=Experience;
       //14
document.getElementById('New_Pecture').src=New_Pecture;
       //15
       document.getElementById('Blood_Group').innerText=Blood_Group;
       //16
       document.getElementById('Phone_Number1').innerText=Phone_Number1;
      
       //17
       document.getElementById('Phone_Number2').innerText=Phone_Number2;
       //18
  document.getElementById('Twitter').innerText=Twitter;
       //19
    document.getElementById('facebook').innerText=facebook;
      
       //20
   document.getElementById('Instagram').innerText=Instagram;
       //21
 document.getElementById('how_add').innerText=how_add;
       //21
 document.getElementById('created_at').innerText=created_at;
     // 23
     document.getElementById('Marital_Status').innerText=Marital_Status;
                         
}
function get_info_project(index){
// get info
    //1
    var Project_Name=document.getElementById('Project_Name['+index+']').innerText;
    //2
    var Project_Provider=document.getElementById('Project_Provider['+index+']').innerText;
    //3
var Project_Start_Date=document.getElementById('Project_Start_Date['+index+']').innerText;
    //4
    var Team_Responsible=document.getElementById('Team_Responsible['+index+']').innerText;
    //5
    var Estimate_Project_Time=document.getElementById('Estimate_Project_Time['+index+']').innerText;
    //6
    var Project_Requirement=document.getElementById('Project_Requirement['+index+']').innerHTML;
  

  //7
  var Project_Description=document.getElementById('Project_Description['+index+']').innerHTML;
  //8
  var Project_Report=document.getElementById('Project_Report['+index+']').innerHTML;


     // set info
    //1
    document.getElementById('Project_Name').innerText=Project_Name;
    //2
    document.getElementById('Project_Provider').innerText=Project_Provider;
    //3
   document.getElementById('Project_Start_Date').innerText=Project_Start_Date;
   
   
        //4
        document.getElementById('Team_Responsible').innerText=Team_Responsible;
        //5
     document.getElementById('Estimate_Project_Time').innerText=Estimate_Project_Time;
        //6
        document.getElementById('Project_Requirement').innerHTML=Project_Requirement;
       
       //7
       document.getElementById('Project_Description').innerHTML=Project_Description;
       //8
       document.getElementById('Project_Report').innerHTML=Project_Report;
}
function get_info_training(index){
  // get info
      //1
      var Title_Trining=document.getElementById('Title_Trining['+index+']').innerText;
      //2
      var Trainer_Name=document.getElementById('Trainer_Name['+index+']').innerText;
      //3
  var Training_Course_Duration=document.getElementById('Training_Course_Duration['+index+']').innerHTML;
      //4
      var Status=document.getElementById('Status['+index+']').innerText;
      //5
      var Training_Place=document.getElementById('Training_Place['+index+']').innerText;
      //6
      var Training_Start_Date=document.getElementById('Training_Start_Date['+index+']').innerText;
    //7
    var Training_End_Date=document.getElementById('Training_End_Date['+index+']').innerText;
    //8
    var add_by=document.getElementById('add_by['+index+']').innerText;
  
  
  
    //********************************************************* */
      // set info
      //1
      document.getElementById('Title_Trining').innerText=Title_Trining;
      //2
      document.getElementById('Trainer_Name').innerText=Trainer_Name;
      //3
     document.getElementById('Training_Course_Duration').innerHTML=Training_Course_Duration;
     
     
          //4
          document.getElementById('Status').innerText=Status;
          //5
       document.getElementById('Training_Place').innerText=Training_Place;
          //6
          document.getElementById('Training_Start_Date').innerText=Training_Start_Date;
       
         //7
       
         document.getElementById('Training_End_Date').innerText=Training_End_Date;
         
         //8
         document.getElementById('add_by').innerText=add_by;
         //9
         Training_End_Date_new =get_days(Training_End_Date);
         Training_Start_Date_new =get_days(Training_Start_Date);
         //
         document.getElementById('Duration').innerText=Training_End_Date_new-Training_Start_Date_new+" Day";
        
    }