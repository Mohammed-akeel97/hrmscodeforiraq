@extends('layouts.general')

@section('form_reg')

<fieldset style="padding: 20px;"> 
{!! Form::open(['action' => ['Volunteer_controller@update',$get_volunteer->id], 'method'=>'POST','enctype'=>'multipart/form-data']) !!}

{{ csrf_field() }}



@if (session('success'))
<div class="container">
<div class="row col-md-8 col-md-offset-2">
<div class="alert alert-success alert-success fade in">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
<strong>Success!</strong>  {{session('success')}}.
</div>
</div>
</div>
@endif
@if (session('errors'))
<div class="container">
<div class="row col-md-8 col-md-offset-2">
<div class="alert alert-success alert-danger fade in">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Danger!</strong> Not Successful  You Have Fileds.
  </div>
</div>
</div>
@endif
<link href="{{ asset('css/add.css') }}" rel="stylesheet">

	 <!--this was made my Agil Asadi. You are free to delete this comment line and use it as you wish-->   
<div class="container">

	<div class="row">
		<h2 class="headerSign" style="">Update Volunteer</h2>

	</div>
</div>
<div class="row col-md-8 col-ms-5 col-md-offset-2 registeration" style="z-index:100;background-color:rgba(255,255,255,0.8)">
    
<div class="registerInner">
<!-- ********************************  lift -->
        <div class="col-md-6 signUp">



<!-- ******************************* Group Information -->
@include('hrm.volunteer.Update.points.Group_Information')

<!-- ******************************* Specialty Information -->
@include('hrm.volunteer.Update.points.Specialty_Information')
<!-- ******************************* Means of communication -->
@include('hrm.volunteer.Update.points.Means_communication')

<!-- ******************************* Social Media Contact-->
@include('hrm.volunteer.Update.points.social_m')


 </div>
<!-- ********************************  right -->       
        <div class="col-md-6">
 <!-- ******************************* Personal Information-->

 @include('hrm.volunteer.Update.points.Personal_Information')
 <!-- ******************************* Address-->
  @include('hrm.volunteer.Update.points.Address')
  
<!-- ******************************* other  information-->

 @include('hrm.volunteer.Update.points.other_information')
<!-- ******************************* Passowrd-->

           @include('hrm.volunteer.Update.points.Password')                                                <!-- *********************************************************************  -->

 
                    
           </div>
           <!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
                                    <!-- *********************************************************************  -->
           <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                           <h3 class="headerSign" align="center">{{$title_panel_Save_Changes}}</h3>
                                     <!-- *********************************************************************  -->
            <div class="form-group"> 
            {{Form::hidden('_method','PUT' ) }}
                {{Form::submit('save',['class'=>'signbuttons btn btn-primary pull-right' ] ) }}
                          </div>  
                                     <br>
           <br>	
                                     <br>
           <br>		  
           <!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
                       
                   </div>
                        
           </div>
                  
           </div>
{!! Form::close() !!}
</fieldset> 

@endsection