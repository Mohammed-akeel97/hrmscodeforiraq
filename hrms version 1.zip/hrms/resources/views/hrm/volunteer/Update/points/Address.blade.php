    
         <h3 class="headerSign" align="center">{{$title_panel_Address}}</h3>
                <!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^  -->

                <div class="form-group">                    

                     
                {{Form::label($Governorate, $Governorate)}}<span style="color:red;font-size:18pt;">*</span>
           
                    {{ Form::select('Governorate', [
                        'Governorate' => $Governorates,             ]
                        ,$get_volunteer->Governorate,['class'=>'form-control','placeholder'=>'Governorate',]
) }}
@if ($errors->has('Governorate'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('Governorate') }}</strong>
                                    </span>
                                @endif
                </div>
         <!--***********************************  -->








                <!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^  -->
                          <!-- *********************************************************************  -->
    <div class="form-group">                    
                    {{Form::label('Address', $Address)}}<span style="color:red;font-size:18pt;">*</span>
                {{Form::text('Address',$get_volunteer->Address,['class'=>'form-control','placeholder'=>$Address]  ) }}
                @if ($errors->has('Address'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('Address') }}</strong>
                                    </span>
                                @endif
                </div>
                                          <!-- *********************************************************************  -->
  

