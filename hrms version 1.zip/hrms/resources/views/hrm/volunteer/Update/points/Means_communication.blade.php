                <!--***********************************  -->
 <h3 class="headerSign" align="center">{{$title_panel_Means_of_communication}}</h3>
 <!-- *********************************************************************  -->

 <!-- *********************************************************************  -->
                <div class="form-group {{ $errors->has('email') ? 'errorfiled' : '' }}">
         
                    {{Form::label('email', $email)}}<span style="color:red;font-size:18pt;">*</span>
      {{Form::email('email',$get_volunteer->email,['class'=>'form-control','placeholder'=>$email]  ) }}
      @if ($errors->has('email'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
</div>
<!-- *********************************************************************  -->
                <div class="form-group">
                {{Form::label('Phone_Number1', $Phone_Number1)}}<span style="color:red;font-size:18pt;">*</span>
                {{Form::text('Phone_Number1',$get_volunteer->Phone_Number1,['class'=>'form-control','placeholder'=>$Phone_Number1]  ) }}
                @if ($errors->has('Phone_Number1'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('Phone_Number1') }}</strong>
                                    </span>
                                @endif
            </div>
<!-- *********************************************************************  -->
<!-- *********************************************************************  -->
<div class="form-group">
{{Form::label('Phone_Number2', $Phone_Number2)}}
{{Form::text('Phone_Number2',$get_volunteer->Phone_Number2,['class'=>'form-control','placeholder'=>$Phone_Number2]  ) }}
</div>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
  
           
