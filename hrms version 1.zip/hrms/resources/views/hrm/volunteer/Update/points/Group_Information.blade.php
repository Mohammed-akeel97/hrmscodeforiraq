
 <script type="text/javascript" src="{{ asset('js/suport.js')}}"></script>
     <h3 class="headerSign">{{$title_panel_Group_Information}}</h3>
     <!-- *******************************  -->
     <?php
$departments_arr=array ();
foreach ($get_depatment as $depratment){
    $departments_arr[$depratment->id]=$depratment->name_department;
}
     ?>
        <script>
    var arr_manager=[];
          <?php
          $i=0;
          $dpt_mng="";
foreach ($get_manager as $manager){
    $json="{nameManager:'".$manager->Full_Name."',emailManager:'".$manager->email."',departments_id:".$manager->departments_id."}";
echo "arr_manager[".$i."]=".$json."\n";
$i++;

}
     ?>
 

</script>

     {{--  ***********************  --}}
 
                <div class="form-group">                    
                {{Form::label('departments', 'Department')}}<span style="color:red;font-size:18pt;">*</span>
           
                    {{ Form::select('departments',$departments_arr,$get_volunteer->departments_id,['class'=>'form-control','placeholder'=>'Department','onchange'=>'get_manager(this)']
) }}
                </div>
                @if ($errors->has('departments'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('departments') }}</strong>
                                    </span>
                                @endif
                <!-- **************************** -->
                     <?php
$postion_arr=array ();
foreach ($get_postion as $postion){
    $postion_arr[$postion->id]=$postion->name_postion;
}
     ?>
                  <div class="form-group" >                    
                {{Form::label('Position', 'Position')}}<span style="color:red;font-size:18pt;">*</span>
           
                    {{ Form::select('Position',$postion_arr,$get_volunteer->Positions_id,['class'=>'form-control','placeholder'=>'Position','onchange'=>'myFunction(this)']
) }}
@if ($errors->has('Position'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('Position') }}</strong>
                                    </span>
                                @endif
                </div>
                   <!-- get managers **********************************  -->

           <div class="form-group">                    

              
                {{Form::label('Parent_Group', $Parent_Group)}}
         
                    {{ Form::select('Parent_Group', [
                        $Parent_Group =>'',               
   ],'',['class'=>'form-control','placeholder'=>$Parent_Group_title,]
) }}
                </div>
         <!--***********************************  -->
         <script>

get_select_manager({{$get_volunteer->departments_id}},<?php echo "'".$get_volunteer->parent_group."'";?>);
         get_position({{$get_volunteer->Positions_id}});
</script>