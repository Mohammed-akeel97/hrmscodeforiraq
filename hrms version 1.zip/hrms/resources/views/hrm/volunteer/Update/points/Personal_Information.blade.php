                     <h3 class="headerSign" align="center">{{$title_panel_Personal_Information}}</h3>
           

      <!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
                <div class="form-group">
            {{Form::label('Full_Name', $Full_Name)}}<span style="color:red;font-size:18pt;">*</span>
                {{Form::text('Full_Name',$get_volunteer->Full_Name,['class'=>'form-control','placeholder'=>$Full_Name]  ) }}
                @if ($errors->has('Full_Name'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('Full_Name') }}</strong>
                                    </span>
                                @endif
</div>
<!-- *********************************************************************  -->

    <div class="form-group">                    
         
                    {{Form::label('Gender', $Gender)}}<span style="color:red;font-size:18pt;">*</span>
           
                    {{ Form::select('Gender', [
                        $Gender_Male => $Gender_Male,         $Gender_Female => $Gender_Female,          
   ],$get_volunteer->Gender,['class'=>'form-control','placeholder'=>$Gender,]
) }}
@if ($errors->has('Gender'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('Gender') }}</strong>
                                    </span>
                                @endif
                </div>
                <!-- *********************************************************************  -->

    <div class="form-group">                    
                {{Form::label('Day_of_Birth', $Day_of_Birth)}}<span style="color:red;font-size:18pt;">*</span>
                {{Form::date('Day_of_Birth',$get_volunteer->Day_of_Birth,['class'=>'form-control','placeholder'=>$Day_of_Birth]  ) }}

                @if ($errors->has('Day_of_Birth'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('Day_of_Birth') }}</strong>
                                    </span>
                                @endif
                </div>
                <!-- *********************************************************************  -->