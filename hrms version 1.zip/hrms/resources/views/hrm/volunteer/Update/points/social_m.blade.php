<h3 class="headerSign" align="center">{{$title_panel_social_m}}</h3>

                          <!-- *********************************************************************  -->
    <div class="form-group">                    
                 {{Form::label('facebook', $facebook)}}
                {{Form::text('facebook',$get_volunteer->facebook,['class'=>'form-control','placeholder'=>$facebook]  ) }}
                @if ($errors->has('facebook'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('facebook') }}</strong>
                                    </span>
                                @endif
                    
                </div>
                                          <!-- *********************************************************************  -->
  
                        <!-- *********************************************************************  -->
    <div class="form-group">                    
              {{Form::label('Instagram', $Instagram)}}
                {{Form::text('Instagram',$get_volunteer->Instagram,['class'=>'form-control','placeholder'=>$Instagram]  ) }}
                @if ($errors->has('Instagram'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('Instagram') }}</strong>
                                    </span>
                                @endif
                </div>
                                          <!-- *********************************************************************  -->
                       <!-- *********************************************************************  -->
    <div class="form-group">                    
                    {{Form::label('Twitter', $Twitter)}}
                {{Form::text('Twitter',$get_volunteer->Twitter,['class'=>'form-control','placeholder'=>$Twitter]  ) }}    
                @if ($errors->has('Twitter'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('Twitter') }}</strong>
                                    </span>
                                @endif
              </div>
                                          <!-- *********************************************************************  -->
  

