                              <!--***********************************  -->
 <h3 class="headerSign" align="center">{{$title_panel_Specialty_Information}}</h3>
 <!-- *********************************************************************  -->
 
    <div class="form-group">                    
        
                    {{Form::label('Acadimic_Achievement', $Acadimic_Achievement)}}<span style="color:red;font-size:18pt;">*</span>
           
                    {{ Form::select('Acadimic_Achievement', [
                        $Acadimic_Achievement_High_School => $Acadimic_Achievement_High_School,    
                        $Acadimic_Achievement_diploma => $Acadimic_Achievement_diploma,   
                        $Acadimic_Achievement_Bachelor => $Acadimic_Achievement_Bachelor,   
                        $Acadimic_Achievement_Master => $Acadimic_Achievement_Master,   
                        $Acadimic_Achievement_Doctorate => $Acadimic_Achievement_Doctorate,   
                        $Acadimic_Achievement_not => $Acadimic_Achievement_not,              
   ],$get_volunteer->Acadimic_Achievement,['class'=>'form-control','placeholder'=>$Acadimic_Achievement,]
) }}
@if ($errors->has('Acadimic_Achievement'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('Acadimic_Achievement') }}</strong>
                                    </span>
                                @endif
                </div>
                <!-- *********************************************************************  -->
 <!-- *********************************************************************  -->
                <div class="form-group">
       
                    {{Form::label('Specialization', $Specialization)}}<span style="color:red;font-size:18pt;">*</span>
                {{Form::text('Specialization',$get_volunteer->Specialization,['class'=>'form-control','placeholder'=>$Specialization]  ) }}
                @if ($errors->has('Specialization'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('Specialization') }}</strong>
                                    </span>
                                @endif
</div>
<!-- *********************************************************************  -->
                <div class="form-group">
            {{Form::label('Experience', $Experience)}}<span style="color:red;font-size:18pt;">*</span>
                {{Form::textarea('Experience',$get_volunteer->Experience,['class'=>'form-control','placeholder'=>$Experience,'id'=>'article-ckeditor']  ) }}
                @if ($errors->has('Experience'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('Experience') }}</strong>
                                    </span>
                                @endif
</div>
<!-- *********************************************************************  -->
<script>

      CKEDITOR.replace( 'article-ckeditor' );
  </script>