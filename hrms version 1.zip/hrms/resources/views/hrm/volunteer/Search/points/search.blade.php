 <div class="row">
          <div class=" col-md-12">
            <h2 class="" style=""> <span class="glyphicon glyphicon-list-alt"> </span> Search Volunteers </h2>
          </div>
          <div class=" col-md-12">
            <div class=" col-md-12">
              <div class=" col-md-12">
              <div class=" col-md-12">
              <!-- Modal -->
              {!! Form::open(['action' => ['Volunteer_controller@results_search'], 'method'=>'POST']) !!}
<a class="btn btn-info  pull-right" href="#SearchModal" data-toggle="modal" title="" data-original-title="Search" aria-expanded="true">  <i class="glyphicon glyphicon-search"></i>  Search</a> 
<!-- Modal -->
              @include('hrm.volunteer.Search.points.modal_search')
              {!! Form::close() !!}
              </div>
    
              </div>
            </div>
          </div>
        </div>