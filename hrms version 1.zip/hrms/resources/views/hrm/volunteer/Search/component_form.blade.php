<link href="{{ asset('css/edit_vol.css') }}" rel="stylesheet">
<link href="{{ asset('css/add.css') }}" rel="stylesheet">       
@extends('layouts.general')

@section('panel_edit')
 <div class="container-fluid">
    <div class="panel panel-info">
    <div class="panel-heading color_panel" style="color:white;">
    @include('hrm.volunteer.Search.points.search')
      </div>

   @include('hrm.volunteer.Search.points.table')
   @include('hrm.volunteer.Edit.points.modal_show')

      <div class="panel-footer">
        <div class="row">
          <div class="col-lg-12">
            <div class="col-md-12">
              </div>
              <div class="col-md-12">
              <p class="muted pull-right"><strong> © 2017 All rights reserved Code For Iraq </strong></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  @endsection