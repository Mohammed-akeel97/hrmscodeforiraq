    

            
@extends('layouts.general')

@section('panel_edit')
@include('hrm.volunteer.Edit.points.delete_modal')
<link href="{{ asset('css/add.css') }}" rel="stylesheet">  
<div class="col-md-12">
 <div class="container-fluid">
    <div class="panel panel-info" style="font-size:16;">
    <div class="panel-heading color_panel" style="color:white;">
       @include('hrm.volunteer.Edit.points.search')
      </div>
 
 @include('hrm.volunteer.Edit.points.table')
 @include('hrm.volunteer.Edit.points.modal_show')

      <div class="panel-footer">
        <div class="row ">
          <div class="col-lg-12 pull-righ">
            <div class="col-md-12">
            @if(count($Volunteers) >0)
            {{$Volunteers->links()}}
            @endif
              </div>
              <div class="col-md-12">
              <p class="muted pull-right"><strong> © 2017 All rights reserved Code For Iraq </strong></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
  @endsection