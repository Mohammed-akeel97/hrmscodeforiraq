
	            <div class="container">  
				
                <div class="jumbotron">
                    
                    
                    
                  <div class="row">
                      <div class="col-md-3 col-xs-12 col-sm-6 col-lg-3">
                        <div class="thumbnail text-center photo_view_postion_b">
                          <img id="New_Pecture" src="http://dkextras.com/DK/images/profile/dfe29f0b7f57ca5cb982ac9b323ac975.jpg" alt="stack photo" class="img">
                        </div>
                      </div>
                      <div class="col-md-9 col-xs-12 col-sm-9 col-lg-9">
                          <div class="" style="border-bottom:1px solid black">
                            <h2 id="Full_Name"></h2>
                          </div>
                            <hr>
                          <div class="details col-md-13 col-sm-12 col-xs-8">  
						    <div class="col-md-12">  
							  <div class="col-sm-5 col-xs-6 tital "><span class="glyphicon glyphicon-earphone one" style="width:50px;"></span></div><div class="col-sm-7 col-xs-6 " ><span id="Phone_Number1"></span></div>
                            <div class="clearfix"></div><div class="bot-border"></div>
							  <div class="col-sm-5 col-xs-6 tital "><span class="glyphicon glyphicon-earphone one" style="width:50px;"></span></div><div class="col-sm-7 col-xs-6 " ><span id="Phone_Number2"></span></div>
                            <div class="clearfix"></div><div class="bot-border"></div>

                          <div class="col-sm-5 col-xs-6 tital "><span class="glyphicon glyphicon-envelope one" style="width:50px;"></span></div><div class="col-sm-7 col-xs-6 " ><span id="email"></span></div>
                            <div class="clearfix"></div><div class="bot-border"></div>
                            <div class="col-sm-5 col-xs-6 tital "><span class="glyphicon glyphicon-map-marker one" style="width:50px;"></span></div><div class="col-sm-7 col-xs-6" ><span id="Governorate"></span>/<span id="Address"><span></div>
                            <div class="clearfix"></div><div class="bot-border"></div>
                          </div>
                          
                          </div>

                          <div class="col-md-12">  
                            <div class="col-sm-5 col-xs-6 tital ">Birthday:</div><div class="col-sm-7 col-xs-6 " ><span id="Day_of_Birth"></span></div>
                            <div class="clearfix"></div><div class="bot-border"></div>
                            <div class="col-sm-5 col-xs-6 tital ">Gender:</div><div class="col-sm-7 col-xs-6 " ><span id="Gender"></span></div>
                            <div class="clearfix"></div><div class="bot-border"></div>
                            <div class="col-sm-5 col-xs-6 tital ">Blood Group:</div><div class="col-sm-7 col-xs-6 " ><span  id="Blood_Group"></span></div>
                            <div class="clearfix"></div><div class="bot-border"></div>
							 <div class="col-sm-5 col-xs-6 tital ">Marital Status:</div><div class="col-sm-7 col-xs-6 " ><span id="Marital_Status"></span></div>
                            <div class="clearfix"></div><div class="bot-border"></div>
                          </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="form-group row">
                        <div class="col-md-12">
                        <div class="form-group" style="border-bottom:1px solid black">
                            <h2>Specialty Information</h2>
                        </div>
                        </div>
                      </div>
                    </div>
                    <div class="row"> 
                     <div class="col-md-6">
                        <div class="col-sm-6 col-xs-9 tital ">Acadimic Achievement:</div><div class="col-sm-6 col-xs-6 contant_i" ><span id="Acadimic_Achievement"><span></div>
                        <div class="clearfix"></div><div class="bot-border"></div>
                        <div class="col-sm-6 col-xs-6 tital ">Specialization:</div><div class="col-sm-6 col-xs-6 contant_i" ><span id="Specialization"></span></div>
                        <div class="clearfix"></div><div class="bot-border"></div>
						      <div class="col-sm-12 col-xs-12 tital ">Experience:</div><div class="col-sm-12 col-xs-12 contant_i"><p id="Experience"></p></div>
                        <div class="clearfix"></div><div class="bot-border"></div>
                     
                   </div>
                  
                    
					
                   <div class="row">
                   <div class="form-group row">
                     <div class="col-md-12">
                     <div class="form-group" style="border-bottom:1px solid black">
                         <h2>Join Information Information</h2>
                     </div>
                     </div>
                   </div>
                 </div>
                 <div class="row"> 
                  <div class="col-md-6">
                     <div class="col-sm-6 col-xs-9 tital ">Add By:</div><div class="col-sm-6 col-xs-6 contant_i" ><span id="how_add"><span></div>
                     <div class="clearfix"></div><div class="bot-border"></div>
                     <div class="col-sm-6 col-xs-6 tital ">Date Of Join:</div><div class="col-sm-6 col-xs-6 contant_i" ><span id="created_at"></span></div>
                     <div class="clearfix"></div><div class="bot-border"></div>
          
                </div>
					
					
					
					
                    </div>
                 
                       <div class="row">
                      <div class="form-group row">
                        <div class="col-md-12">
                        <div class="form-group" style="border-bottom:1px solid black">
                            <h2>Group Information</h2>
                        </div>
                        </div>
                      </div>
                    </div>
                      <div class="row"> 
                     <div class="col-md-6">
                     <div class="col-sm-6 col-xs-6 tital "></div><div class="col-sm-6 col-xs-6 contant_i" ><span></span></div>
                        <div class="clearfix"></div><div class="bot-border"></div>
                        <div class="col-sm-6 col-xs-9 tital ">Department:</div><div class="col-sm-6 col-xs-6 contant_i" ><span id="Volunteer_Code"></span></div>
                        <div class="clearfix"></div><div class="bot-border"></div>
                        <div class="col-sm-6 col-xs-6 tital ">Position:</div><div class="col-sm-6 col-xs-6 contant_i" ><span id="Position"></span></div>
                        <div class="clearfix"></div><div class="bot-border"></div>
						      <div class="col-sm-6 col-xs-6 tital ">Parent Group:</div><div class="col-sm-6 col-xs-6 contant_i" ><span id="parent_group">osama ismail</span></div>
                        <div class="clearfix"></div><div class="bot-border"></div>
                     
                   </div>
                    
                    
                   <div class="row">
                   <div class="form-group row">
                     <div class="col-md-12">
                     <div class="form-group" style="border-bottom:1px solid black">
                         <h2>Social Media Information</h2>
                     </div>
                     </div>
                   </div>
                 </div>
                 <div class="row"> 
                  <div class="col-md-6">
                     <div class="col-sm-6 col-xs-9 tital ">Facebook:</div><div class="col-sm-6 col-xs-6 contant_i" ><a href="" traget="_blank" id="facebook"></a></div>
                     <div class="clearfix"></div><div class="bot-border"></div>
                     <div class="col-sm-6 col-xs-6 tital ">Instagram:</div><div class="col-sm-6 col-xs-6 contant_i" ><a href="" traget="_blank" id="Instagram"></a></div>
                     <div class="clearfix"></div><div class="bot-border"></div>
                     <div class="col-sm-6 col-xs-6 tital ">Twitter:</div><div class="col-sm-6 col-xs-6 contant_i" ><a href="" traget="_blank" id="Twitter"></a></div>
                     <div class="clearfix"></div><div class="bot-border"></div>
          
                </div>
					
					
                </div>
            </div>
            </div>
 </div>
 </div>

