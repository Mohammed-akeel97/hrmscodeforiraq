<link href="{{ asset('css/edit_vol.css') }}" rel="stylesheet">
<script type="text/javascript">
    $(function(){
$('a[title]').tooltip();
});

    </script>
   <div class="panel-body table-responsive">
        <table class="table table-hover">
          <thead>
            <tr class="th">
              <th class="text-center"> No. </th>
              <th class=""> Name </th>
              <th class=""> Department </th>
              <th class=""> Postion </th>
              <th class=""> Specialization </th>
              <th class=""> Governorate</th>
                  <th class="col-tools text-center"><span class="	glyphicon glyphicon-wrench" aria-hidden="true"></span>
            </tr>
          </thead>

          <tbody>
  
          @if(count($Volunteers) >0)
<?php  $i=1; ?>
          @foreach($Volunteers as $Volunteer)
            <tr class="edit" id="detail">
          
              <td id="no" class="text-center">{{$i}}</td>
              <!-- 1 -->
              <td id="Full_Name[{{$i}}]" > {{$Volunteer->Full_Name}}</td>
                 <!-- 2 -->
              <td id="Volunteer_Code[{{$i}}]" class=""> {{$Volunteer->name_department}}</td>
                 <!-- 3 -->
              <td id="Position[{{$i}}]" class=""> {{$Volunteer->name_postion}}</td>
                 <!-- 4 -->
                 <td id="Specialization[{{$i}}]" class="" > {{$Volunteer->Specialization}}</td>
             <!-- 5 -->
              <td id="Governorate[{{$i}}]" class=""> {{$Volunteer->Governorate}}</td>
                 <!-- 6 -->
        
              <td id="email[{{$i}}]" class="" style="display:none;">{{$Volunteer->volunteerEmail}}</td>
           
                 <!-- 7 -->
              <td id="Gender[{{$i}}]" class="" style="display:none;"> {{$Volunteer->Gender}}</td>
                 <!-- 8 -->
              <td id="parent_group[{{$i}}]" class="" style="display:none;"> {{$Volunteer->parent_group}}</td>
                 <!-- 9 -->
              <td id="Day_of_Birth[{{$i}}]" class="" style="display:none;"> {{$Volunteer->Day_of_Birth}}</td>
                 <!-- 10 -->
              <td id="Acadimic_Achievement[{{$i}}]" class="" style="display:none;"> {{$Volunteer->Acadimic_Achievement}}</td>
                 <!-- 11 -->
              <td id="New_Pecture[{{$i}}]" class="" style="display:none;">{{$Volunteer->New_Pecture}}</td>
                 <!-- 12 -->
              <td id="Address[{{$i}}]" class="" style="display:none;"> {{$Volunteer->Address}}</td>
                 <!-- 13 -->
              <td id="Experience[{{$i}}]" class="" style="display:none;"> {!!$Volunteer->Experience!!}</td>
                 <!-- 14 -->
              <td id="Blood_Group[{{$i}}]" class="" style="display:none;"> {{$Volunteer->Blood_Group}}</td>
                 <!-- 15 -->
              <td id="Marital_Status[{{$i}}]" class="" style="display:none;"> {{$Volunteer->Marital_Status}}</td>
                 <!-- 16 -->
              <td id="Phone_Number1[{{$i}}]" class="" style="display:none;"> {{$Volunteer->Phone_Number1}}</td>
                 <!-- 17 -->
              <td id="Phone_Number2[{{$i}}]" class="" style="display:none;"> {{$Volunteer->Phone_Number2}}</td>
                 <!-- 18 -->
              <td id="Twitter[{{$i}}]" class="" style="display:none;"> {{$Volunteer->Twitter}}</td>
                 <!-- 19 -->
              <td id="facebook[{{$i}}]" class="" style="display:none;"> {{$Volunteer->facebook}}</td>
                 <!-- 20 -->
              <td id="Instagram[{{$i}}]" class="" style="display:none;"> {{$Volunteer->Instagram}}</td>
                 <!-- 21 -->
              <td id="how_add[{{$i}}]" class="" style="display:none;"> {{$Volunteer->name}}</td>
                      <!-- 22 -->
                      <td id="created_at[{{$i}}]" class="" style="display:none;"> {{$Volunteer->join_date}}</td>
               
               <td align="left">


                                <a href="/volunteer/{{$Volunteer->volunteerID}}/edit" class="btn btn-default btn-group" title="" data-original-title="Edit" aria-expanded="true"><span class="glyphicon glyphicon-pencil"
                                                                 aria-hidden="true"></span></a>
                                                                 
            {!! Form::open(['action' => ['Volunteer_controller@destroy',$Volunteer->volunteerID], 'method'=>'POST']) !!}
  {{Form::hidden('_method' ,'DELETE') }}
<?php
echo get_modal($Volunteer->volunteerID,$Volunteer->Full_Name);

?>
  {!! Form::close() !!}
          <!--   <button data-toggle="modal" onclick="get_info({{$i}})"  data-target="#ShowModal1" class="btn btn-info"  title="" data-original-title="Edit" aria-expanded="true"><span class="glyphicon glyphicon-list-alt"
                            aria-hidden="true"></span></button>-->
                            <a class="btn btn-info btn-group" onclick="get_info({{$i}})" href="#ShowModal1" data-toggle="modal" title="" data-original-title="Show Information" aria-expanded="true"><i class="glyphicon glyphicon-list-alt"></i></a> 

                            </td>
            </tr>
 
            <?php  $i++; ?>
            @endforeach
@else 
<td colspan="7" style="text-align:center;"><br><br><strong>No Results</strong><br><br></td>      
@endif
          </tbody>
        </table>
      </div>