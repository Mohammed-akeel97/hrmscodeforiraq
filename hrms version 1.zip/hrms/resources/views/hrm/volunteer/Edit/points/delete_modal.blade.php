<?php
function get_modal($id,$name){
$modal='<!--<button type="button" data-toggle="modal" title="" data-original-title="Delete" aria-expanded="true"  data-target="#DeleteModal'.$id.'" class="btn btn-danger"><span class="glyphicon glyphicon-trash"
aria-hidden="true"></span></button>-->
<!-- Modal -->
<a class="btn btn-danger" href="#DeleteModal'.$id.'" data-toggle="modal" title="" data-original-title="Delete" aria-expanded="true"><i class="glyphicon glyphicon-trash"></i></a> 
<!-- Modal -->
<div class="modal fade" id="DeleteModal'.$id.'" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header modal-header" style="background-color:#DC143C;color:white;border-color:#DC143C;   ">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<br>
<h4><p><i class="glyphicon glyphicon-trash"></i> Delete '.$name.' , Are You Sure?</p></h4>
</div>
<div class="modal-body">
</div>
<div class="modal-footer">
<div>
<button type="submit" name="Delete" class="btn btn-danger" >Delete</button>
<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancel</button>
</div>
</div>
</div><!-- /.modal-content -->
</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- Modal -->
';

return $modal;

}


?>