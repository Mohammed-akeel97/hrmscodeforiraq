         
                <!-- *************************  -->
             
                    <?php
$departments_arr=array ();
foreach ($get_depatment as $depratment){
    $departments_arr[$depratment->id]=$depratment->name_department;
}
$postion_arr=array ();
foreach ($get_postion as $postion){
    $postion_arr[$postion->id]=$postion->name_postion;
}
     ?>
         
                <div class="form-group">                    
                
                                   {{Form::label('Full_Name_search', 'Full Name')}}
                               {{Form::text('Full_Name_search','',['class'=>'form-control','placeholder'=>'Full Name']  ) }}
                               @if ($errors->has('Full_Name_search'))
                                                   <span class="help-block" style="color:red;">
                                                       <strong>{{ $errors->first('Full_Name_search') }}</strong>
                                                   </span>
                                               @endif
                               </div>
                                  <!-- *************************  -->
                     
                                  
                                  <div class="form-group">                    
                                  {{Form::label('Department_search', 'Department')}}
                             
                                      {{ Form::select('Department_search',$departments_arr,'',['class'=>'form-control','placeholder'=>'Department']
                  ) }}
                                  </div>
                                  @if ($errors->has('Department_search'))
                                                      <span class="help-block" style="color:red;">
                                                          <strong>{{ $errors->first('Department_search') }}</strong>
                                                      </span>
                                                  @endif
                               
                        
                                <!-- *************************  -->
                               <div class="form-group" >                    
                               {{Form::label('Position_search', 'Position')}}
                          
                                   {{ Form::select('Position_search',$postion_arr,'',['class'=>'form-control','placeholder'=>'Position']
               ) }}
               @if ($errors->has('Position_search'))
                                                   <span class="help-block" style="color:red;">
                                                       <strong>{{ $errors->first('Position_search') }}</strong>
                                                   </span>
                                               @endif
                               </div>
                                <!-- *************************  -->
                                     
                <!-- *************************  -->
             
               
         
                <div class="form-group">                    
                
                                   {{Form::label('parent_group_search', 'Email Manager')}}
                               {{Form::email('parent_group_search','',['class'=>'form-control','placeholder'=>'Email Manager']  ) }}
                               @if ($errors->has('parent_group_search'))
                                                   <span class="help-block" style="color:red;">
                                                       <strong>{{ $errors->first('parent_group_search') }}</strong>
                                                   </span>
                                               @endif
                               </div>
                                  <!-- *************************  -->