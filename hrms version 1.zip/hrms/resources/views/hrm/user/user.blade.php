@extends('layouts.general')
@section('content')

<link href="{{ asset('css/profile.css') }}" rel="stylesheet">
@include('hrm.user.points.modal_password')
<?php $user_info_arr=array (); ?>
@foreach($user_info as $info)
<?php
//1
$user_info_arr['full_name']=$info->name;
//2
$user_info_arr['name_department']=$info->name_department;
//
//3
$user_info_arr['Gender']=$info->Gender;
//4
$user_info_arr['parent_group']=$info->parent_group;
//5
$user_info_arr['Day_of_Birth']=$info->Day_of_Birth;

//6
$user_info_arr['Acadimic_Achievement']=$info->Acadimic_Achievement;
//7
$user_info_arr['Governorate']=$info->Governorate;
//8
$user_info_arr['New_Pecture']=$info->New_Pecture;
//9
$user_info_arr['Address']=$info->Address;

//10
$user_info_arr['Blood_Group']=$info->Blood_Group;
//11
$user_info_arr['Marital_Status']=$info->Marital_Status;
//12
$user_info_arr['Phone_Number1']=$info->Phone_Number1;
//13
$user_info_arr['Phone_Number2']=$info->Phone_Number2;
//14

//15
$user_info_arr['created_at']=$info->created_at;
//16
$user_info_arr['name_postion']=$info->name_postion;
//
$user_info_arr['Specialization']=$info->Specialization;
?>
@endforeach
	<div class="container">
	<div class="row">

        
       <div class="col-md-8 col-md-offset-2 ">

<div class="panel panel-default">
  <div class="panel-heading color_panel" style="color:white;">  <h2 align="center"><i class="glyphicon glyphicon-user"></i> User Profile</h2></div>
   <div class="panel-body">
       
    <div class="box box-info">
        
            <div class="box-body">
                     <div class="col-sm-6">
                     <div align="center"> <img alt="User Pic" src="{{ URL::to('/') }}/pictures/{{$user_info_arr['New_Pecture']}}" id="profile-image1" class="img-circle img-responsive"> 
                
           
<div style="color:#999;">Code For {{$user_info_arr['Governorate']}}</div>
                <!--Upload Image Js And Css-->
           
              
   
                
                
                     
                     
                     </div>
              
              <br>
    
              <!-- /input-group -->
            </div>
            <div class="col-sm-6">
            <h4 style="color:#00b1b1;">{{$user_info_arr['full_name']}} </h4>
              <span><p>{{$user_info_arr['name_department']}}</p></span>            
            </div>
            <div class="clearfix"></div>
            <hr style="margin:5px 0 5px 0;">
    
              
<div class="col-sm-5 col-xs-6 tital ">Position:</div><div class="col-sm-7 col-xs-6 ">{{$user_info_arr['name_postion']}}</div>
     <div class="clearfix"></div>
<div class="bot-border"></div>


<div class="col-sm-5 col-xs-6 tital ">Date Of Joining:</div><div class="col-sm-7"><?php echo  date('N F Y', strtotime($user_info_arr['created_at'])) ?></div>

  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital ">Date Of Birth:</div><div class="col-sm-7"><?php echo  date('N F Y', strtotime($user_info_arr['Day_of_Birth'])) ?></div>


 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital ">Governorate:</div><div class="col-sm-7">{{$user_info_arr['Governorate']}}</div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital ">Address:</div><div class="col-sm-7">{{$user_info_arr['Address']}}</div>
<div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital "></div><div class="col-sm-7"><button type="button" class="btn btn-default color_button" style="" data-toggle="modal" data-target="#modalchangepassword">Change Password</button></div>


            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </div>
       
            
    </div> 
    </div>
</div>  
 
       
       
       
       
       
       
       
       
       
   </div>
</div>




         




@endsection