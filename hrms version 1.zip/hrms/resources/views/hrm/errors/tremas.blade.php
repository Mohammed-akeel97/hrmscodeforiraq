@extends('layouts.general')
@section('content')
<fieldset style="padding: 20px;"> 
<div class="row col-md-8 col-md-offset-2 ">

  <div class="panel panel-primary">
      <div class="panel-heading color_panel"><h1 ><i class="glyphicon glyphicon-exclamation-sign"></i> Warning Validity</h1></div>
      <div class="panel-body">						<div class="row">
                <div class="col-md-12 col-sm-12 col-lg-12" align="center"> <img alt="" src="{{ URL::to('/') }}/Images/logo_home.png" class="img-circle img-responsive"> </div>
          
             <article align="center">
                 <h1 style="color:red;">Error Validity</h1>
        <p>Sorry ! ,Your Position Not Have  Validity To This Page</p>
          </article>
              </div>

		</div>
	
	</div>
  </div>
</div></div>
    </div>
		   </div>	
</fieldset> 
@endsection

