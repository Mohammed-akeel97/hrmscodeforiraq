    
<link href="{{ asset('css/edit_vol.css') }}" rel="stylesheet">

@extends('layouts.general')

@section('panel_edit')
    <script type="text/javascript" src="{{ asset('js/get_info.js')}}"></script> 
<link href="{{ asset('css/add.css') }}" rel="stylesheet">  
@include('hrm.Training.Edit.points.delete_modal')

@include('hrm.Training.View.points.modal_show')

 <div class="container-fluid">
    <div class="panel panel-info">
      <div class="panel-heading color_panel" style="color:white;">
       @include('hrm.Training.Edit.points.search')
      </div>

   @include('hrm.Training.Edit.points.table')

      <div class="panel-footer">
        <div class="row">
          <div class="col-lg-12">
            <div class="col-md-12">
            {{$Trainings->links()}}
              </div>
              <div class="col-md-12">
              <p class="muted pull-right"><strong> © 2017 All rights reserved Code For Iraq </strong></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  @endsection