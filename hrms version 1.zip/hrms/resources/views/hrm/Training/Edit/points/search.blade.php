 <div class="row">
          <div class=" col-md-12">
            <h2 class="text-center pull-left" style="padding-left: 30px;"> <span class="glyphicon glyphicon-list-alt"> </span> Edit  Training </h2>
          </div>
          <div class=" col-md-12">
            <div class=" col-md-12">
              <div class=" col-md-12">
                
                <!-- *************************  -->
            <div class=" col-md-4 pull-right">
            {!! Form::open(['action' =>[ 'Training_controller@edit_search'], 'method'=>'POST','enctype'=>'multipart/form-data']) !!}

                <div class="form-group">
                <label> Search </label>
                  <div class="input-group">
        {{Form::text('Title_Trining_search','',['class'=>'form-control','placeholder'=>'Title Trining']  ) }}
              <div class="input-group-btn">
                      <button type="submit" class="btn btn-md btn-info"> <span class=" glyphicon glyphicon-search"></span></button>
                
                    </div>

                  </div>
                  </div>
                  {!! Form::close() !!}
                  </div>
                   <!-- *************************  -->

                 <!-- *************************  -->

                 <!-- *************************  -->
              </div>
            </div>
          </div>
        </div>