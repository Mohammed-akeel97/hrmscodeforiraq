 
   <div class="panel-body table-responsive">
        <table class="table table-hover">
          <thead>
            <tr class="th">
              <th class="text-center"> No. </th>
              <th class="text-center"> Title </th>
              <th class="text-center"> Trainer Name </th>
              <th class="text-center"> Training Place </th>
              <th class="text-center"> Training Start Date</th>
                  <th class="col-tools text-center"><span class="	glyphicon glyphicon-wrench" aria-hidden="true"></span>
            </tr>
          </thead>

          <tbody>
          @if(count($Trainings) >0)
<?php  $i=1; ?>
          @foreach($Trainings as $Training)
            <tr class="edit" id="detail">
              <td  class="text-center"> {{$i}}</td>
              <td  class="text-center" id="Title_Trining[{{$i}}]"> {{$Training->Title_Trining}}</td>
              <td class="text-center" id="Trainer_Name[{{$i}}]"> {{$Training->Trainer_Name}} </td>
              <td class="text-center" id="Training_Place[{{$i}}]">  {{$Training->Training_Place}} </td>
              <td  class="" id="Training_Start_Date[{{$i}}]">  {{$Training->Training_Start_Date}}</td>
              <span id="Status[{{$i}}]" style="display:none;">{{$Training->Status}}</span>
    <span id="add_by[{{$i}}]" style="display:none;">{{$Training->add_by}}</span>
    <span id="Training_Course_Duration[{{$i}}]" style="display:none;">{!!$Training->Training_Course_Duration!!}</span>
    <span id="Training_End_Date[{{$i}}]" style="display:none;">{{$Training->Training_End_Date}}</span>

              <td align="left">


                                <a href="/training/{{$Training->id}}/edit" class="btn btn-default " title="" data-original-title="Edit" aria-expanded="true"><span class="glyphicon glyphicon-pencil"
                                                                 aria-hidden="true"></span></a>

          <!--   <button data-toggle="modal" onclick="get_info({{$i}})"  data-target="#ShowModal1" class="btn btn-info"  title="" data-original-title="Edit" aria-expanded="true"><span class="glyphicon glyphicon-list-alt"
                            aria-hidden="true"></span></button>-->
                            <a class="btn btn-info "  onclick="get_info_training({{$i}})"  href="#trainModal" data-toggle="modal" title="" data-original-title="Show Information" aria-expanded="true"><i class="glyphicon glyphicon-list-alt"></i></a> 
                                     <span>                            
                            {!! Form::open(['action' => ['Training_controller@destroy',$Training->id], 'method'=>'POST']) !!}
  {{Form::hidden('_method' ,'DELETE') }}
<?php
echo get_modal($Training->id,$Training->Title_Trining);

?>
  {!! Form::close() !!}
  </span>
                            </td>
            </tr>
            <?php  $i++; ?>
            @endforeach
@else 
<td colspan="7" style="text-align:center;"><br><br><strong>No Results</strong><br><br></td>      
@endif
 
          </tbody>
        </table>
      </div>