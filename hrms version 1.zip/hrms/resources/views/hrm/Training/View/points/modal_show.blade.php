

<!-- line modal -->
<div class="modal fade" id="trainModal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
  <div class="modal-dialog">
	<div class="modal-content">
		<div class="modal-header color_panel">
			<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
			<h3 class="modal-title" id="lineModalLabel">Information Training</h3>
		</div>
		<div class="modal-body">
			
            <!-- content goes here -->
						<div class="row">
                <div class="col-md-3 col-lg-3 " align="center"> <img alt="" src="{{ URL::to('/') }}/Images/logo_home.png" class="img-circle img-responsive"> </div>
          
                <div class=" col-md-9 col-lg-9 "> 
                  <table class="table table-user-information">
                    <tbody>
                      <tr>
                        <td>Title Trining:</td>
                        <td ><p id="Title_Trining"></p></td>
											</tr>
											<tr>
                        <td>Trainer Name:</td>
                        <td><p id="Trainer_Name"></p></td>
											</tr>
											<tr>
                        <td>Training Place:</td>
                        <td><p id="Training_Place"></p></td>
											</tr>
						
                      <tr>
                        <td>Training Start Date</td>
                        <td><p id="Training_Start_Date"></p></td>
                      </tr>
                      <tr>
                        <td>Training End Date</td>
                        <td><p id="Training_End_Date"></p></td>
                      </tr>
                      <tr>
                        <td>Duration</td>
                        <td><p id="Duration"></p></td>
                      </tr>
											<tr>
                        <td>Status:</td>
                        <td><p id="Status"></p></td>
                      </tr>
											<tr>
                        <td colspan="2">Training Course Duration:<br>
                       <br><p id="Training_Course_Duration">  </tr>
                     
                    </tbody>
                  </table>
                  
   <small >Add by:<span  id="add_by"></span></small>
                </div>
              </div>

		</div>
		<div class="modal-footer">
			<div class="btn-group btn-group-justified" role="group" aria-label="group button">
				<div class="btn-group" role="group">
					<button type="button" class="btn btn-default" data-dismiss="modal"  role="button">Close</button>
				</div>
			</div>
		</div>
	</div>
  </div>
</div>