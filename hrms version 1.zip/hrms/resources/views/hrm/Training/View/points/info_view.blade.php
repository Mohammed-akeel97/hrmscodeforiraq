
                        
<div class="panel-body table-responsive">
@if(count($Trainings) >0)
<?php  $i=1; ?>
          @foreach($Trainings as $Training)
<div class=" col-md-3">
<ul class="eight">
  <li class="transition">
    <div class="wrapper" > <span class="transition" >
      <h3 class="transition">{{$Training->Title_Trining}}<em>{{$Training->Trainer_Name}}</em></h3>
      <span id="Title_Trining[{{$i}}]" style="display:none;">{{$Training->Title_Trining}}</span>
      <span id="Trainer_Name[{{$i}}]" style="display:none;">{{$Training->Trainer_Name}}</span>
      <span id="Training_Course_Duration[{{$i}}]" style="display:none;">{!!$Training->Training_Course_Duration!!}</span>
      <span id="Status[{{$i}}]" style="display:none;">{{$Training->Status}}</span>
      <span id="Training_Place[{{$i}}]" style="display:none;">{{$Training->Training_Place}}</span>
      <span id="Training_Start_Date[{{$i}}]" style="display:none;">{{$Training->Training_Start_Date}}</span>
      <span id="add_by[{{$i}}]" style="display:none;">{{$Training->add_by}}</span>
      <span id="Training_End_Date[{{$i}}]" style="display:none;">{{$Training->Training_End_Date}}</span>
      <span id="days[{{$i}}]" style="display:none;">{{$Training->Training_End_Date-$Training->Training_Start_Date}}</span>


      <div class="image-container transition">
        <div class="creation" >
          <div class="front" >
            <div class="cont" > <i class="details"><img width="100" class="icon-circle transition" src="{{ URL::to('/') }}/Images/lap.png" ></img> </div>
          </div>
          <div class="back">
            <div class="cont" > <i class="details"><img width="100" src="{{ URL::to('/') }}/Images/vinger.png"  ></img> </div>
          </div>
        </div>
      </div>
      </span>
      <ul class="social transition" align="center" style="margin-left:36%;">
        <li class="transition"><button onclick="get_info_training({{$i}})" data-toggle="modal" data-target="#trainModal" class="btn btn-info center-block"><i class="glyphicon glyphicon-list-alt"></i> View</button></li>
   </ul>
      <div class="arrow"></div>
    </div>
  </li>

</ul>
</div>
<?php  $i++; ?>
            @endforeach
@else 
<p colspan="7" style="text-align:center;"><br><br><strong>No Results</strong><br><br></p>      
@endif
</div>