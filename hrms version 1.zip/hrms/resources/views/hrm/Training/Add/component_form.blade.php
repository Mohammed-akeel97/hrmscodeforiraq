@extends('layouts.general')


<!-- *************************  left ****************** -->
@section('form_reg')
<fieldset style="padding: 20px;"> 
 <link href="{{ asset('css/add.css') }}" rel="stylesheet">  
<br>
{!! Form::open(['action' => 'Training_controller@store', 'method'=>'POST','enctype'=>'multipart/form-data']) !!}

	 <!--this was made my Agil Asadi. You are free to delete this comment line and use it as you wish-->   
<div class="container">
	<div class="row">
		<h2 class="headerSign" style="">Add Training</h2>

	</div>
</div>
<div class="row col-md-8 col-ms-5 col-md-offset-2 registeration" style="z-index:100;background-color:rgba(255,255,255,0.8)">
    
<div class="registerInner">
<!-- ********************************  lift -->
        <div class="col-md-6 signUp">
<br>
<!-- ********************************  title_and_name -->
@include('hrm.Training.Add.points.title_and_name')
<!-- ********************************  Status -->
 @include('hrm.Training.Add.points.Status')
 

 </div>
<!-- ********************************  right -->       
        <div class="col-md-6">
        <br>
        <!-- ********************************  date_and_place -->
@include('hrm.Training.Add.points.date_and_place')


 
                    
                </div>
<!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
                         <!-- *********************************************************************  -->

                
             
       
       <br>  <br>  <br>                    <!-- *********************************************************************  -->
 <div class="form-group"> 
     <br>  <br>  <br>  <br> <br>  <br>  <br>  <br> <br>  <br>       <br>  <br>  <br>  <br> <br>      
     {{Form::submit('save',['class'=>'signbuttons btn btn-primary pull-right' ] ) }} <br>  
               </div>  

 
<!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
            
        </div>
             
</div>
       
</div>

{!! Form::close() !!}
</fieldset> 
@endsection