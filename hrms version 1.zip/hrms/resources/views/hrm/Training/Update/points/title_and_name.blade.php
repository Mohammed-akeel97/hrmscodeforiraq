<h3 class="headerSign">Title & Trainer Name</h3>
<!--***********************************  -->
<!-- *********************************************************************  -->

<!-- *********************************************************************  -->
<div class="form-group">  
   {{Form::label('Title_Trining','Title Trining')}}<span style="color:red;font-size:18pt;">*</span>
{{Form::text('Title_Trining',$get_Training->Title_Trining,['class'=>'form-control','placeholder'=>'Title Trining']  ) }}
@if ($errors->has('Title_Trining'))
                   <span class="help-block" style="color:red;">
                       <strong>{{ $errors->first('Title_Trining') }}</strong>
                   </span>
               @endif
</div>

<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
<!-- *********************************************************************  -->
<div class="form-group">
{{Form::label('Trainer_Name','Trainer Name')}}<span style="color:red;font-size:18pt;">*</span>
{{Form::text('Trainer_Name',$get_Training->Trainer_Name,['class'=>'form-control','placeholder'=>'Trainer Name']  ) }}
@if ($errors->has('Trainer_Name'))
                   <span class="help-block" style="color:red;">
                       <strong>{{ $errors->first('Trainer_Name') }}</strong>
                   </span>
               @endif
</div>
<!-- *********************************************************************  -->

