<h3 class="headerSign">Training Place & Date Start</h3>

            <!--***********************************  -->
<!-- *********************************************************************  -->

<!-- *********************************************************************  -->
           <div class="form-group">
  
               {{Form::label('Training_Place','Training Place')}}<span style="color:red;font-size:18pt;">*</span>
           {{Form::text('Training_Place',$get_Training->Training_Place,['class'=>'form-control','placeholder'=>'Training Place']  ) }}
           @if ($errors->has('Training_Place'))
                               <span class="help-block" style="color:red;">
                                   <strong>{{ $errors->first('Trainer_Name') }}</strong>
                               </span>
                           @endif
</div>
<!-- *********************************************************************  -->
<!-- *********************************************************************  -->
           <div class="form-group">
{{Form::label('Training_Start_Date','Training Start Date')}}<span style="color:red;font-size:18pt;">*</span>
           {{Form::date('Training_Start_Date',$get_Training->Training_Start_Date,['class'=>'form-control','placeholder'=>'Training Start Date']  ) }}
           @if ($errors->has('Training_Start_Date'))
                               <span class="help-block" style="color:red;">
                                   <strong>{{ $errors->first('Training_Start_Date') }}</strong>
                               </span>
                           @endif

</div>
<!-- *********************************************************************  -->
  <!-- *********************************************************************  -->
  <div class="form-group">
   {{Form::label('Training_End_Date','Training End Date')}}<span style="color:red;font-size:18pt;">*</span>
                {{Form::date('Training_End_Date',$get_Training->Training_End_Date,['class'=>'form-control','placeholder'=>'Training Start Date']  ) }}
                @if ($errors->has('Training_End_Date'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('Training_End_Date') }}</strong>
                                    </span>
                                @endif

</div>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
