{!! Form::open(['action' => 'Announcement_controller@store', 'method'=>'POST','enctype'=>'multipart/form-data']) !!}

<div class="container">


  <!-- Modal -->
  <div class="modal fade " id="modal_send_groups" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header color_panel">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Group Announcement</h4>
        </div>
        <div class="modal-body">
       <!-- body start -->
       {{--  excract volunteer  --}}
  
       <!-- *********************************************************************  -->
    
<!-- *********************************************************************  -->
<!-- *********************************************************************  -->
<div class="form-group">
                {{Form::label('title_message', 'Title Message')}}<span style="color:red;font-size:18pt;">*</span>
                {{Form::text('title_message','',['class'=>'form-control','placeholder'=>'Title Message']  ) }}
                @if ($errors->has('title_message'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('title_message') }}</strong>
                                    </span>
                                @endif
            </div>
<!-- *********************************************************************  -->
<!-- *********************************************************************  -->
<div class="form-group">
                {{Form::label('full_message', 'Message')}}<span style="color:red;font-size:18pt;">*</span>
                {{Form::textarea('full_message','',['class'=>'form-control txt2','placeholder'=>'Message','id'=>'article-ckeditor']  ) }}
                @if ($errors->has('full_message'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('full_message') }}</strong>
                                    </span>
                                @endif
            </div>
<!-- *********************************************************************  -->


       <!-- body end -->
        </div>
        <div class="modal-footer">
        <button type="submit" class="btn btn-default pull-right color_button" >Send</button>
       
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>
{!! Form::close() !!}