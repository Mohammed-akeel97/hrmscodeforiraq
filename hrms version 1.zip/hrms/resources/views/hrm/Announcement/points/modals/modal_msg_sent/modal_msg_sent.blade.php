<div class="container">
{!! Form::open(['action' => 'replay_message_controller@store', 'method'=>'POST','enctype'=>'multipart/form-data']) !!}
{{ csrf_field() }}
  {{--  
  <!-- Trigger the modal with a button -->
  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#modal_read_message_received">Open Modal</button>  --}}

  <!-- Modal -->
  <div class="modal fade" id="modal_message_sent" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header color_panel">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><span class="glyphicon glyphicon-comment"></span> View A Sent Announcement</h4>
        </div>
        <div class="modal-body">
                            @include('hrm.Announcement.points.modals.modal_msg_sent.modal_msg_sent_body')
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
    {!! Form::close() !!}
</div>