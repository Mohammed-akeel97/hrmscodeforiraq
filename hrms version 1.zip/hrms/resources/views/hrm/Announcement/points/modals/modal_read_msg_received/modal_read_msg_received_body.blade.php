<div class="row">
<div  class="col-md-12" >
<div class="container">
<div class="row" >
  <ul class="nav nav-tabs col-md-5">
   <li class="active"><a data-toggle="tab" href="#menu1">Announcement  Details</a></li>
    <li><a data-toggle="tab" href="#menu2">Replies</a></li>
    <li><a data-toggle="tab" href="#menu3">Reply To The Announcement </a></li>
  </ul>
 </div>
 <div class="row" >
  <div class="tab-content" >

    <div id="menu1" class="tab-pane  fade  in active" >
    {{--  ******************************************************  --}}
    <div class="row">
    <br>
  	<div class="row col-md-8 col-lg-8">
  
                <div class=" col-md-9 col-lg-9 "> 
                  <div class="list-group">
                    <tbody>
                      <a class="list-group-item">
                        <td>Name Sender:</td>
                        <td ><p id="message_received_name_sender"></p></td>
											</a>
                          <a class="list-group-item">
                        <td>Position Sender:</td>
                        <td ><p id="message_received_position"></p></td>
											</a>
                      
                            <a class="list-group-item" id="message_received_group_parent_a">
                        <td>Email Manager Sender:</td>
                        <td ><p id="message_received_group_parent"></p></td>
											</a>
												       <a class="list-group-item">
                        <td>Email Sender:</td>
                        <td ><p id="message_received_email_sender"></p></td>
											</a>
                      <a class="list-group-item">
                            <td>From  Department:</td>
                        <td ><p id="message_received_department_sender"></p></td>
											</a>
                      	<a class="list-group-item">
                            <td>To  Department:</td>
                        <td ><p id="message_received_department_received"></p></td>
											</a>
									       <a class="list-group-item">
                        <td>Announcement Title:</td>
                        <td ><p id="message_received_title_message"></p></td>
											</a>
                
            
									
											<a class="list-group-item">
                        <td colspan="2">Announcement Details:<br>
                       <br><p id="message_received_full_message"></p>  </a>
                     
                    </tbody>
                  </div>
                  
   <small >sent at:<span  id="sent_at"></span></small>
                </div>
				     </div>
   </div>
{{--  **************************************************************  --}} </div>
    <div id="menu2" class="tab-pane fade">
  {{--  ******************************************************  --}}
  <div class="row col-md-6 col-md-offset-0">
   <div class="panel panel-primary ">
      <div class="panel-heading color_panel">Replays A Received Announcement</div>
      <div class="panel-body" id="received_replay"> </div>
    </div>
   </div>
{{--  **************************************************************  --}}  </div>
    <div id="menu3" class="tab-pane fade">
    {{--  ******************************************************  --}}
    <div class="row col-md-6 ">
  <!-- *********************************************************************  -->

<input name="replay_id" id="replay_id" type="hidden" value="">
<div class="form-group col-md-12">

                {{Form::label('detailes_replay', 'Replay Announcement')}}<span style="color:red;font-size:18pt;">*</span>
                {{Form::textarea('detailes_replay','',['class'=>'form-control txt5','placeholder'=>'Replay Announcement']  ) }}
                @if ($errors->has('detailes_replay'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('detailes_replay') }}</strong>
                                    </span>
                                @endif
            </div>
                               <button type="submit" class="btn btn-default color_button pull-right" >Send</button>
          
<!-- *********************************************************************  -->

   </div>
{{--  **************************************************************  --}}</div>
  </div>
</div>
</div>
</div>
</div>
