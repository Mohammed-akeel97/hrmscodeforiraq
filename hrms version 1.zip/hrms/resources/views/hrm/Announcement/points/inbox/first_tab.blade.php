      <div class="list-group">
      <?php $i=0; ?>
      @if(count($receiveds)>0)
@foreach($receiveds as $received)

     <a onclick="modal_read_message_received_fun({{$i}},{{$received->id_message_to}},{{$received->id_message}})" href="#modal_read_message_received" data-toggle="modal" style="padding:20px 20px 20px 20px;" id="message_class[{{$i}}]"   class="list-group-item <?php if(!$received->is_read)echo 'read'; ?>">
                    
                            <span id="message_star[{{$i}}]" class="glyphicon glyphicon-star<?php if($received->is_read)echo '-empty'; ?>"></span><span class="name" style="min-width: 120px;
                                display: inline-block;" id="message_received_name_sender[{{$i}}]">{{$received->name_sender}}</span> <span class="" id="message_received_title_message[{{$i}}]">{{$received->title_message}}</span>
                            <span class="text-muted" style="font-size: 11px;">-<span id="message_received_department_sender[{{$i}}]"> {{$received->department_sender}}</span>-<span id="message_received_position[{{$i}}]"> {{$received->name_postion}}</span></span> <span class="badge" id="message_received_created_at[{{$i}}]">{{$received->sent_at}}</span> <span class="pull-right">
                                </span>
                        <span style="display:none;" id="message_received_full_message[{{$i}}]">{!!$received->full_message!!}</span>        
                                    <span style="display:none;" id="message_received_email_sender[{{$i}}]">{{$received->email_sender}}</span>
                                        <span style="display:none;" id="message_received_department_received[{{$i}}]">{{$received->department_received}}</span>
                                <span style="display:none;" id="message_received_group_parent[{{$i}}]">{{$received->group_parent}}</span>
                              </a>
 <?php $i++; ?>
@endforeach`
@else 
<br>
<br>
<h3 align="center">No Announcement Received</h3>
@endif
</div> 
<input type="hidden" name="_token" value="{{ csrf_token() }}" />
     {{$receiveds->links()}}
          @include('hrm.Announcement.points.modals.modal_read_msg_received.modal_read_msg_received')