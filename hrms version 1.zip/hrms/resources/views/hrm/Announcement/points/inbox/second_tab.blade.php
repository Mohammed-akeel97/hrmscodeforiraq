       <div class="list-group">
      <?php $i=0; ?>
      @if(count($sents)>0)
@foreach($sents as $sent)

     <a  href="#modal_message_sent" onclick="modal_message_sent_fun({{$i}},{{$sent->id_message_to}},{{$sent->id_message}})"  data-toggle="modal" style="padding:20px 20px 20px 20px;" id="message_class_sent[{{$i}}]"   class="list-group-item <?php if(!$sent->is_read)echo 'read'; ?>">
                    
                           <span class="name" style="min-width: 120px;
                                display: inline-block;" id="message_sent_name_sender[{{$i}}]">{{$sent->name_sender}}</span> <span class="" id="message_sent_title_message[{{$i}}]">{{$sent->title_message}}</span>
                            <span class="text-muted" style="font-size: 11px;">-<span id="message_sent_department_sender[{{$i}}]"> {{$sent->department_sender}}</span></span> <span class="badge" id="message_sent_created_at[{{$i}}]">{{$sent->sent_at}}</span> <span class="pull-right">
                                </span>
                        <span style="display:none;" id="message_sent_full_message[{{$i}}]">{!!$sent->full_message!!}</span>        
                                    <span style="display:none;" id="message_sent_email_sender[{{$i}}]">{{$sent->email_sender}}</span>
                                        <span style="display:none;" id="message_sent_department_received[{{$i}}]">{{$sent->department_received}}</span>
                                           <span style="display:none;" id="is_sent[{{$i}}]">{{$sent->is_read}}</span>
                              </a>
 <?php $i++; ?>
@endforeach`
@else 
<br>
<br>
<h3 align="center">No Announcement Received</h3>
@endif
</div> 
<input type="hidden" name="_token" value="{{ csrf_token() }}" />
     {{$sents->links()}}
          @include('hrm.Announcement.points.modals.modal_msg_sent.modal_msg_sent')
            