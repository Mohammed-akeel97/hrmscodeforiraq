
@foreach($messages as $numbers)
<?php
$num_message=$numbers->num;

?>
@endforeach
<?php echo $num_message; ?>