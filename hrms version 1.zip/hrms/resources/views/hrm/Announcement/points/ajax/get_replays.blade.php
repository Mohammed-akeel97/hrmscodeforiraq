  
  @if(count($replays)>0)
  @foreach($replays as $replays)
  <article class="row">
            <div class="col-md-2 col-sm-2 hidden-xs">
          
            </div>
            <div class="col-md-12 col-sm-12">
              <div class="panel panel-primary arrow left">
              <div class="panel-heading <?php if($replays->replay_email==Auth::user()->email)echo 'color_panel';?>" style="color:white;">{{$replays->replay_name}}</div>
                <div class="panel-body">
                  <header class="text-left">
                    <div class="comment-user"><span>Full Name:</span>{{$replays->replay_name}}</div>
                         <div class="comment-user"><span>Email:</span>{{$replays->replay_email}}</div>
                              <div class="comment-user"><span>Position:</span>{{$replays->name_postion}}</div>
                               <div class="comment-user"><span>Department:</span>{{$replays->name_department}}</div>

                    <time class="comment-date" datetime="16-12-2014 01:05"><i class="glyphicon glyphicon-time"></i> {{$replays->replay_at}}</time>
                  </header>
                  <hr>
                  <div class="comment-post">
                    <p>
                    {!!$replays->detailes_replay!!}
                   </p>
                  </div>
               </div>
              </div>
            </div>
          </article>
          @endforeach
          @else
          <p align="center">No Replays</p>
          @endif