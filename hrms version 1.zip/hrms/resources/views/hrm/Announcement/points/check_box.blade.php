<div class="col-md-12">
<div class="container">

     <h4>Sending to</h4>
      <!-- *********************************************************************  -->

    <div class="funkyradio">
<div class="col-md-3">
        <div class="funkyradio-info">
            <input type="checkbox" name="checkbox" id="checkbox1" />
            <label for="checkbox1">Strategy</label>
        </div>
        </div>
              <!-- *********************************************************************  -->
<div class="col-md-3">
        <div class="funkyradio-info">
            <input type="checkbox" name="checkbox" id="checkbox2" >
            <label for="checkbox2">Managers</label>
        </div>
           </div>
              <!-- *********************************************************************  -->
<div class="col-md-3">
        <div class="funkyradio-info">
            <input type="checkbox" name="checkbox" id="checkbox3" />
            <label for="checkbox3">Volunteers</label>
        </div>
         </div>
      <!-- *********************************************************************  -->


   </div>
    </div>