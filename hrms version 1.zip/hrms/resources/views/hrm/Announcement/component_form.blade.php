@extends('layouts.general')

<!-- *************************  left ****************** -->
@section('form_reg')
<script type="text/javascript" src="{{ asset('js/inbox.js')}}"></script>     
<link href="{{ asset('css/inbox.css') }}" rel="stylesheet">

 	<div class="container style" style="">
    <div class="row">
        <div class="col-sm-3 col-md-2">
            <div class="btn-group">
          
            </div>
        </div>
        <div class="col-sm-9 col-md-10">
            <!-- Split button -->
 
 
            <a href="{{ URL::to('/announcement') }}" class="btn btn-default" data-toggle="tooltip" title="Refresh">
                &nbsp;&nbsp;&nbsp;<span class="glyphicon glyphicon-refresh"></span>&nbsp;&nbsp;&nbsp;</a><br>
       
       
            <!-- Single button -->
             
            <div class="btn-group">
              
            </div>
            <div class="pull-right">
               
                <div class="btn-group btn-group-sm">
             
                 
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-3 col-md-2">
            <button type="button" class="btn btn-danger btn-sm btn-block" onclick="get_ckeditor_class('txt1');" data-toggle="modal" data-target="#myModal" role="button">COMPOSE</button>
            <hr>
            <ul class="nav nav-pills nav-stacked">
                <li class="active"><button type="button" class="btn btn btn-sm btn-block color_button" onclick="get_ckeditor_class('txt2');" style="background-color:white;" data-toggle="modal" data-target="#modal_send_deparments" role="button"> Send Departments </button>
                </li>
                <br>
                <li>
                
                <button type="button" class="btn btn-info btn-sm btn-block " onclick="get_ckeditor_class('txt3')" data-toggle="modal" data-target="#modal_send_groups" role="button"> Send Group </button>
                </li>
       
            </ul>
        </div>
        <div class="col-sm-9 col-md-10">
            <!-- Nav tabs -->
            <ul class="nav nav-tabs">
                <li class="active"><a href="#home" data-toggle="tab"><span class="glyphicon glyphicon-inbox">
                </span>Recipient</a></li>
                <li class=""><a href="#profile" data-toggle="tab"><span class="glyphicon glyphicon-user"></span>
                    Sent</a></li>
                {{--  <li class=""><a href="#messages" data-toggle="tab"><span class="glyphicon glyphicon-comment"></span>
                    Group</a></li>
                <li><a href="#settings" data-toggle="tab"><span class="glyphicon glyphicon-cloud">
                </span> Departments</a></li>  --}}
            </ul>
            <!-- Tab panes -->
            <div class="tab-content">
                <div class="tab-pane fade active in" id="home">
              @include('hrm.Announcement.points.inbox.first_tab')
                </div>
                <div class="tab-pane fade" id="profile">
                @include('hrm.Announcement.points.inbox.second_tab')
                  
                </div>
                {{--  <div class="tab-pane fade" id="messages">
                    @include('hrm.Announcement.points.inbox.therd_tab')
                    </div>
                <div class="tab-pane fade in" id="settings">
                   @include('hrm.Announcement.points.inbox.forth_tab')
                    </div>  --}}
            </div>
           
        </div>
    </div>
</div>



@include('hrm.Announcement.points.modal_send')
@include('hrm.Announcement.points.modals.modal_send_departments')
@include('hrm.Announcement.points.modals.modal_send_groups')
@endsection