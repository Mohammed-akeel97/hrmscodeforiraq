<!-- *******************************  -->


     <h3 class="headerSign">Name & Description</h3>
     <!-- *******************************  -->
      <!-- *********************************************************************  -->
       <div class="form-group">
        {{Form::label('Project Name', 'Project Name')}}<span style="color:red;font-size:18pt;">*</span>
        {{Form::text('Project_Name',$get_Project->Project_Name,['class'=>'form-control ','placeholder'=>'Project Name']  ) }}
            @if ($errors->has('Project_Name'))
                <span class="help-block" style="color:red;">
                <strong>{{ $errors->first('Project_Name') }}</strong>
                </span>
             @endif
      
        </div>
     
<!-- *********************************************************************  -->
     <!-- *********************************************************************  -->
         <div class="form-group">
        {{Form::label('Description', 'Project Description')}}<span style="color:red;font-size:18pt;">*</span>
        {{Form::textarea('Project_Description',$get_Project->Project_Description,['class'=>'form-control ','placeholder'=>'Project Description','id'=>'article-ckeditor']  ) }}
            @if ($errors->has('Project_Description'))
                <span class="help-block" style="color:red;">
                <strong>{{ $errors->first('Project_Description') }}</strong>
                </span>
             @endif
        </div>
          <script>

      CKEDITOR.replace( 'article-ckeditor' );
  </script>
     
<!-- *********************************************************************  -->
    
         <!--***********************************  -->