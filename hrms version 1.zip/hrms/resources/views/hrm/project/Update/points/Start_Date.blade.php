          
          
                 <!--***********************************  -->
 <h3 class="headerSign" align="center">Start Date&Estimate  Time</h3>
 <!-- *********************************************************************  -->

  <!-- *********************************************************************  -->
                <div class="form-group">
                {{Form::label('Project Start Date', 'Project Start Date')}}<span style="color:red;font-size:18pt;">*</span>
                {{Form::date('Project_Start_Date',$get_Project->Project_Start_Date,['class'=>'form-control','placeholder'=>'Project Start Date']  ) }}
                @if ($errors->has('Project_Start_Date'))
                <span class="help-block" style="color:red;">
                <strong>{{ $errors->first('Project_Start_Date') }}</strong>
                </span>
                @endif
                </div>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
  
                  <!-- *********************************************************************  -->
                <div class="form-group">
                {{Form::label('Estimate Project Time', 'Estimate Project Time')}}<span style="color:red;font-size:18pt;">*</span>
                {{Form::date('Estimate_Project_Time',$get_Project->Estimate_Project_Time,['class'=>'form-control','placeholder'=>'Estimate Project Time']  ) }}
                @if ($errors->has('Estimate_Project_Time'))
                <span class="help-block" style="color:red;">
                <strong>{{ $errors->first('Estimate_Project_Time') }}</strong>
                </span>
                @endif
                </div>
<!-- *********************************************************************  -->
 

   