@extends('layouts.general')


<!-- *************************  left ****************** -->
@section('form_reg')
<link href="{{ asset('css/add.css') }}" rel="stylesheet">  
<br>
{!! Form::open(['action' =>['project_controller@update',$get_Project->id], 'method'=>'POST','enctype'=>'multipart/form-data']) !!}
<fieldset style="padding: 20px;"> 
		 <!--this was made my Agil Asadi. You are free to delete this comment line and use it as you wish-->   
<div class="container">
	<div class="row">
		<h2 class="headerSign" style="">Edit Project</h2>

	</div>
</div>
<div class="row col-md-8 col-ms-5 col-md-offset-2 registeration" style="z-index:100;background-color:rgba(255,255,255,0.8)">
    
<div class="registerInner">
<!-- ********************************  lift -->
        <div class="col-md-6 signUp">

<!-- ********************************  Name & Description -->  
 @include('hrm.project.Update.points.Name_and_Description')
<!-- ********************************  Requirement & Team  -->  
@include('hrm.project.Update.points.Requirement')


 </div>
<!-- ********************************  right  -->       
        <div class="col-md-6">
        <!-- ********************************Start Date&Estimate Time-->  
@include('hrm.project.Update.points.Start_Date')
<!-- ********************************Progress Rate Report -->  
 @include('hrm.project.Update.points.Report_project')
   

   <div class="row" >
 <div class="form-group" style="padding-top:130%;"> 

                <button type="submit" class="signbuttons btn btn-primary pull-right">Save</button>
   </div>
               </div>  
                    
                </div>
<!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
                         <!-- *********************************************************************  -->

        
               
                          <!-- *********************************************************************  -->
		  
<!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
            
        </div>
             
</div>
       
</div>

</fieldset >
      {{Form::hidden('_method','PUT' ) }}    
{!! Form::close() !!}

@endsection