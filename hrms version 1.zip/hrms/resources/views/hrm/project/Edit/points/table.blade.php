      <script type="text/javascript" src="{{ asset('js/get_info.js')}}"></script> 
   <div class="panel-body table-responsive">
        <table class="table table-hover">
          <thead>
            <tr class="th">
              <th class="text-center"> No. </th>
              <th class="text-center"> Project Name </th>
              <th class="text-center"> Project Provider </th>
              <th class="text-center"> Project Start Date</th>
                <th class="text-center"> Team Responsible</th>
              <th class="col-tools text-center"><span class="	glyphicon glyphicon-wrench" aria-hidden="true"></span>
            </tr>
          </thead>

          <tbody>
          @if(count($Projects) >0)
<?php  $i=1; ?>
          @foreach($Projects as $Project)

            <tr class="edit" id="detail">
                         <td style="display:none;" id="Project_Requirement[{{$i}}]">  {!!$Project->Project_Requirement!!} </td>
  <td style="display:none;" id="Project_Description[{{$i}}]">  {!!$Project->Project_Description!!} </td>
  <td style="display:none;" id="Estimate_Project_Time[{{$i}}]">  {{$Project->Estimate_Project_Time}} </td>
  <td style="display:none;" id="Project_Report[{{$i}}]">  {!!$Project->Project_Report!!} </td>

              <td  class="text-center"> {{$i}}</td>
              <td  class="text-center" id="Project_Name[{{$i}}]"> {{$Project->Project_Name}}</td>
              <td class="text-center" id="Project_Provider[{{$i}}]"> {{$Project->Project_Provider}} </td>
           
              <td class="text-center" id="Project_Start_Date[{{$i}}]">  {{$Project->Project_Start_Date}} </td>
              <td class="text-center" id="Team_Responsible[{{$i}}]">  {{$Project->Team_Responsible}} </td>

              <td align="left">


    <a href="/project/{{$Project->id}}/edit" class="btn btn-default " title="" data-original-title="Edit" aria-expanded="true"><span class="glyphicon glyphicon-pencil"
                                                                 aria-hidden="true"></span></a>

          <!--   <button data-toggle="modal" onclick="get_info({{$i}})"  data-target="#ShowModal1" class="btn btn-info"  title="" data-original-title="Edit" aria-expanded="true"><span class="glyphicon glyphicon-list-alt"
                            aria-hidden="true"></span></button>-->
                            <a class="btn btn-info "  onclick="get_info_project({{$i}})"  href="#trainModal" data-toggle="modal" title="" data-original-title="Show Information" aria-expanded="true"><i class="glyphicon glyphicon-list-alt"></i></a> 
  <span>                            
                            {!! Form::open(['action' => ['project_controller@destroy',$Project->id], 'method'=>'POST']) !!}
  {{Form::hidden('_method' ,'DELETE') }}
<?php
echo get_modal($Project->id,$Project->Project_Name);

?>
  {!! Form::close() !!}
  </span>
                            </td>
            </tr>



            <?php  $i++; ?>
            @endforeach
@else 
<td colspan="7" style="text-align:center;"><br><br><strong>No Results</strong><br><br></td>      
@endif
 
          </tbody>
        </table>
      </div>