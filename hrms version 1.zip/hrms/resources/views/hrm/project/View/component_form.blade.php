<link href="{{ asset('css/edit_vol.css') }}" rel="stylesheet">

@extends('layouts.general')

@section('panel_edit')
@include('hrm.project.View.points.modal_show')
    <script type="text/javascript" src="{{ asset('js/get_info.js')}}"></script> 
<link href="{{ asset('css/add.css') }}" rel="stylesheet">   
<link href="{{ asset('css/training_view.css') }}" rel="stylesheet">

 <div class="container-fluid">

    <div class="panel panel-info">
      <div class="panel-heading color_panel" style="color:white;  ">
   @include('hrm.project.View.points.search')
      </div>

   @include('hrm.project.View.points.info_view')

      <div class="panel-footer">
        <div class="row">
          <div class="col-lg-12">
            <div class="col-md-12">
               {{$Projects->links()}}
              </div>
              <div class="col-md-12">
              <p class="muted pull-right"><strong> © 2017 All rights reserved Code For Iraq </strong></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  @endsection