<style>
td{
  color:black;
}
</style>
<!-- line modal -->
<div class="modal fade" id="trainModal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
  <div class="modal-dialog">
	<div class="modal-content">
		<div class="modal-header color_panel">
			<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
			<h3 class="modal-title" id="lineModalLabel">Information Training</h3>
		</div>
		<div class="modal-body">
			
            <!-- content goes here -->
						<div class="row">
                <div class="col-md-3 col-lg-3 " align="center"> <img alt="" src="{{ URL::to('/') }}/Images/logo_home.png" class="img-circle img-responsive"> </div>
          
                <div class=" col-md-9 col-lg-9 "> 
                  <table class="table table-user-information">
                    <tbody>
                      <tr>
                        <td>Project Name:</td>
                        <td ><p id="Project_Name"></p></td>
											</tr>
											<tr>
                        <td>Project Provider:</td>
                        <td><p id="Project_Provider"></p></td>
											</tr>
											<tr>
                        <td>Team Responsible:</td>
                        <td><p id="Team_Responsible"></p></td>
											</tr>
						
                      <tr>
                        <td>Project Start Date:</td>
                        <td><p id="Project_Start_Date"></p></td>
                      </tr>
                      <tr>
                        <td>Estimate Project Time:</td>
                        <td><p id="Estimate_Project_Time"></p></td>
                      </tr>
                
							
											<tr>
                        <td colspan="2">Project Description:<br>
                       <br><p id="Project_Description">  </tr>
                     				<tr>
                        <td colspan="2">Project Requirement:<br>
                       <br><p id="Project_Requirement">  </tr>
                       				<tr>
                        <td colspan="2">Project Report:<br>
                       <br><p id="Project_Report">  </tr>
                    </tbody>
                  </table>
                  

                </div>
              </div>

		</div>
		<div class="modal-footer">
			<div class="btn-group btn-group-justified" role="group" aria-label="group button">
				<div class="btn-group" role="group">
					<button type="button" class="btn btn-default" data-dismiss="modal"  role="button">Close</button>
				</div>
			</div>
		</div>
	</div>
  </div>
</div>