
                        
<div class="panel-body table-responsive">
@if(count($Projects) >0)
<?php  $i=1; ?>
          @foreach($Projects as $Project)
<div class=" col-md-3">
<ul class="eight">
  <li class="transition">
    <div class="wrapper" > <span class="transition" >
      <h3 class="transition">{{$Project->Project_Name}}<em>{{$Project->Project_Start_Date}}</em></h3>
     <span id="Project_Name[{{$i}}]" style="display:none;">{{$Project->Project_Name}}</span>
     
      <span id="Project_Start_Date[{{$i}}]" style="display:none;">{{$Project->Project_Start_Date}}</span>
      <span id="Training_Place[{{$i}}]" style="display:none;">{{$Project->Training_Place}}</span>
      <span id="Training_Start_Date[{{$i}}]" style="display:none;">{{$Project->Training_Start_Date}}</span>
      <span id="Estimate_Project_Time[{{$i}}]" style="display:none;">{{$Project->Estimate_Project_Time}}</span>

 <span style="display:none;" id="Project_Description[{{$i}}]">  {!!$Project->Project_Description!!} </span>
 <span style="display:none;" id="Project_Report[{{$i}}]">  {!!$Project->Project_Report!!} </span>
              <span style="display:none;" id="Project_Requirement[{{$i}}]">  {!!$Project->Project_Requirement!!} </span>

              <span style="display:none;" id="Project_Provider[{{$i}}]"> {{$Project->Project_Provider}} </span>
           
            <span style="display:none;" id="Team_Responsible[{{$i}}]">  {{$Project->Team_Responsible}} </span>




      <div class="image-container transition">
        <div class="creation" >
          <div class="front" >
            <div class="cont" > <i class="details"><img width="100" class="icon-circle transition" src="{{ URL::to('/') }}/Images/project-icon.png" ></img> </div>
          </div>
          <div class="back">
            <div class="cont" > <i class="details"><img width="100" src="{{ URL::to('/') }}/Images/vinger.png"  ></img> </div>
          </div>
        </div>
      </div>
      </span>
      <ul class="social transition" align="center" style="margin-left:36%;">
        <li class="transition"><button onclick="get_info_project({{$i}})" data-toggle="modal" data-target="#trainModal" class="btn btn-info center-block"><i class="glyphicon glyphicon-list-alt"></i> View</button></li>
   </ul>
      <div class="arrow"></div>
    </div>
  </li>

</ul>
</div>
<?php  $i++; ?>
            @endforeach
@else 
<p colspan="7" style="text-align:center;"><br><br><strong>No Results</strong><br><br></p>      
@endif
</div>