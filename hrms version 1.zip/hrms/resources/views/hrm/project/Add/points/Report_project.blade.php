        
            <h3 class="headerSign" align="center">Progress Rate Report</h3>
                          <!-- *********************************************************************  -->
    <div class="form-group">                    
        {{Form::label('Project Report', 'Project Report')}}<span style="color:red;font-size:18pt;">*</span>
        {{Form::textarea('Project_Report','',['class'=>'form-control ','placeholder'=>'Project Report','id'=>'txt1']  ) }}
            @if ($errors->has('Project_Report'))
                <span class="help-block" style="color:red;">
                <strong>{{ $errors->first('Project_Report') }}</strong>
                </span>
             @endif     
                    
    </div>

      <script>
    
      document.getElementById('txt1').id="article-ckeditor";
        CKEDITOR.replace('article-ckeditor' );
    
  </script>
<!-- *********************************************************************  -->
<!--***************************************************************  -->
            
    {{--  <label class="cols-sm-2 control-label "> Progress Rate<span style="color:red;font-size:18pt;">*</span></label>            
    <div class="progress">
    <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 15%;">
    </div>
    <span class="progress-type">15 </span>
    </div>  --}}