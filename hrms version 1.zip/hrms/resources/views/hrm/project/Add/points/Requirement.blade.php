        
        
                               <!--***********************************  -->
 <h3 class="headerSign" align="center">Requirement & Team</h3>
<!-- *********************************************************************  -->
                <div class="form-group">
                {{Form::label('Project Requirement', 'Project Requirement')}}<span style="color:red;font-size:18pt;">*</span>
                {{Form::textarea('Project_Requirement','',['class'=>'form-control ','placeholder'=>'Project Requirement','id'=>'txt2']  ) }}
                @if ($errors->has('Project_Requirement'))
                <span class="help-block" style="color:red;">
                <strong>{{ $errors->first('Project_Requirement') }}</strong>
                </span>
                @endif
                </div>
                <script>
     document.getElementById('article-ckeditor').id="none";
      document.getElementById('txt2').id="article-ckeditor";
        CKEDITOR.replace('article-ckeditor' );
       document.getElementById('article-ckeditor').id="txt2";
      
                </script>
<!-- *********************************************************************  -->
<!-- *********************************************************************  -->
                <div class="form-group">
                {{Form::label('Project Provider', 'Project Provider')}}<span style="color:red;font-size:18pt;">*</span>
                {{Form::text('Project_Provider','',['class'=>'form-control','placeholder'=>'Project Provider']  ) }}
                @if ($errors->has('Project_Provider'))
                <span class="help-block" style="color:red;">
                <strong>{{ $errors->first('Project_Provider') }}</strong>
                </span>
                @endif
                </div>
<!-- *********************************************************************  -->
       <!-- *********************************************************************  -->
                <div class="form-group">
                {{Form::label('Team Responsible for the Project', 'Team Responsible')}}<span style="color:red;font-size:18pt;">*</span>
                {{Form::text('Team_Responsible','',['class'=>'form-control','placeholder'=>'Team Responsible for the Project']  ) }}
                @if ($errors->has('Team_Responsible'))
                <span class="help-block" style="color:red;">
                <strong>{{ $errors->first('Team_Responsible') }}</strong>
                </span>
                @endif
                </div>
<!-- *********************************************************************  -->
 