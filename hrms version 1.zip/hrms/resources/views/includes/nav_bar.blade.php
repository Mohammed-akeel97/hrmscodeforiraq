<!-- *************************  left ****************** -->


<!--*********************** Start Navbar *************** -->


@foreach($messages as $numbers)
<?php
$num_message=$numbers->num;
?>
@endforeach
<header>
<div class="top_bar">
<div class="container">
<div class="col-md-6">
<ul class="social">
<!-- <li><a target="_blank" href="https://facebook.com"><i class="fa fa-facebook text-white"></i></a></li>
<li><a target="_blank" href="https://twitter.com"><i class="fa fa-twitter text-white"></i></a></li>
<li><a target="_blank" href="http://instagram.com"><i class="fa fa-instagram text-white"></i></a></li> -->
</ul></div>

<div class="col-md-6">
<ul class="rightc">
<li><i class="glyphicon glyphicon-envelope"></i> <span >{{ Auth::user()->email }} </span></li>
<li><i class="glyphicon glyphicon-user"></i> <a href="{{ URL::to('/user') }}">{{ Auth::user()->name }}</a></li>      
</ul>
</div>
</div>
</div>
<!--top_bar-->



<nav class="navbar navbar-default" role="navigation">
    	<div class="container">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="#"><img src=""> 

				</a>
				<a  class="navbar-brand"  href="{{ URL::to('/') }}"><span>&lt;IRAQ/&gt;</span></a>
			</div>

			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="color: #30bed6;">
				
				
				<ul class="nav navbar-nav navbar-right" style="">
				
			<li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Volunteer <b class="caret"></b></a>
            <ul class="dropdown-menu">
     <li><a href="{{ URL::to('/volunteer/create') }}"><b class="glyphicon glyphicon-plus"></b> Add Volunteer</a></li>
							<li><a href="{{ URL::to('/volunteer') }}"><b class="glyphicon glyphicon-pencil"></b> Edit Volunteer</a></li>
						
							<li class="divider"></li>
							<li><a href="{{ URL::to('/volunteer/search') }}"><b class="glyphicon glyphicon-search"></b> Search Volunteer</a></li>
            </ul>
          </li>  


				   <!-- ******************************8 -->
			<li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">  Project <b class="caret"></b></a>
            <ul class="dropdown-menu">
      	<li><a  href="{{ URL::to('/project/create/') }}"><b class="glyphicon glyphicon-plus"></b> Add Project</a></li>
	<li><a href="{{ URL::to('/project') }}"><b class="glyphicon glyphicon-pencil"></b> Edit Project</a></li>
						
	<li class="divider"></li>
	<li><a  href="{{ URL::to('/project/search') }}"><b class="glyphicon glyphicon-search"></b> Search Project</a></li>
            </ul>
          </li>   
                  					 <!-- ******************************88  -->

		<li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Training <b class="caret"></b></a>
            <ul class="dropdown-menu">
     <li><a href="{{ URL::to('/training/create') }}"> <b class="glyphicon glyphicon-plus"></b>Add Training</a></li>
							
							
							<li><a href="{{ URL::to('/training/edit') }}"><b class="glyphicon glyphicon-pencil"></b> Edit Training</a></li>
							<li class="divider"></li>
							<li><a  href="{{ URL::to('/training') }}"><b class="glyphicon glyphicon-search"></b> View Training</a></li>
            </ul>
          </li>  

 <!-- ******************************88  --> 
                    <li><a  href="{{ URL::to('/announcement') }}"><i class="glyphicon glyphicon-bullhorn"></i>   Announcement 	&nbsp;  <span class="badge" id="msg_num" style="color:white;background-color:red;font-size:10pt; border-radius: 50%;  display: @if(!$num_message){{'none' }}@endif ;">{{$num_message}}</span></a></li>





                   


                    <li><a href="{{ URL::to('/reports') }}"> <i class="glyphicon glyphicon-folder-close"></i>  Reports </a></li>
			     
				 
					<li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><b class="glyphicon glyphicon-cog"></b></a>
            <ul class="dropdown-menu">
						<li><a href="{{ URL::to('/dashboard') }}"><b class="glyphicon glyphicon-globe"> </b> Dashboard</a></li>
   
			<li><a href="{{ URL::to('/user') }}"><b class="glyphicon glyphicon-user"> </b> Profile</a></li>
    <li>
                                        <a href="{{ route('logout') }}"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                  <i class="glyphicon glyphicon-off"></i>          Logout
                                        </a>

                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display:none;">
                                            {{ csrf_field() }}
                                        </form>
										</li>
										</ul>
                                    </li>
				</ul>

			</div><!-- /.navbar-collapse -->
		</div><!-- /.container-fluid -->
	</nav>
   
</header>
<audio controls id="vnotification" style="display:none;">
  <source src="{{ URL::to('/') }}/sounds/noti_sound.ogg" type="audio/ogg">
</audio>
<!--*********************** End Navbar ***************/ -->
<script>
var j=setInterval(num_message,3000);
</script>
