<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">

<head>
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

 <link rel="shortcut icon" href="{{ URL::to('/') }}/Images/logo_home.png" type="image/x-icon" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

<script>var host='{{ URL::to('/') }}';</script>
    <title>Code For Iraq</title>
    <div id="bsp">
       <script src="{{ URL::to('/') }}/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
           <script src="{{ URL::to('/') }}/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
    <script src="{{ URL::to('/') }}/vendor/unisharp/laravel-ckeditor/adapters/jquery.js"></script>
     <script src="{{ URL::to('/') }}/vendor/unisharp/laravel-ckeditor/styles.js"></script>
       <link rel="shortcut icon" href="{{ URL::to('/') }}/vendor/unisharp/laravel-ckeditor/contents.css" />
    <link rel="stylesheet" href="{{ URL::to('/') }}/Images/logo_home.png" type="image/x-icon" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
      <link href="{{ asset('css/app.css') }}" rel="stylesheet">
       <link href="{{ asset('css/check_box.css') }}" rel="stylesheet">
           <link href="{{ asset('bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">
                       <script type="text/javascript" src="{{ asset('bootstrap/jquery/jquery-3.2.1.min.js')}}"></script>
                                <script type="text/javascript" src="{{ asset('bootstrap/js/bootstrap.min.js')}}"></script>
                                <script type="text/javascript" src="{{ asset('js/suport.js')}}"></script> 
                              
                                     <script type="text/javascript" src="{{ asset('push/bin/push.min.js')}}"></script>     
      <link href="{{ asset('css/nav_bar.css') }}" rel="stylesheet">
       <link href="{{ asset('css/footer.css') }}" rel="stylesheet">
       <link href="{{ asset('css/color_panel.css') }}" rel="stylesheet">
       <link href="{{ asset('css/button_style.css') }}" rel="stylesheet">
       <link href="{{ asset('css/input_style.css') }}" rel="stylesheet">
     </div>
     <script>
function announcement_noti() {
    Push.create('You Have New Announcement  HRMS', {
        body: 'Press To View New Announcement',
        icon: '{{ URL::to('/') }}/Images/announcement_icon.png',
    
       
        onClick: function () {
        
            window.focus();
         location.href="/announcement";
           this.close();
        },
        vibrate: [200, 100, 200, 100, 200, 100, 200]
    });
}



     </script>
           <style>
           html,body{
               background-image:url("{{ URL::to('/') }}/Images/bg_photo_hrms.png");
               
           }
           </style>
@include('includes.nav_bar')

</head>

<body style="zoom: 1;">

@if (session('success'))
<div class="container">
<div class="row col-md-8 col-md-offset-2">
<div class="alert alert-success alert-success fade in">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
<strong>Success!</strong>  {{session('success')}}.
</div>
</div>
</div>
@endif
@if (session('errors'))
<div class="container">
<div class="row col-md-8 col-md-offset-2">
<div class="alert alert-success alert-danger fade in">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Danger!</strong> Not Successful  You Have Fileds.
  </div>
</div>
</div>
@endif

@if (session('error'))
<div class="container">
<div class="row col-md-8 col-md-offset-2">
<div class="alert alert-success alert-danger fade in">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Danger!</strong>  {{session('error')}}.
  </div>
</div>
</div>
@endif

@yield('form_reg')
@yield('home')
@yield('panel_edit')
@yield('content')

@include('includes.footer')


</body>
  <script>
        CKEDITOR.replace( 'article-ckeditor' );
    </script>
</html>