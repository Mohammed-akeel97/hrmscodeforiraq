@extends('layouts.app')

@section('content')
     
<?php
//****** arabic
function arabic_lan(){
    $bg_img="../wp4.jpg";
        $logo_bath="../logo_code_for_iraq2.png";
        $lan_arr=['login_title'=>"تسجيل الدخول",'p_password'=>"الرمز السري",'p_email'=>"البريد الالكتروني",'p_login'=>"تسجيل الدخول",'logo'=>$logo_bath
      ,'bg_img' =>$bg_img ,'logo_title'=>"Code For Baghdad",'g_title'=>"اهلا وسهلا في Code For Iraq",'system_title'=>"HRMS",'language'=>"ar"];
     return $lan_arr;
}
// ********** english
function  english_lan(){
    $bg_img="../wp4.jpg";
        $logo_bath="../logo_code_for_iraq2.png";
   $lan_arr=['login_title'=>"Login",'p_password'=>"Password",'p_email'=>"E-mail",'p_login'=>"login",'logo'=>$logo_bath
     ,'bg_img' =>$bg_img,'logo_title'=>"Code For Baghdad",'g_title'=>"Welcome To Code For Iraq",'system_title'=>"HRMS",'language'=>"en"];
   
   return $lan_arr;

}




///*********************************** set language
 
if(isset($_GET['language'])){
    
     // arabic
 if($_GET['language']=="ar"){
 $lan_arr=arabic_lan();
 }
 else 
 $lan_arr=english_lan();
 
}
// english
else{
 $lan_arr=english_lan();
 }

//********************************************************************
?>
	<div class="container">
	<div class="row">
	
        <div class="col-md-12 ">
        <h2 class="headerSign" style="<?php if($lan_arr['language']=="ar")echo "direction:rtl";?>">{{$lan_arr['g_title']}}</h2>
        <h2 class="headerSign" style="">{{$lan_arr['system_title']}}</h2>
  <div style="padding: 20px; display: block;" id="form-olvidado">
  <form class="form-horizontal" method="POST" action="{{ route('login') }}"   id="login-form">
  <fieldset >
  <!-- ********************************************************************** -->
       
  {{ csrf_field() }}
	 <!--this was made my Agil Asadi. You are free to delete this comment line and use it as you wish-->   
<div class="container">
	<div class="row">
	
	</div>
</div>
<div class="row col-md-8 col-md-offset-2 registeration">
    
<div class="registerInner">
        <div class="col-md-6 signUp">
            <h3 class="headerSign" align="center">{{$lan_arr['login_title']}}</h3>
            <form class="form-horizontal" method="POST" action="{{ route('login') }}">
                        {{ csrf_field() }}
                <div class="form-group {{ $errors->has('email') ? ' has-error' : '' }}">                    
                    <input class="form-control" type="email" name="email" value="{{ old('email') }}" placeholder="{{$lan_arr['p_email']}}">
                       @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                </div>
                 
                <div class="form-group {{ $errors->has('password') ? ' has-error' : '' }}">
             
                    
                    <input class="form-control" type="password" name="password" placeholder="{{$lan_arr['p_password']}}" value="">
   @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
</div>
<div class="form-group">
                            <div class="col-md-6 col-md-offset-0">
                                <div class="checkbox pull-right">
                                    <label>
                                    <input type="checkbox" style="height:50px;" name="remember" class="" {{ old('remember') ? 'checked' : '' }}> <strong class="headerSign" align="center">Remember Me</strong>
                                   </label>
                                  
                                  
                                </div>



                            </div>

    



                        </div>
  <div class="col-md-13">
                <button type="submit" class="signbuttons btn btn-primary <?php if($lan_arr['language']=="ar")echo "pull-right";?>">{{$lan_arr['p_login']}}</button>
             </div> 
             <a class="" class="headerSign" href="#" id="olvidado"><small>Forgot your password?</small></a>   
            
               <br>
               <br>
    
        </div>

             
             
        <div class="col-md-6">
            <h3 class="headerSign">Code For Baghdad</h3>
     
     <div class="col-md-9  col-md-offset-2 " align="..."> <img alt="" style="border-radius: 30px;margin-top:-30px;" src="{{ URL::to('/') }}/Images/logo_home.png" class="img-responsive"> </div>
     
            
        </div>
             
</div>

        
          
</div>






     <!-- ****************************************************************************** -->
   
      </fieldset>
    </form>
  </div>
  <!-- ********************************************************************** -->
  <div style="display: none;" id="form-olvidado">
  <form class="form-horizontal" method="POST" action="{{ route('password.email') }}" id="login-recordar">
            {{ csrf_field() }}

         
    <fieldset style="padding: 20px;"> 
    <div class="container">
	<div class="row">
	
	</div>
</div>
<div class="row col-md-6 col-md-offset-3 registeration">
    
<div class="registerInner">
        <div class="col-md-12 signUp">
            <h3 class="headerSign" align="center">Send Email</h3>
         
            <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
            <div class="col-md-12">
                <input id="email" type="email" class="form-control" placeholder="example@domin.com" name="email" value="{{ old('email') }}" required>

                @if ($errors->has('email'))
                    <span class="help-block">
                        <strong>{{ $errors->first('email') }}</strong>
                    </span>
                @endif
            </div>
        </div>
        <br>
        <div class="form-group">
        <div class="col-md-11 col-md-offset-3">
            <button type="submit" class="btn btn-primary">
                Send Password Reset Link
            </button>
        </div>
    </div>
             <a class="text-muted" class="headerSign" href="#" id="acceso"><small class="headerSign">Login</small></a>  
            
               <br>
               <br>
        
        </div>

             
    
</div>

        
          
</div>






     <!-- ****************************************************************************** -->
      </fieldset>
    </form>
  </div>
</div>
	</div>
</div>
	<script type="text/javascript">
	$(document).ready(function() {
  $('#olvidado').click(function(e) {
    e.preventDefault();
    $('div#form-olvidado').toggle('500');
  });
  $('#acceso').click(function(e) {
    e.preventDefault();
    $('div#form-olvidado').toggle('500');
  });
});
	</script>
@endsection
