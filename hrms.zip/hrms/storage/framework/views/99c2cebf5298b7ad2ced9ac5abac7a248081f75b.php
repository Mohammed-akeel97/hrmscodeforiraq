<!-- *************************  left ****************** -->
<?php $__env->startSection('nav_bar'); ?>

		<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">

<!--*********************** Start Navbar *************** -->
<style type="text/css">

</style>


<header>
<div class="top_bar">
<div class="container">
<div class="col-md-6">
<ul class="social">
<li><a target="_blank" href="https://www.webenlance.com/"><i class="fa fa-facebook text-white"></i></a></li>
<li><a target="_blank" href="https://webenlance.com"><i class="fa fa-twitter text-white"></i></a></li>
<li><a target="_blank" href="http://webenlance.com"><i class="fa fa-instagram text-white"></i></a></li>
</ul></div>

<div class="col-md-6">
<ul class="rightc">
<li><i class="fa fa-envelope-o"></i> ahmed_alawi@gmail.com  </li>
<li><i class="fa fa-user"></i> <a href="webenlance.com">Ahmed Alawi</a></li>      
</ul>
</div>
</div>
</div>
<!--top_bar-->



<nav class="navbar navbar-default" role="navigation">
    	<div class="container">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="#"><img src=""> 

				</a>
				<a  class="navbar-brand"  href="/home"><span>&lt;IRAQ/&gt;</span></a>
			</div>

			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="color: #30bed6;">
				
				
				<ul class="nav navbar-nav navbar-right" style="">
				
						<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Volunteer</a>
						<ul class="dropdown-menu" style="display: none;">
							<li><a href="/volunteer/add_volunteer">Add Volunteer</a></li>
							<li><a href="/volunteer/edit_volunteer">Edit Volunteer</a></li>
						
							<li class="divider"></li>
							<li><a href="#">Search Volunteer</a></li>
						</ul>
					</li>

	<li><a href="#">  Patients</a></li>
                  
								<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Project</a>
						<ul class="dropdown-menu" style="display: none;">
							<li><a href="#">Add Project</a></li>
							<li><a href="#">Edit Project</a></li>
						
							<li class="divider"></li>
							<li><a href="#">Search Project</a></li>
						</ul>
					</li>
                    <li><a href="#">   Training</a></li>
                    <li><a href="#">   Announcement </a></li>
                    <li><a href="#">   Reports</a></li>
                    <li><a href="#">   LogOut</a></li>
				</ul>

			</div><!-- /.navbar-collapse -->
		</div><!-- /.container-fluid -->
	</nav>
   
</header>
	<script type="text/javascript">
	
$(document).ready(function(){

    $(".dropdown").hover(            

        function() {

            $('.dropdown-menu', this).not('.in .dropdown-menu').stop( true, true ).slideDown("fast");

            $(this).toggleClass('open');        

        },

        function() {

            $('.dropdown-menu', this).not('.in .dropdown-menu').stop( true, true ).slideUp("fast");

            $(this).toggleClass('open');       

        }

    );

});
	</script>
<!--*********************** End Navbar ***************/ -->
<?php $__env->stopSection(); ?>

