   <div class="panel-body table-responsive">
        <table class="table table-hover">
          <thead>
            <tr class="th">
              <th class="text-center"> No. </th>
              <th class="text-center"> Title </th>
              <th class="text-center"> Trainer Name </th>
              <th class="text-center"> Training Place </th>
              <th class="text-center"> Training Start Date</th>
                  <th class="col-tools text-center"><span class="	glyphicon glyphicon-wrench" aria-hidden="true"></span>
            </tr>
          </thead>

          <tbody>
        <?php for($i=1;$i<5;$i++): ?>
            <tr class="edit" id="detail">
              <td  class="text-center"> 1</td>
              <td  class="text-center"> programming</td>
              <td class="text-center">Ali </td>
              <td class="text-center"> baghdad </td>
              <td  class="text-center"> 20/10/2018</td>
               <td align="center">
                                <a href="/training/<?php echo e($i); ?>/edit" class="btn btn-default"><span class="glyphicon glyphicon-pencil"
                                                                 aria-hidden="true"></span></a>
                                <a class="btn btn-danger"><span class="glyphicon glyphicon-trash"
                                                                aria-hidden="true"></span></a>
 <a class="btn btn-info"><span class="glyphicon glyphicon-list-alt"
                            aria-hidden="true"></span></a>
                            </td>
            </tr>
<?php endfor; ?>
 
          </tbody>
        </table>
      </div>