

<html lang="en"><head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex, nofollow">

    <title>Code For Iraq</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
      <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
       <script src="<?php echo e(asset('js/app.js')); ?>"></script>
        
           <link href="<?php echo e(asset('css/login.css')); ?>" rel="stylesheet">
<style>
html,body{
background-image:url("<?php echo e($bg_img); ?>");
}
</style>
</head>
<body style="zoom: 1;">
	 <!--this was made my Agil Asadi. You are free to delete this comment line and use it as you wish-->   
<div class="container">
	<div class="row">
		<h2 class="headerSign" style="<?php if($language=="ar")echo "direction:rtl";?>"><?php echo e($g_title); ?></h2>
        <h2 class="headerSign" style=""><?php echo e($system_title); ?></h2>
	</div>
</div>
<div class="row col-md-8 col-md-offset-2 registeration">
    
<div class="registerInner">
        <div class="col-md-6 signUp">
            <h3 class="headerSign" align="center"><?php echo e($login_title); ?></h3>
            <form action="" method="post">

         
                <div class="form-group">                    
                    <input class="form-control" type="text" name="email"  placeholder="<?php echo e($p_email); ?>">
                </div>
                 
                <div class="form-group">
             
                    <input class="form-control" type="password" name="password" placeholder="<?php echo e($p_password); ?>" value="">
</div>
  <div class="col-md-13">
                <button type="submit" class="signbuttons btn btn-primary <?php if($language=="ar")echo "pull-right";?>"><?php echo e($p_login); ?></button>

               </div> 
               <br>
               <br>
            </form>
        </div>

             
             
        <div class="col-md-6">
            <h3 class="headerSign"><?php echo e($logo_title); ?></h3>
     
     <div class="col-md-9  col-md-offset-2 " align="..."> <img alt="" style="border-radius: 30px;margin-top:-30px;" src="<?php echo e($logo); ?>" class="img-responsive"> </div>
     
            
        </div>
             
</div>
        
</div>


</body></html>
