

<script>
function myFunction(selTag) {
  
    var x = selTag.selectedIndex;
    var pg=document.getElementById("Parent_Group");
    if(x==1)
pg.disabled = true;
    if(x==2)
pg.disabled = false;
}



</script>


     <h3 class="headerSign"><?php echo e($title_panel_Group_Information); ?></h3>
     <!-- *******************************  -->
                <div class="form-group">                    
                <?php echo e(Form::label('Volunteer_Code', $Volunteer_Code)); ?><span style="color:red;font-size:18pt;">*</span>
           
                    <?php echo e(Form::select('Volunteer_Code', [
   'st' => 'Strategy',
   'hr' => 'Human Resorce',
   'ar' => 'Art',
   '[pr]' => 'Project',
   ],'',['class'=>'form-control','placeholder'=>$Volunteer_Code]
)); ?>

                </div>
                <?php if($errors->has('Volunteer_Code')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Volunteer_Code')); ?></strong>
                                    </span>
                                <?php endif; ?>
                <!-- **************************** -->
                  <div class="form-group" >                    
                <?php echo e(Form::label('Position', $Position)); ?><span style="color:red;font-size:18pt;">*</span>
           
                    <?php echo e(Form::select('Position', [
                        $Position_Manager => $Position_Manager,
                        $Position_Volunteer => $Position_Volunteer,
                        
   ],'',['class'=>'form-control','placeholder'=>$Position,'onclick'=>'myFunction(this)']
)); ?>

<?php if($errors->has('Position')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Position')); ?></strong>
                                    </span>
                                <?php endif; ?>
                </div>
                 <!-- **********************************  -->

    <div class="form-group">                    

                     
                <?php echo e(Form::label('Parent_Group', $Parent_Group)); ?>

           
                    <?php echo e(Form::select('Parent_Group', [
                        $Parent_Group => $Parent_Group,               
   ],'',['class'=>'form-control','placeholder'=>$Parent_Group_title,]
)); ?>

                </div>
         <!--***********************************  -->