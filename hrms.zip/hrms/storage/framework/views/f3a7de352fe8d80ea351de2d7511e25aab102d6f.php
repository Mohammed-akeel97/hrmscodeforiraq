<!-- *************************  left ****************** -->
<link href="<?php echo e(asset('css/add.css')); ?>" rel="stylesheet">
<?php $__env->startSection('Name_and_Description'); ?>

<!-- *******************************  -->


     <h3 class="headerSign">Name & Description</h3>
     <!-- *******************************  -->
      <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Project Name<span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="text" name="Project_Name" placeholder="Project Name" value="">
</div>
<!-- *********************************************************************  -->
     <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Description<span style="color:red;font-size:18pt;">*</span></label>
                    <textarea class="form-control"  name="Description" placeholder="Description" value=""></textarea>
</div>
<!-- *********************************************************************  -->
    
         <!--***********************************  -->
                                <?php $__env->stopSection(); ?>








<?php $__env->startSection('Requirement'); ?>



                               <!--***********************************  -->
 <h3 class="headerSign" align="center">Requirement & Team</h3>
<!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Project Requirement<span style="color:red;font-size:18pt;">*</span></label>
                    <textarea class="form-control"  name="Project_Requirement" placeholder="Project Requirement" value=""></textarea>
</div>
<!-- *********************************************************************  -->
       <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Project Provider<span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="text" name="Project_Provider" placeholder="Project Provider" value="">
</div>
<!-- *********************************************************************  -->
       <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Team Responsible for the Project<span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="text" name="Team_Responsible" placeholder="Team Responsible for the Project" value="">
</div>
<!-- *********************************************************************  -->
 
   <?php $__env->stopSection(); ?>
 







  <?php $__env->startSection('Start_Date'); ?>

                 <!--***********************************  -->
 <h3 class="headerSign" align="center">Start Date&Estimate  Time<span style="color:red;font-size:18pt;">*</span></h3>
 <!-- *********************************************************************  -->

  <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Project Start Date</label>
                    <input class="form-control" type="date" name="Project_Start_Date" placeholder="Project Start Date" value="">
</div>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
  
                  <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Estimate Project Time<span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="text" name="Estimate_Project_Time" placeholder="Estimate Project Time" value="">
</div>
<!-- *********************************************************************  -->
 

   
 
    <?php $__env->stopSection(); ?>







<?php $__env->startSection('Report_project'); ?>


               <h3 class="headerSign" align="center">Progress Rate Report</h3>
                          <!-- *********************************************************************  -->
    <div class="form-group">                    
                <label class="cols-sm-2 control-label ">  Project Report<span style="color:red;font-size:18pt;">*</span></label>
                       
                    <textarea class="form-control" type="text" name="project_report" placeholder="Project Report" value=""></textarea>

                    
                </div>
                                                         <!-- *********************************************************************  -->
<!--***************************************************************  -->
            
            <label class="cols-sm-2 control-label "> Progress Rate<span style="color:red;font-size:18pt;">*</span></label>
                  
      <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 15%;">
         
            </div>
            <span class="progress-type">15 </span>
          
        </div>

<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.project.form_add', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>