<link href="<?php echo e(asset('css/add.css')); ?>" rel="stylesheet">
<!-- *************************  left ****************** -->
<?php $__env->startSection('form_reg'); ?>
<br>
<form action="" method="POST">
	 <!--this was made my Agil Asadi. You are free to delete this comment line and use it as you wish-->   
<div class="container">
	<div class="row">
		<h2 class="headerSign" style="">Announcement Send E-mail</h2>

	</div>
</div>
<div class="row col-md-8 col-ms-5 col-md-offset-2 registeration" style="z-index:100;background-color:rgba(255,255,255,0.8)">
    
<div class="registerInner">
<!-- ********************************  lift -->
        <div class="col-md-6 signUp">
<br>

  <?php echo $__env->yieldContent('from'); ?>
 <?php echo $__env->yieldContent('to'); ?>
 

 </div>
<!-- ********************************  right -->       
        <div class="col-md-6">
        <br>
<?php echo $__env->yieldContent('subject'); ?>

<?php echo $__env->yieldContent('msg'); ?>
 
                    
                </div>
<!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
                         <!-- *********************************************************************  -->

                
             
       
       <br>  <br>  <br>                    <!-- *********************************************************************  -->
 <div class="form-group"> 
     <br>  <br>  <br>  <br>
           
                <button type="submit" class="signbuttons btn btn-primary pull-right">Send</button>
   <br>  
               </div>  

 
<!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
            
        </div>
             
</div>
       
</div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.nav_bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.general', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>