<link href="<?php echo e(asset('css/add.css')); ?>" rel="stylesheet">
<!-- *************************  left ****************** -->
<?php $__env->startSection('form_reg'); ?>
<br>
<form action="" method="POST">
	 <!--this was made my Agil Asadi. You are free to delete this comment line and use it as you wish-->   
<div class="container">
	<div class="row">
		<h2 class="headerSign" style="">Announcement Send E-mail</h2>

	</div>
</div>
<div class="row col-md-8 col-ms-5 col-md-offset-2 registeration" style="z-index:100;background-color:rgba(255,255,255,0.8)">
    
<div class="registerInner">
<!-- ********************************  lift -->
        <div class="col-md-6 signUp">
<br>

 <?php echo $__env->make('hrm.Announcement.points.left', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
 
 </div>
<!-- ********************************  right -->       
        <div class="col-md-6">
        <br>
 <?php echo $__env->make('hrm.Announcement.points.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
                    
                </div>
<!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
<?php echo $__env->make('hrm.Announcement.points.check_box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                         <!-- *********************************************************************  -->

                
             
       
                  <!-- *********************************************************************  -->
 <div class="form-group"> 
 
           
                <button type="submit" class="signbuttons btn btn-primary pull-right">Send</button>
   <br>  
               </div>  

 
<!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
            
        </div>
             
</div>
       
</div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.general', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>