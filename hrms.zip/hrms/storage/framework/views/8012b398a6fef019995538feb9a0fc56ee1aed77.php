                <!--***********************************  -->
 <h3 class="headerSign" align="center"><?php echo e($title_panel_Means_of_communication); ?><span style="color:red;font-size:18pt;">*</span></h3>
 <!-- *********************************************************************  -->

 <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label "><?php echo e($email); ?><span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="email" name="email" placeholder="<?php echo e($email); ?>" value="">
</div>
<!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label "><?php echo e($Phone_Number1); ?><span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="text" name="Phone_Number1" placeholder="<?php echo e($Phone_Number1); ?>" value="">
</div>
<!-- *********************************************************************  -->
  <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label "><?php echo e($Phone_Number2); ?></label>
                    <input class="form-control" type="text" name="Phone_Number2" placeholder="<?php echo e($Phone_Number2); ?>" value="">
</div>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
  
           
