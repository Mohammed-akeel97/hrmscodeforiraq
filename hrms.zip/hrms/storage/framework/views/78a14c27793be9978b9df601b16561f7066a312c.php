

<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
       <script src="<?php echo e(asset('js/app.js')); ?>"></script>

<?php echo Form::open(['url' => '/veiw']); ?>

<?php echo e(Form::label('email'.'E-mail Adrees')); ?>

<br>
<?php echo e(Form::text('email')); ?>

<br>

<?php echo e(Form::file('image')); ?>

<br>
<?php echo e(Form::select('size', ['L' => 'Large', 'S' => 'Small'], 'L')); ?>

<br>
<?php echo e(Form::select('animal',[
    'Cats' => ['leopard' => 'Leopard','leop' => 'Leop'],
    'Dogs' => ['spaniel' => 'Spaniel'],
])); ?>

<br>
<?php echo e(Form::selectRange('number', 10, 20)); ?>

<br>
<?php echo e(Form::submit('Click Me!')); ?>

<br>
<div class="form-group">
    <?php echo e(Form::label('name', null, ['class' => 'control-label'])); ?>

    <?php echo e(Form::text('name', 1, ['class' => 'form-control'], '')); ?>

</div>
<br>
<?php echo e(link_to('foo/bar', $title = null, $attributes = [], $secure = null)); ?>

<br>
 
 <br>
<?php echo e(Form::checkbox('name', 'value', true)); ?>

<br>
<?php
// echo Form::email($name, $value = null, $attributes = []);
// echo Form::file($name, $attributes = []);

?>
 <?php echo e(Form::radio('name', 'value', true)); ?>

<?php echo Form::close(); ?>