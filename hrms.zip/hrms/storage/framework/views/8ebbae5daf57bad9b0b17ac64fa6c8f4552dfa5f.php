 
 <?php $__env->startSection('title_and_name'); ?>
 <h3 class="headerSign">Title & Trainer Name</h3>
                 <!--***********************************  -->
<!-- *********************************************************************  -->

  <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Title Trining<span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="text" name="Title_Trining"   placeholder="Title Trining" value="">
</div>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
  <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Trainer Name<span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="text" name="Trainer_Name"   placeholder="Trainer Name" value="">
</div>
<!-- *********************************************************************  -->

  
    <?php $__env->stopSection(); ?>


     <?php $__env->startSection('date_and_place'); ?>
 <h3 class="headerSign">Training Place & Date Start</h3>
     
                 <!--***********************************  -->
 <!-- *********************************************************************  -->

  <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Training Place<span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="text" name="Training_Place" placeholder="Training Place" value="">
</div>
<!-- *********************************************************************  -->
  <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Training Start Date<span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="date" name="Start_Date" placeholder="Training Start Date" value="">
</div>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
  
    <?php $__env->stopSection(); ?>



         <?php $__env->startSection('Status'); ?>
 <h3 class="headerSign">Training Course Duration & Status</h3>
     
                 <!--***********************************  -->
 <!-- *********************************************************************  -->

  <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Training Course Duration<span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="text" name="Training_Course_Duration" placeholder="Training Course Duration" value="">
</div>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
  


  <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Status<span style="color:red;font-size:18pt;">*</span></label>
                    <select class="form-control" type="text" name="Status"  >

                    </select>
</div>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
  
    <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.Training.form_Training', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>