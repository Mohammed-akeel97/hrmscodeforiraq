

  <?php $__env->startSection('table_edit_vol'); ?>
   <div class="panel-body table-responsive">
        <table class="table table-hover">
          <thead>
            <tr class="th">
              <th class="text-center"> No. </th>
              <th class="text-center"> Name </th>
              <th class="text-center"> Volunteer Code </th>
              <th class="text-center"> E-Mail </th>
              <th class="text-center"> Governorate</th>
                  <th class="col-tools text-center"><span class="	glyphicon glyphicon-wrench" aria-hidden="true"></span>
            </tr>
          </thead>

          <tbody>
        <?php for($i=1;$i<5;$i++): ?>
            <tr class="edit" id="detail">
              <td id="no" class="text-center"> 1</td>
              <td id="name" class="text-center"> mohammed</td>
              <td id="mobile" class="text-center"> #p123 </td>
              <td id="mail" class="text-center"> mohammed@gmail.com </td>
              <td id="city" class="text-center"> baghdad</td>
               <td align="center">
                                <a class="btn btn-default"><span class="glyphicon glyphicon-pencil"
                                                                 aria-hidden="true"></span></a>
                                <a class="btn btn-danger"><span class="glyphicon glyphicon-trash"
                                                                aria-hidden="true"></span></a>
 <a class="btn btn-info"><span class="glyphicon glyphicon-list-alt"
                            aria-hidden="true"></span></a>
                            </td>
            </tr>
<?php endfor; ?>
 
          </tbody>
        </table>
      </div>
      <?php $__env->stopSection(); ?>