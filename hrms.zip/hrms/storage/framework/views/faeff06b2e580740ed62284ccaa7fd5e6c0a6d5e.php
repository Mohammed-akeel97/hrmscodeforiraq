<html lang="en"><head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex, nofollow">


    <title>Code For Iraq</title>
    <link rel="shortcut icon" href="<?php echo e(URL::to('/')); ?>/Images/logo_home.png" type="image/x-icon" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
      <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
       <link href="<?php echo e(asset('css/check_box.css')); ?>" rel="stylesheet">
           <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
                       <script type="text/javascript" src="<?php echo e(asset('bootstrap/jquery/jquery-3.2.1.min.js')); ?>"></script>
                                <script type="text/javascript" src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
                        
      <link href="<?php echo e(asset('css/nav_bar.css')); ?>" rel="stylesheet">
       <link href="<?php echo e(asset('css/footer.css')); ?>" rel="stylesheet">
     
           <style>
           html,body{
               background-image:url("<?php echo e(URL::to('/')); ?>/Images/bg_photo_hrms.png");
               
           }
           </style>
<?php echo $__env->make('includes.nav_bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>
<body style="zoom: 1;">
<?php echo $__env->yieldContent('form_reg'); ?>
<?php echo $__env->yieldContent('home'); ?>
<?php echo $__env->yieldContent('panel_edit'); ?>

<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</body>

</html>