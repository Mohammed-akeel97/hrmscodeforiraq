<?php $__env->startSection('panel_edit'); ?>
 <div class="container-fluid">
    <div class="panel panel-info">
      <div class="panel-heading">
       <?php echo $__env->yieldContent('search_panel'); ?>
      </div>

   <?php echo $__env->yieldContent('table_edit_vol'); ?>

      <div class="panel-footer">
        <div class="row">
          <div class="col-lg-12">
            <div class="col-md-12">
              </div>
              <div class="col-md-12">
              <p class="muted pull-right"><strong> © 2017 All rights reserved Code For Iraq </strong></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>