

<script>
function myFunction(selTag) {
  
    var x = selTag.selectedIndex;
    var pg=document.getElementById("Parent_Group");
    if(x==1)
pg.disabled = true;
    if(x==2)
pg.disabled = false;
}



</script>


     <h3 class="headerSign"><?php echo e($title_panel_Group_Information); ?></h3>
     <!-- *******************************  -->
                <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($Volunteer_Code); ?><span style="color:red;font-size:18pt;">*</span></label>
                    <select class="form-control"  name="Volunteer_Code" >

                    <option value="#StM001" >Strategy</option>
                     <option value="#StV002" >Human Resorce</option>
                      <option value="" >Art</option>
                       <option value="" >Project</option>
                    </select>
                    
                </div>
                <!-- **************************** -->
                  <div class="form-group" >                    
                <label class="cols-sm-2 control-label "><?php echo e($Position); ?><span style="color:red;font-size:18pt;">*</span></label>
                    <select class="form-control"  name="Position" id="Position" onchange="myFunction(this)" >
<option value="" disabled selected hidden><?php echo e($Position); ?></option>
                    <option value="" ><?php echo e($Position_Manager); ?></option>
                     <option value="" ><?php echo e($Position_Volunteer); ?></option>
                   
                    </select>
                    
                </div>
                 <!-- **********************************  -->

    <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($Parent_Group); ?></label>
                    <select class="form-control"  name="Parent_Group" id="Parent_Group"  >
<option value="" disabled selected hidden><?php echo e($Parent_Group_title); ?></option>
                    <option value="" >Oasama ismail</option>
                     <option value="" >Ahmed ali</option>
                  
                    </select>
                    
                </div>

         <!--***********************************  -->