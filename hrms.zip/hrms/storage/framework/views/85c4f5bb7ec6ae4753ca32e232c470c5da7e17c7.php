                              <!--***********************************  -->
 <h3 class="headerSign" align="center"><?php echo e($title_panel_Specialty_Information); ?></h3>
 <!-- *********************************************************************  -->
 
    <div class="form-group">                    
        
                    <?php echo e(Form::label('$Acadimic_Achievement', $Acadimic_Achievement)); ?><span style="color:red;font-size:18pt;">*</span>
           
                    <?php echo e(Form::select('Acadimic_Achievement', [
                        $Acadimic_Achievement_High_School => $Acadimic_Achievement_High_School,    
                        $Acadimic_Achievement_diploma => $Acadimic_Achievement_diploma,   
                        $Acadimic_Achievement_Bachelor => $Acadimic_Achievement_Bachelor,   
                        $Acadimic_Achievement_Master => $Acadimic_Achievement_Master,   
                        $Acadimic_Achievement_Doctorate => $Acadimic_Achievement_Doctorate,   
                        $Acadimic_Achievement_not => $Acadimic_Achievement_not,              
   ],'',['class'=>'form-control','placeholder'=>$Acadimic_Achievement,]
)); ?>

<?php if($errors->has('Acadimic_Achievement')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Acadimic_Achievement')); ?></strong>
                                    </span>
                                <?php endif; ?>
                </div>
                <!-- *********************************************************************  -->
 <!-- *********************************************************************  -->
                <div class="form-group">
       
                    <?php echo e(Form::label('Specialization', $Specialization)); ?><span style="color:red;font-size:18pt;">*</span>
                <?php echo e(Form::text('Specialization','',['class'=>'form-control','placeholder'=>$Specialization]  )); ?>

                <?php if($errors->has('Specialization')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Specialization')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
<!-- *********************************************************************  -->
                <div class="form-group">
            <?php echo e(Form::label('Experience', $Experience)); ?><span style="color:red;font-size:18pt;">*</span>
                <?php echo e(Form::textarea('Experience','',['class'=>'form-control','placeholder'=>$Experience]  )); ?>

                <?php if($errors->has('Experience')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Experience')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
<!-- *********************************************************************  -->
