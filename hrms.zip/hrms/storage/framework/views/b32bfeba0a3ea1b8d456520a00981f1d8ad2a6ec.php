                     <h3 class="headerSign" align="center"><?php echo e($title_panel_Personal_Information); ?></h3>
           

      <!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
                <div class="form-group">
             <label class="cols-sm-2 control-label "><?php echo e($Full_Name); ?><span style="color:red;font-size:18pt;">*</span></label>
                  
                    <input class="form-control" type="text" name="Full_Name" placeholder="<?php echo e($Full_Name); ?>" value="">

</div>
<!-- *********************************************************************  -->

    <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($Gender); ?><span style="color:red;font-size:18pt;">*</span></label>
                    <select class="form-control"  name="Gender" >

                    <option value="" ><?php echo e($Gender_Male); ?></option>
                     <option value="" ><?php echo e($Gender_Female); ?></option>
                   
                    </select>
                    
                </div>
                <!-- *********************************************************************  -->

    <div class="form-group">                    
                <label class="cols-sm-2 control-label "><?php echo e($Day_of_Birth); ?><span style="color:red;font-size:18pt;">*</span></label>
                   <input class="form-control" type="date" name="Day_of_Birth" placeholder="<?php echo e($Day_of_Birth); ?>" value="">

                    
                </div>
                <!-- *********************************************************************  -->