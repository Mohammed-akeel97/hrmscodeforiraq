

 <?php $__env->startSection('search_panel'); ?>
 <div class="row">
          <div class=" col-md-12">
            <h2 class="text-center pull-left" style="padding-left: 30px;"> <span class="glyphicon glyphicon-list-alt"> </span> Edit Volunteers </h2>
          </div>
          <div class=" col-md-12">
            <div class=" col-md-12">
              <div class=" col-md-12">
                
                <!-- *************************  -->
            <div class=" col-md-4 pull-right">
                
                <div class="form-group">
                <label> Search </label>
                  <div class="input-group">

                    <input type="text" class="form-control input-md" name="Volunteer_Name" data-original-title="" placeholder="Name Volunteer" title="">
                    <div class="input-group-btn">
                      <button type="button" class="btn btn-md btn-info"> <span class=" glyphicon glyphicon-search"></span></button>
                    </div>
                  </div>
                  </div>
                  </div>
                   <!-- *************************  -->
            <div class=" col-md-4 pull-right">
                   
                    <div class="form-group">
                 <label> Department </label>
                  
                    <select  class="form-control input-md" name="Volunteer_Code" data-original-title="" placeholder="Name Volunteer" title="">
        <option value="" >Department</option>            
<option value="#StM001" >Strategy</option>
                     <option value="#StV002" >Human Resorce</option>
                      <option value="" >Art</option>
                       <option value="" >Project</option>
                    </select>
                

                </div>
                </div>
                 <!-- *************************  -->
            <div class="col-md-4 pull-right">
                 
                       <div class="form-group">
               
                  <label> Position </label>
                    <select  class="form-control input-md" name="Position" data-original-title="" placeholder="Name Volunteer" title="">

<option value="">Position</option>
                    <option value="">Manager</option>
                     <option value="">Volunteer</option>
                   
                    </select>
          

                </div>
                </div>
                 <!-- *************************  -->
              </div>
            </div>
          </div>
        </div>
        <?php $__env->stopSection(); ?>