<h3 class="headerSign" align="center"><?php echo e($title_panel_social_m); ?></h3>

                          <!-- *********************************************************************  -->
    <div class="form-group">                    
                 <?php echo e(Form::label('facebook', $facebook)); ?>

                <?php echo e(Form::text('facebook','',['class'=>'form-control','placeholder'=>$facebook]  )); ?>

                <?php if($errors->has('facebook')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('facebook')); ?></strong>
                                    </span>
                                <?php endif; ?>
                    
                </div>
                                          <!-- *********************************************************************  -->
  
                        <!-- *********************************************************************  -->
    <div class="form-group">                    
              <?php echo e(Form::label('Instagram', $Instagram)); ?>

                <?php echo e(Form::text('Instagram','',['class'=>'form-control','placeholder'=>$Instagram]  )); ?>

                <?php if($errors->has('Instagram')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Instagram')); ?></strong>
                                    </span>
                                <?php endif; ?>
                </div>
                                          <!-- *********************************************************************  -->
                       <!-- *********************************************************************  -->
    <div class="form-group">                    
                    <?php echo e(Form::label('Twitter', $Twitter)); ?>

                <?php echo e(Form::text('Twitter','',['class'=>'form-control','placeholder'=>$Twitter]  )); ?>    
                <?php if($errors->has('Twitter')): ?>
                                    <span class="help-block" style="color:red;">
                                        <strong><?php echo e($errors->first('Twitter')); ?></strong>
                                    </span>
                                <?php endif; ?>
              </div>
                                          <!-- *********************************************************************  -->
  

