<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/




//*********************************************************************** Volunteer
// 
Route::get('/volunteer/search', 'Volunteer_controller@search');
    Route::resource('volunteer',"Volunteer_controller");


//******************************************************* project
//
Route::get('/project/search', 'project_controller@search');
Route::resource('/project',"project_controller");
//******************************************************* Announcement_controller
Route::resource('/announcement',"Announcement_controller");
 

//*******************************************************  Training 
// add 
Route::get('/training/edit', 'Training_controller@View');
Route::resource('/training',"Training_controller");









Auth::routes();

Route::get('/', 'HomeController@index')->name('home');
Route::get('/home', 'HomeController@index')->name('home');

