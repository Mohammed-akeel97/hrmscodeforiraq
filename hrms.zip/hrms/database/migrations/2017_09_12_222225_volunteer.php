<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Volunteer extends Migration
{
      /**
     * Run the migrations.
     *
     * @return void
     */
     public function up()
     {
         Schema::create('volunteers', function (Blueprint $table) {
             //1
             $table->increments('id')->unsigned();
             //2
             $table->string('Volunteer_Code');
             //3
             $table->string('Full_Name');
          
             //4
             $table->string('Specialization');
             //5
             $table->string('Gender');
             //6
             $table->string('parent_group')->nullable();
           //7
            $table->date('Day_of_Birth');
           //8
           $table->string('Acadimic_Achievement');
           //9
              $table->string('Governorate');
             //10
             $table->mediumText('New_Pecture');
              //11
             $table->string('Address');
                //12
               $table->mediumText('Experience');
              
              //13
                  $table->string('Blood_Group');
                  //14
                  $table->string('email')->unique();
                  //15
                  $table->string('Marital_Status');
                  //16
                  $table->string('Phone_Number1');
                  //17
              
                  $table->string('Phone_Number2')->nullable();
                  //18
               
                  //19
       
                  $table->mediumText('Twitter')->nullable();
                  //20
                  $table->mediumText('facebook')->nullable();
                  //21
                  $table->mediumText('Instagram')->nullable();
                  //22
                  $table->string('how_add');
             
             $table->timestamps();
         });
     }
 
     /**
      * Reverse the migrations.
      *
      * @return void
      */
     public function down()
     {
         Schema::dropIfExists('volunteers');
     }
}
