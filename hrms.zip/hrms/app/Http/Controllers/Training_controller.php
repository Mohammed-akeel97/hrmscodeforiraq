<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Training_controller extends Controller
{
     /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
       // view
    public function index(){
   return view('hrm.Training.View.component_form');

    }
    //add
    public function create(){


        return view('hrm.Training.Add.component_form');
    }
 
        //  edit
            public function edit($id)
    {
    
        
          return view('hrm.Training.Update.component_form');
    }


    public function View(){
   return view('hrm.Training.Edit.component_form');

    }
    
}
