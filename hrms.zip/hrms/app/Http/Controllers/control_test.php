<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Test;

class control_test extends Controller
{
    //
        public function test(){

         return view('test.test');
    }

    public function veiwtests(){
     

$arr=['test' => Test::all()];

         return view('test.veiwtests',$arr);
    }
}
