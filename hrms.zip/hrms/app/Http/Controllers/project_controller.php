<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use App\Http\Controllers\Controller;


class project_controller extends Controller

{
      public function __construct()
    {
        $this->middleware('auth');
    }

  public function index(){
  
return view('hrm.project.Edit.component_form');

    }
  //add
      public function create(){
  
return view('hrm.project.Add.component_form');

    }

//edit

    public function edit($id)
    {
 
       return view('hrm.project.Update.component_form');
        
  
    }

    //search
      public function search(){
  
return view('hrm.project.Search.component_form');

    }
}
