<?php

namespace App\Http\Controllers;
use App\Volunteer;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class Volunteer_controller extends Controller
{
 /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

public function index(){
    return view('hrm.volunteer.Edit.component_form');
}
    // add
    public function store(Request $request)
    {
        $this->validate($request ,[
            'Volunteer_Code'=>'required',
            'Position'=>'required',
            'Acadimic_Achievement'=>'required',
            'Specialization'=>'required',
            'Experience'=>'required',
            'email'=>'required|unique:volunteers',
            'Phone_Number1'=>'required',
       
            'Full_Name'=>'required',
            'Blood_Group'=>'required',
            'Marital_Status'=>'required',
            'Gender'=>'required',
            'Day_of_Birth'=>'required',
            'Governorate'=>'required',
            'Address'=>'required',
            'Password'=>'required|min:6',
            'facebook'=>'url|nullable',
            'Instagram'=>'url|nullable',
            'Twitter'=>'url|nullable',
            'New_Pecture'=>'image|required|max:1024',
           ]);
           if($request->hasFile('New_Pecture')){  
            
                $filenameWithExtention = $request->file('New_Pecture')->getClientOriginalName();
                $fileName = pathinfo($filenameWithExtention,PATHINFO_FILENAME);
                $extension = $request->file('New_Pecture')->getClientOriginalExtension();
                $fileNameStore = $fileName .'_'.time().'.'.$extension;
            
                $path = $request->file('New_Pecture')->move(base_path() . '/public/pictures/', $fileNameStore);
              
             
                        
                    }else{
                            $fileNameStore = 'noImage.jpg';
                          }
             
            // if($request->hasFile('post_image')){
            //     $filenameWithExtention = $request->file('post_image')->getClientOriginalName();
            //     $fileName = pathinfo($filenameWithExtention,PATHINFO_FILENAME);
            //     $extension = $request->file('post_image')->getClientOriginalExtension();
            //     $fileNameStore = $fileName .'_'.time().'.'.$extension;
            //     $path = $request->file('post_image')->storeAs('public/post_image',$fileNameStore);
            // }else{
            //     $fileNameStore = 'noImage.jpg';
            // }
   // add to table

   $Volunteer = new Volunteer;
   //1
   $Volunteer->Volunteer_Code = $request->input('Volunteer_Code');
   //2
   $Volunteer->Full_Name = $request->input('Full_Name');
   //3
   $Volunteer->Specialization = $request->input('Specialization');
   //4
   $Volunteer->Gender = $request->input('Gender');
   //5
   $Volunteer->parent_group = $request->input('parent_group');
   //6
   $Volunteer->Day_of_Birth = $request->input('Day_of_Birth');
   //7
   $Volunteer->Acadimic_Achievement = $request->input('Acadimic_Achievement');
   //8
   $Volunteer->Governorate = $request->input('Governorate');
   //9
   $Volunteer->New_Pecture = $fileNameStore;
   //10
   $Volunteer->Address = $request->input('Address');
   //11
   $Volunteer->Experience = $request->input('Experience');
   //12
   $Volunteer->Blood_Group = $request->input('Blood_Group');
   //13
   $Volunteer->email = $request->input('email');
   //14
   $Volunteer->Marital_Status = $request->input('Marital_Status');
   //15
   $Volunteer->Phone_Number1 = $request->input('Phone_Number1');
   //16
   $Volunteer->Phone_Number2 = $request->input('Phone_Number2');
   //17
   $Volunteer->Twitter = $request->input('Twitter');
   //18
   $Volunteer->facebook = $request->input('facebook');
   //19
   $Volunteer->Instagram = $request->input('Instagram');
   //20
   $Volunteer->how_add = Auth::user()->name;
   //add to table
   $Volunteer->save();
   // add to table user
   $User = new User;
   $User->name=$request->input('Full_Name');
   $User->email=$request->input('email');
   $User->password=bcrypt($request->input('Password'));
   $User->save();

        return redirect('/volunteer/create')->with('success', 'Add Volunteer Done successfully');
    }







    //*************************************************8
    // create page
    public function create(){
        $titles=Volunteer_controller::titles("en");
        $form_items=Volunteer_controller::form_items("en");
     
return view('hrm.volunteer.Add.component_form',$titles,$form_items);

    }


//search
  public function search(){
  
return view('hrm.volunteer.Search.component_form');

    }


    public function edit($id)
    {
     
             $titles=Volunteer_controller::titles("en");
        $form_items=Volunteer_controller::form_items("en");
     
return view('hrm.volunteer.Update.component_form',$titles,$form_items);
        

    }
















// english form 
// titles panel
//****************************************
public function titles($language){
  if($language=="en")
$arr_titles=array (
'title_form'=>"Add Volunteer"
 ,
'title_panel_Group_Information'=>"Group Information"
 ,
 'title_panel_Personal_Information'=>"Personal Information"
,
'title_panel_Specialty_Information'=>"Specialty Information"
,
'title_panel_Address'=>"Address"
,
'title_panel_Means_of_communication'=>"Means of communication"
,
'title_panel_other_information'=>"other information"
,
'title_panel_Password'=>"Passoword"
,
'title_panel_Save_Changes'=>"Save Changes",
'title_panel_social_m'=>"Social Media Contact",
'language'=>"en"
);
   
return  $arr_titles;
}
//***************************************
public function form_items($language){
if($language=="en")
$arr=array(
    //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    //Group Information
'Volunteer_Code'=>"Volunteer Code",
//Position select option in Group Information
//***
'Position'=>"Position",
'Position_Manager'=>"Manager",
'Position_Volunteer'=>"Volunteer",
//***
'Parent_Group'=>"Parent Group",
'Parent_Group_title'=>"Manager Name",
 //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//Personal Information
'Full_Name'=>"Full Name",
//Gender select option in Personal Information
//**
'Gender'=>"Gender",
'Gender_Male'=>"Male",
'Gender_Female'=>"Female",

//**
'Day_of_Birth'=>"Day of Birth",
 //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//Means of communication
'email'=>"E-Mail",
'Phone_Number1'=>"Phone Number 1",
'Phone_Number2'=>"Phone Number 2",
 //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//Specialty Information

'Acadimic_Achievement'=>"Acadimic Achievement",
// Acadimic_Achievement select option personal information
//***
//1
'Acadimic_Achievement_High_School'=>"High School",
//2
'Acadimic_Achievement_diploma'=>"diploma",
//3
'Acadimic_Achievement_Bachelor'=>"Bachelor",
//4
'Acadimic_Achievement_Master'=>"Master",
//5
'Acadimic_Achievement_Doctorate'=>"Doctorate",
//6
'Acadimic_Achievement_not'=>"Not Graduated",
//**
'Specialization'=>"Specialization",
'Experience'=>"Experience",


 //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//Address
'Address'=>"Address",
'Governorate'=>"Governorate",'Governorates'=>
//select Governorate option 
[
//1

'Al Anbar'=>"Al Anbar",
//2
'Babil'=>"Babil",
//3
'Baghdad'=>"Baghdad",
//4
'Basra'=>"Basra",
//5
'Dhi Qar'=>"Dhi Qar",
//6
'Al-Qadisiyyah'=>"Al-Qadisiyyah",
//7 
'Diyala'=>"Diyala",
//8 
'Dohuk'=>"Dohuk",
//9
'Al Anbar'=>"Erbil",
//10
'Karbala'=>"Karbala",
//11
'Kirkuk'=>"Kirkuk",
//12
'Maysan'=>"Maysan",
// 13
'Muthanna'=>"Muthanna",
//14
'Najaf'=>"Najaf",
//15
'Nineveh'=>"Nineveh",
//16
'Saladin'=>"Saladin",
//17
'Sulaymaniyah'=>"Sulaymaniyah",
//18
'Wasit'=>"Wasit"],
//****
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//other information
'Blood_Group'=>"Blood Group",
'New_Pecture'=>"New Pecture",
'Marital_Status'=>"Marital Status",
// select oprion Marital_Status
// ***
'Marital_Status_Married'=>"Married",
'Marital_Status_Not'=>"Not Married",
// ***
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//Passoword
'Password'=>"Password",
'Generate_Password'=>"Generate Password",
'save'=>"save",
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//social m
'facebook'=>"Facebook",
'Instagram'=>"Instagram",
'Twitter'=>"Twitter",
'new_pecture'=>"New Picrtrue"
);


return $arr;
}
//*************************************8888

}

