<html lang="en"><head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex, nofollow">


    <title>Code For Iraq</title>
    <link rel="shortcut icon" href="{{ URL::to('/') }}/Images/logo_home.png" type="image/x-icon" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
      <link href="{{ asset('css/app.css') }}" rel="stylesheet">
       <link href="{{ asset('css/check_box.css') }}" rel="stylesheet">
           <link href="{{ asset('bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">
                       <script type="text/javascript" src="{{ asset('bootstrap/jquery/jquery-3.2.1.min.js')}}"></script>
                                <script type="text/javascript" src="{{ asset('bootstrap/js/bootstrap.min.js')}}"></script>
                        
      <link href="{{ asset('css/nav_bar.css') }}" rel="stylesheet">
       <link href="{{ asset('css/footer.css') }}" rel="stylesheet">
     
           <style>
           html,body{
               background-image:url("{{ URL::to('/') }}/Images/bg_photo_hrms.png");
               
           }
           </style>
@include('includes.nav_bar')

</head>
<body style="zoom: 1;">
@yield('form_reg')
@yield('home')
@yield('panel_edit')

@include('includes.footer')


</body>

</html>