 <h3 class="headerSign">Title & Trainer Name</h3>
                 <!--***********************************  -->
<!-- *********************************************************************  -->

  <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Title Trining<span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="text" name="Title_Trining"   placeholder="Title Trining" value="">
</div>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
  <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Trainer Name<span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="text" name="Trainer_Name"   placeholder="Trainer Name" value="">
</div>
<!-- *********************************************************************  -->

  