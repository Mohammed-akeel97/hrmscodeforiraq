 <h3 class="headerSign">Training Place & Date Start</h3>
     
                 <!--***********************************  -->
 <!-- *********************************************************************  -->

  <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Training Place<span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="text" name="Training_Place" placeholder="Training Place" value="">
</div>
<!-- *********************************************************************  -->
  <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Training Start Date<span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="date" name="Start_Date" placeholder="Training Start Date" value="">
</div>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
  