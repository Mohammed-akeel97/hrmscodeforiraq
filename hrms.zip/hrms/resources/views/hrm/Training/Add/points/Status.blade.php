<h3 class="headerSign">Training Course Duration & Status</h3>
     
                 <!--***********************************  -->
 <!-- *********************************************************************  -->

  <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Training Course Duration<span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="text" name="Training_Course_Duration" placeholder="Training Course Duration" value="">
</div>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
  


  <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Status<span style="color:red;font-size:18pt;">*</span></label>
                    <select class="form-control" type="text" name="Status"  >

                    </select>
</div>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->