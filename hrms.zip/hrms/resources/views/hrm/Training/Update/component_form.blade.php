@extends('layouts.general')

<link href="{{ asset('css/add.css') }}" rel="stylesheet">
<!-- *************************  left ****************** -->
@section('form_reg')
<br>
<form action="" method="POST">
	 <!--this was made my Agil Asadi. You are free to delete this comment line and use it as you wish-->   
<div class="container">
	<div class="row">
		<h2 class="headerSign" style="">Update Training</h2>

	</div>
</div>
<div class="row col-md-8 col-ms-5 col-md-offset-2 registeration" style="z-index:100;background-color:rgba(255,255,255,0.8)">
    
<div class="registerInner">
<!-- ********************************  lift -->
        <div class="col-md-6 signUp">
<br>
<!-- ********************************  title_and_name -->
@include('hrm.Training.Update.points.title_and_name')
<!-- ********************************  Status -->
 @include('hrm.Training.Update.points.Status')
 

 </div>
<!-- ********************************  right -->       
        <div class="col-md-6">
        <br>
        <!-- ********************************  date_and_place -->
@include('hrm.Training.Update.points.date_and_place')


 
                    
                </div>
<!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
                         <!-- *********************************************************************  -->

                
             
       
       <br>  <br>  <br>                    <!-- *********************************************************************  -->
 <div class="form-group"> 
     <br>  <br>  <br>  <br> <br>  <br>  <br>  <br> <br>  <br>  
           
                <button type="submit" class="signbuttons btn btn-primary pull-right">Save</button>
                 <a href="/training/edit" class="signbuttons btn btn-primary pull-right">Back</a>
     
   <br>  
               </div>  

 
<!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
            
        </div>
             
</div>
       
</div>

</form>

@endsection