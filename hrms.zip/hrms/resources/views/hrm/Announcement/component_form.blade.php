@extends('layouts.general')
<link href="{{ asset('css/add.css') }}" rel="stylesheet">
<!-- *************************  left ****************** -->
@section('form_reg')
<br>
<form action="" method="POST">
	 <!--this was made my Agil Asadi. You are free to delete this comment line and use it as you wish-->   
<div class="container">
	<div class="row">
		<h2 class="headerSign" style="">Announcement Send E-mail</h2>

	</div>
</div>
<div class="row col-md-8 col-ms-5 col-md-offset-2 registeration" style="z-index:100;background-color:rgba(255,255,255,0.8)">
    
<div class="registerInner">
<!-- ********************************  lift -->
        <div class="col-md-6 signUp">
<br>

 @include('hrm.Announcement.points.left')
 
 
 </div>
<!-- ********************************  right -->       
        <div class="col-md-6">
        <br>
 @include('hrm.Announcement.points.right')
 
                    
                </div>
<!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
@include('hrm.Announcement.points.check_box')
                         <!-- *********************************************************************  -->

                
             
       
                  <!-- *********************************************************************  -->
 <div class="form-group"> 
 
           
                <button type="submit" class="signbuttons btn btn-primary pull-right">Send</button>
   <br>  
               </div>  

 
<!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
            
        </div>
             
</div>
       
</div>

</form>

@endsection