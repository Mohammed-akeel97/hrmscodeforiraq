                               <!--***********************************  -->
 <h3 class="headerSign" align="center">Requirement & Team</h3>
<!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Project Requirement<span style="color:red;font-size:18pt;">*</span></label>
                    <textarea class="form-control"  name="Project_Requirement" placeholder="Project Requirement" value=""></textarea>
</div>
<!-- *********************************************************************  -->
       <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Project Provider<span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="text" name="Project_Provider" placeholder="Project Provider" value="">
</div>
<!-- *********************************************************************  -->
       <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Team Responsible for the Project<span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="text" name="Team_Responsible" placeholder="Team Responsible for the Project" value="">
</div>
<!-- *********************************************************************  -->
 