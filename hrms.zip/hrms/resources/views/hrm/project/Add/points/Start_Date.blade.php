                 <!--***********************************  -->
 <h3 class="headerSign" align="center">Start Date&Estimate  Time</h3>
 <!-- *********************************************************************  -->

  <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Project Start Date</label>
                    <input class="form-control" type="date" name="Project_Start_Date" placeholder="Project Start Date" value="">
</div>
<!-- *********************************************************************  -->
<!-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->
  
                  <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Estimate Project Time<span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="text" name="Estimate_Project_Time" placeholder="Estimate Project Time" value="">
</div>
<!-- *********************************************************************  -->
 

   