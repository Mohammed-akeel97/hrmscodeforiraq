<!-- *******************************  -->


     <h3 class="headerSign">Name & Description</h3>
     <!-- *******************************  -->
      <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Project Name<span style="color:red;font-size:18pt;">*</span></label>
                    <input class="form-control" type="text" name="Project_Name" placeholder="Project Name" value="">
</div>
<!-- *********************************************************************  -->
     <!-- *********************************************************************  -->
                <div class="form-group">
             <label class="cols-sm-2 control-label ">Description<span style="color:red;font-size:18pt;">*</span></label>
                    <textarea class="form-control"  name="Description" placeholder="Description" value=""></textarea>
</div>
<!-- *********************************************************************  -->
    
         <!--***********************************  -->