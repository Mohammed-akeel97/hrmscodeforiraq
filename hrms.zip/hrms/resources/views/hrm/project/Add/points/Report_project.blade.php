            <h3 class="headerSign" align="center">Progress Rate Report</h3>
                          <!-- *********************************************************************  -->
    <div class="form-group">                    
                <label class="cols-sm-2 control-label ">  Project Report<span style="color:red;font-size:18pt;">*</span></label>
                       
                    <textarea class="form-control" type="text" name="project_report" placeholder="Project Report" value=""></textarea>

                    
                </div>
                                                         <!-- *********************************************************************  -->
<!--***************************************************************  -->
            
            <label class="cols-sm-2 control-label "> Progress Rate<span style="color:red;font-size:18pt;">*</span></label>
                  
      <div class="progress">
            <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 15%;">
         
            </div>
            <span class="progress-type">15 </span>
          
        </div>