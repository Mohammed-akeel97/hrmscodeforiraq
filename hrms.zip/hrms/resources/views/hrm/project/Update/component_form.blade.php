@extends('layouts.general')

<link href="{{ asset('css/add.css') }}" rel="stylesheet">
<!-- *************************  left ****************** -->
@section('form_reg')
<form action="" method="POST">
	 <!--this was made my Agil Asadi. You are free to delete this comment line and use it as you wish-->   
<div class="container">
	<div class="row">
		<h2 class="headerSign" style="">Update Project</h2>

	</div>
</div>
<div class="row col-md-8 col-ms-5 col-md-offset-2 registeration" style="z-index:100;background-color:rgba(255,255,255,0.8)">
    
<div class="registerInner">
<!-- ********************************  lift -->
        <div class="col-md-6 signUp">

<!-- ********************************  Name & Description -->  
 @include('hrm.project.Update.points.Name_and_Description')
<!-- ********************************  Requirement & Team  -->  
@include('hrm.project.Update.points.Requirement')


 </div>
<!-- ********************************  right  -->       
        <div class="col-md-6">
        <!-- ********************************Start Date&Estimate Time-->  
@include('hrm.project.Update.points.Start_Date')
<!-- ********************************Progress Rate Report -->  
 @include('hrm.project.Add.points.Report_project')
   

 
                    
                </div>
<!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
                         <!-- *********************************************************************  -->

                
                <br>  <br>  <br>  <br>  <br>
                          <!-- *********************************************************************  -->
 <div class="form-group"> 
                <button type="submit" class="signbuttons btn btn-primary pull-right">Save</button>
           <a href="/project" class="signbuttons btn btn-primary pull-right">Back</a>
     
               </div>  
			  <br>
<br>	
			  <br>
<br>		  
<!-- @@@@@@@@@@@@@@@@@@@@@@@@  -->
            
        </div>
             
</div>
       
</div>

</form>

@endsection