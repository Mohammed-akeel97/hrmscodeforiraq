

<script>
function myFunction(selTag) {
  
    var x = selTag.selectedIndex;
    var pg=document.getElementById("Parent_Group");
    if(x==1)
pg.disabled = true;
    if(x==2)
pg.disabled = false;
}



</script>


     <h3 class="headerSign">{{$title_panel_Group_Information}}</h3>
     <!-- *******************************  -->
                <div class="form-group">                    
                {{Form::label('Volunteer_Code', $Volunteer_Code)}}<span style="color:red;font-size:18pt;">*</span>
           
                    {{ Form::select('Volunteer_Code', [
   'st' => 'Strategy',
   'hr' => 'Human Resorce',
   'ar' => 'Art',
   '[pr]' => 'Project',
   ],'',['class'=>'form-control','placeholder'=>$Volunteer_Code]
) }}
                </div>
                @if ($errors->has('Volunteer_Code'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('Volunteer_Code') }}</strong>
                                    </span>
                                @endif
                <!-- **************************** -->
                  <div class="form-group" >                    
                {{Form::label('Position', $Position)}}<span style="color:red;font-size:18pt;">*</span>
           
                    {{ Form::select('Position', [
                        $Position_Manager => $Position_Manager,
                        $Position_Volunteer => $Position_Volunteer,
                        
   ],'',['class'=>'form-control','placeholder'=>$Position,'onclick'=>'myFunction(this)']
) }}
@if ($errors->has('Position'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('Position') }}</strong>
                                    </span>
                                @endif
                </div>
                 <!-- **********************************  -->

    <div class="form-group">                    

                     
                {{Form::label('Parent_Group', $Parent_Group)}}
           
                    {{ Form::select('Parent_Group', [
                        $Parent_Group => $Parent_Group,               
   ],'',['class'=>'form-control','placeholder'=>$Parent_Group_title,]
) }}
                </div>
         <!--***********************************  -->