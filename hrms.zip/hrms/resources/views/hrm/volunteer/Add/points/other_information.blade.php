               <h3 class="headerSign" align="center">{{$title_panel_other_information}}</h3>
                          <!-- *********************************************************************  -->
    <div class="form-group">                    

                    {{Form::label('Blood_Group',$Blood_Group)}}<span style="color:red;font-size:18pt;">*</span>
           
                    {{ Form::select('Blood_Group', [   'AB+-ve'=> 'AB+-ve',   'A+-ve'=> 'A+-ve',   'B+-ve'=> 'B+-ve', 
                        'O+-ve'=> 'O+-ve',               
   ],'',['class'=>'form-control','placeholder'=>$Blood_Group,]
) }}
@if ($errors->has('Blood_Group'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('Blood_Group') }}</strong>
                                    </span>
                                @endif
                </div>
                           <!-- *********************************************************************  -->

    <div class="form-group">                    
    {{Form::label('Marital_Status', $Marital_Status)}}
               <span style="color:red;font-size:18pt;">*</span>
           
                    {{ Form::select('Marital_Status', [   $Marital_Status_Married=> $Marital_Status_Married, 
                        $Marital_Status_Not=>$Marital_Status_Not,  
                                   
   ],'',['class'=>'form-control','placeholder'=>$Marital_Status,]
) }}
@if ($errors->has('Marital_Status'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('Marital_Status') }}</strong>
                                    </span>
                                @endif
                </div>
                <!-- *********************************************************************  --
                                                      <!-- *********************************************************************  -->

    <div class="form-group">                    
    <label class="cols-sm-2 control-label ">{{$new_pecture}}</label><span style="color:red;font-size:18pt;">*</span>
                    {{Form::file('New_Pecture', ['class'=>'btn','accept' =>'Image/*' ]) }}
                    @if ($errors->has('New_Pecture'))
                                    <span class="help-block" style="color:red;">
                                        <strong>{{ $errors->first('New_Pecture') }}</strong>
                                    </span>
                                @endif
                </div>
                <!-- *********************************************************************  -->
            